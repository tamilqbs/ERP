-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2024 at 02:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `finance_journal_entry` (IN `amount` DECIMAL(14,2), IN `debit_account` INT(11), IN `credit_account` INT(11), IN `narration` TEXT, IN `created_at` VARCHAR(20), IN `created_by` INT(11), IN `related_to` VARCHAR(140), IN `related_id` INT(11), INOUT `debit_id` INT(11), INOUT `credit_id` INT(11), INOUT `error` TINYINT(1))   BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
		BEGIN
			DECLARE today DATE DEFAULT CURRENT_DATE;
			INSERT INTO journal_entry(gl_acc_id,credit,debit,narration,amount,transaction_date,created_at,created_by,related_to,related_id,prev_amount)
			VALUES(debit_account,0,1,narration,amount,today,created_at,created_by,related_to,related_id,amount) ;
			SELECT LAST_INSERT_ID() INTO debit_id;
			IF debit_id = 0 THEN 
				SET error=1;
			ELSE
				INSERT INTO journal_entry(gl_acc_id,credit,debit,narration,amount,transaction_date,created_at,created_by,related_to,related_id,
				prev_amount) VALUES(credit_account,1,0,narration,amount,today,created_at,created_by,related_to,related_id,amount) ;
				SELECT LAST_INSERT_ID() INTO credit_id;
				IF credit_id = 0 THEN 
					SET error=1;
				END IF;
			END IF;
		END;
END$$

CREATE DEFINER=`stagqbs`@`localhost` PROCEDURE `finance_journal_insert_post` (IN `amount` DECIMAL(14,2), IN `debit_account` INTEGER(11), IN `credit_account` INTEGER(11), IN `debit_id` INTEGER(11), IN `credit_id` INTEGER(11), INOUT `error` TINYINT(1))   BEGIN
	
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
		BEGIN
			DECLARE _period DATE ;
			DECLARE checking INTEGER(11) DEFAULT 0;
			SELECT STR_TO_DATE(CONCAT("1",',',MONTH(CURRENT_DATE),',',YEAR(CURRENT_DATE)),'%d,%m,%Y') INTO _period;
			SELECT gl_acc_id INTO checking FROM general_ledger WHERE DATE(period)=DATE(_period) AND gl_acc_id=debit_account;
			IF checking = 0 THEN
				INSERT INTO general_ledger(gl_acc_id,period,actual_amt,balance_fwd) VALUES(debit_account,_period,0.00,0.00);
			END IF;
			UPDATE general_ledger SET actual_amt=actual_amt+amount , balance_fwd=balance_fwd+amount WHERE DATE(period)=DATE(_period) 
			AND gl_acc_id=debit_account;
			UPDATE general_ledger SET balance_fwd=balance_fwd+amount WHERE DATE(period) > DATE(_period) AND gl_acc_id=debit_account; 
			UPDATE journal_entry SET posted=1 , posted_date=CURRENT_DATE WHERE journal_id=debit_id;
			
			SET checking=0;
			SELECT gl_acc_id INTO checking FROM general_ledger WHERE DATE(period)=DATE(_period) AND gl_acc_id=credit_account;
			IF checking = 0 THEN
				INSERT INTO general_ledger(gl_acc_id,period,actual_amt,balance_fwd) VALUES(credit_account,_period,0.00,0.00);
			END IF;
			UPDATE general_ledger SET actual_amt=actual_amt-amount , balance_fwd=balance_fwd-amount WHERE DATE(period)=DATE(_period) 
			AND gl_acc_id=credit_account;
			UPDATE general_ledger SET balance_fwd=balance_fwd-amount WHERE DATE(period) > DATE(_period) AND gl_acc_id=credit_account; 
			UPDATE journal_entry SET posted=1 , posted_date=CURRENT_DATE WHERE journal_id=credit_id;
		END ;
END$$

CREATE DEFINER=`stagqbs`@`localhost` PROCEDURE `stock_qty_update` (IN `db_related_id` INTEGER(11), IN `db_related_to` VARCHAR(140), IN `db_warehouse_id` INTEGER(11), IN `db_price_id` INTEGER(11), IN `db_qty` INTEGER(11), INOUT `error_flag` TINYINT(1))   BEGIN
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE db_stock_id INTEGER(11) DEFAULT 0;
	
	SELECT stock_id INTO db_stock_id FROM stocks WHERE warehouse_id=db_warehouse_id AND related_id=db_related_id AND related_to=db_related_to AND price_id=db_price_id;
	IF db_stock_id <> 0 THEN
		UPDATE stocks SET quantity=quantity+db_qty WHERE stock_id=db_stock_id;
		SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows <= 0 THEN
			SET error_flag=1;
		ELSE
			/* entry_type 0 means procurement */
			INSERT INTO stock_entry(entry_type,stock_id,qty,created_at) VALUES(0,db_stock_id,db_qty,CURRENT_DATE()) ;
		END IF;
	ELSE
		INSERT INTO stocks(related_id,related_to,quantity,price_id,warehouse_id) VALUES(db_related_id,db_related_to,db_qty,db_price_id,db_warehouse_id) ;
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <= 0 THEN
			SET error_flag=1;
		ELSE 
			/* entry_type 0 means procurement */
			INSERT INTO stock_entry(entry_type,stock_id,qty,created_at) VALUES(0,insert_id,db_qty,CURRENT_DATE()) ;
		END IF;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `supplier_segment_update` (IN `w_segment_id` INT(11), IN `w_segment_key` VARCHAR(140), IN `w_segment_value` TEXT)   BEGIN
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE db_segment_key VARCHAR(140) DEFAULT '';
	DECLARE db_segment_value TEXT DEFAULT '';
	DECLARE new_key_len INTEGER(11) DEFAULT 0;
	DECLARE old_key_len INTEGER(11) DEFAULT 0;
	DECLARE diff_len INTEGER(11) DEFAULT 0;
	DECLARE json_path VARCHAR(20) DEFAULT '';

	
	SELECT JSON_LENGTH(w_segment_value) INTO new_key_len;
	SELECT segment_key,segment_value INTO db_segment_key,db_segment_value FROM supplier_segments WHERE segment_id=w_segment_id;
	SELECT JSON_LENGTH(db_segment_value) INTO old_key_len;
	
	SELECT (old_key_len-new_key_len) INTO diff_len;
	UPDATE supplier_segments SET segment_key=w_segment_key , segment_value=w_segment_value WHERE segment_id=w_segment_id;
	
	IF diff_len > 0 THEN
		UPDATE selection_rule_segment SET segment_value_idx=0 WHERE segment_id=w_segment_id AND segment_value_idx>=new_key_len;
		SET json_path='$.';
		SELECT CONCAT(json_path,w_segment_id) INTO json_path;
		UPDATE supplier_segment_map SET segment_json=JSON_REPLACE(segment_json,json_path,"0") WHERE JSON_UNQUOTE(JSON_EXTRACT(segment_json,json_path)) >= new_key_len;
	END IF;
	
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `addOrUpdateProduct` (`w_req_id` INT, `w_related_to` INT, `w_related_id` INT, `w_qty` INT) RETURNS TINYINT(4)  BEGIN
    DECLARE ret_code TINYINT DEFAULT 0;
    DECLARE db_invent_req_id INT DEFAULT 0;
    DECLARE insert_id INT DEFAULT 0;
    DECLARE affected_rows INT DEFAULT 0;

    SELECT invent_req_id INTO db_invent_req_id
    FROM inventory_requisition
    WHERE req_id = w_req_id AND related_to = w_related_to AND related_id = w_related_id;

    IF db_invent_req_id <> 0 THEN
        UPDATE inventory_requisition SET qty = w_qty WHERE invent_req_id = db_invent_req_id;
        SELECT ROW_COUNT() INTO affected_rows;
        IF affected_rows > 0 THEN
            SET ret_code = 1;
        ELSE
            SET ret_code = 2;
        END IF;
    ELSE
        INSERT INTO inventory_requisition (req_id, related_to, related_id, qty)
        VALUES (w_req_id, w_related_to, w_related_id, w_qty);

        SET insert_id = LAST_INSERT_ID();
        IF insert_id <> 0 THEN
            SET ret_code = 1;
        END IF;
    END IF;

    RETURN ret_code;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `add_to_stock` (`w_grn_id` INT(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE db_related_to VARCHAR(140);
	DECLARE db_related_id INTEGER(11);
	DECLARE db_warehouse_id INTEGER(11);
	DECLARE db_qty INTEGER(11);
	DECLARE db_price_id INTEGER(11);
	DECLARE error_flag TINYINT(1) DEFAULT 0;
	DECLARE done INTEGER(11) DEFAULT FALSE;
	DECLARE item_cursor CURSOR FOR SELECT related_id,related_to,received_qty,price_id,purchase_order.warehouse_id
		FROM grn JOIN purchase_order ON grn.order_id=purchase_order.order_id JOIN purchase_order_items 
		ON grn.order_id=purchase_order_items.order_id WHERE grn_id=w_grn_id;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=TRUE;

	OPEN item_cursor;

	label_1: LOOP
		FETCH item_cursor INTO db_related_id,db_related_to,db_qty,db_price_id,db_warehouse_id ;
		IF done THEN
			LEAVE label_1;
		END IF;
		CALL stock_qty_update(db_related_id,db_related_to,db_warehouse_id,db_price_id,db_qty,error_flag);
		IF error_flag = 1 THEN
			LEAVE label_1;
		END IF;
	END LOOP;
	CLOSE item_cursor;
	IF error_flag = 0 THEN
		UPDATE grn SET status=2 WHERE grn_id=w_grn_id;
	END IF;
	RETURN error_flag;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `add_to_stock2` (`w_related_to` VARCHAR(140), `w_related_id` INT(11), `w_price_id` INT(11), `w_warehouse_id` INT(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE db_stock_id INTEGER(11) DEFAULT 0;
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	SELECT stock_id INTO db_stock_id FROM stocks WHERE related_to=w_related_to AND related_id=w_related_id AND price_id=w_price_id AND warehouse_id=w_warehouse_id ;
	IF db_stock_id <> 0 THEN
		UPDATE stocks SET quantity=quantity+1 WHERE stock_id=db_stock_id;
		SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows <= 0 THEN
			SET error=1;
		END IF;
	ELSE 
		INSERT INTO stocks(related_to,related_id,warehouse_id,quantity,price_id) VALUES(w_related_to,w_related_id,w_warehouse_id,1,w_price_id);
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <=0 THEN 
			SET error=1;
		END IF;
	END IF;
	IF error=0 THEN
		/* ENTRY TYPE 1 MEANS MANUAL ENTRY */
		INSERT INTO stock_entry(entry_type,stock_id,qty,created_at) VALUES(1,db_stock_id,1,CURRENT_DATE()) ;
		SET insert_id=0;
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <=0 THEN
			SET error=1;
		END IF;
	END IF;

	RETURN error;
END$$

CREATE DEFINER=`stagqbs`@`localhost` FUNCTION `c_sale_order_items` (`w_type` VARCHAR(140), `w_type_id` INTEGER(11), `w_related_id` INTEGER(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE db_unit_price DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_tax1 TINYINT(4) DEFAULT 0;
	DECLARE db_tax2 TINYINT(4) DEFAULT 0;
	DECLARE db_sale_item_id INTEGER(11) DEFAULT 0;
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;

	SELECT price,t1.percent,IFNULL(t2.percent,0) INTO db_unit_price,db_tax1,db_tax2 FROM property_unit JOIN taxes t1 ON property_unit.tax1=t1.tax_id LEFT JOIN taxes t2 ON property_unit.tax2=t2.tax_id WHERE prop_unit_id=w_related_id;
	SET db_amount=db_unit_price;

	IF w_type="order" THEN
		SELECT sale_item_id INTO db_sale_item_id FROM sale_order_items WHERE related_to='property_unit' AND related_id=w_related_id AND order_id=w_type_id;
	ELSEIF w_type="invoice" THEN
		SELECT sale_item_id INTO db_sale_item_id FROM sale_order_items WHERE related_to='property_unit' AND related_id=w_related_id AND invoice_id=w_type_id;
	END IF;

	IF db_sale_item_id = 0 THEN
		IF w_type="order" THEN
			INSERT INTO sale_order_items(order_id,related_to,related_id,quantity,unit_price,amount,tax1,tax2) 
			VALUES(w_type_id,'property_unit',w_related_id,1,db_unit_price,db_amount,db_tax1,db_tax2);
		ELSEIF w_type="invoice" THEN
			INSERT INTO sale_order_items(invoice_id,related_to,related_id,quantity,unit_price,amount,tax1,tax2) 
			VALUES(w_type_id,'property_unit',w_related_id,1,db_unit_price,db_amount,db_tax1,db_tax2);
		END IF;
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <= 0 THEN
			SET error=1;
		END IF;
	ELSE
		UPDATE sale_order_items SET unit_price=db_unit_price , amount=db_amount , tax1=db_tax1 , tax2=db_tax2 WHERE sale_item_id=db_sale_item_id;
	END IF;
	IF error=0 THEN
		UPDATE property_unit SET status=1 WHERE prop_unit_id=w_related_id;
	END IF;

	RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `erp_custom_field_update` (`w_cf_id` INT(11), `w_related_id` INT(11), `w_field_value` VARCHAR(255)) RETURNS TINYINT(1)  BEGIN
	DECLARE ret_code TINYINT(1) DEFAULT 0;
	DECLARE d_field_value VARCHAR(255) DEFAULT '';
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	SELECT TRIM(BOTH ' ' FROM field_value) AS field_value INTO d_field_value FROM custom_field_values WHERE cf_id=w_cf_id AND related_id=w_related_id;
	IF d_field_value<>'' THEN
		IF d_field_value=w_field_value THEN
			SET ret_code=2;
		ELSE
			UPDATE custom_field_values SET field_value=w_field_value WHERE cf_id=w_cf_id AND related_id=w_related_id;
			SELECT ROW_COUNT() INTO affected_rows;
			IF affected_rows > 0 THEN
				SET ret_code=1;
			END IF;
		END IF;
	ELSE
		INSERT INTO custom_field_values(cf_id,related_id,field_value) VALUES(w_cf_id,w_related_id,w_field_value) ;
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <> 0 THEN
			SET ret_code=1;
		END IF;
	END IF;
	RETURN ret_code;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `estimate_m_items` (`w_estimate_id` INT(11), `w_related_id` INT(11), `w_quantity` INT(11), `w_price_id` INT(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE db_unit_price DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_tax1 TINYINT(4);
	DECLARE db_tax2 TINYINT(4);
	DECLARE db_est_item_id INTEGER(11) DEFAULT 0;
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;

	SELECT amount,t1.percent,t2.percent INTO db_unit_price,db_tax1,db_tax2 FROM price_list JOIN taxes t1 ON price_list.tax1=t1.tax_id LEFT JOIN taxes t2 ON price_list.tax2=t2.tax_id WHERE price_id=w_price_id;
	SELECT est_item_id INTO db_est_item_id FROM estimate_items WHERE related_to='finished_good' AND related_id=w_related_id AND estimate_id=w_estimate_id;
	SELECT (db_unit_price * w_quantity) INTO db_amount;
	IF db_est_item_id = 0 THEN
		INSERT INTO estimate_items(estimate_id,related_to,related_id,price_id,quantity,unit_price,amount,tax1,tax2) 
		VALUES(w_estimate_id,'finished_good',w_related_id,w_price_id,w_quantity,db_unit_price,db_amount,db_tax1,db_tax2);
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <= 0 THEN
			SET error=1;
		END IF;
	ELSE
		UPDATE estimate_items SET price_id=w_price_id , quantity=w_quantity , unit_price=db_unit_price , amount=db_amount , tax1=db_tax1 , tax2=db_tax2 WHERE est_item_id=db_est_item_id;
	END IF;
	RETURN error;
END$$

CREATE DEFINER=`stagqbs`@`localhost` FUNCTION `finance_automation_delete` (`amount` DECIMAL(14,2), `debit_account` INTEGER(11), `credit_account` INTEGER(11), `narration` TEXT, `created_at` VARCHAR(20), `created_by` INTEGER(11), `related_to` VARCHAR(140), `related_id` INTEGER(11), `auto_posting` TINYINT(1)) RETURNS INT(11) DETERMINISTIC BEGIN
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE debit_id INTEGER(11) DEFAULT 0;
	DECLARE credit_id INTEGER(11) DEFAULT 0;
	DECLARE db_prev_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_trans_date DATE;
	DECLARE diff_amt DECIMAL(14,2) DEFAULT 0.00;
	DECLARE _period DATE;
	
	SELECT amount,prev_amount,transaction_date INTO db_amount,db_prev_amount,db_trans_date FROM journal_entry WHERE related_id=related_id AND related_to=related_to LIMIT 1;
	
	DELETE FROM journal_entry WHERE related_id=related_id AND related_to=related_to;
	SELECT ROW_COUNT() INTO affected_rows;
	IF affected_rows > 0 AND auto_posting = 1 THEN
		SELECT STR_TO_DATE(CONCAT("1",",",MONTH(db_trans_date),',',YEAR(db_trans_date)),"%d,%m,%Y") INTO _period;
		SELECT db_amount INTO diff_amt;
		UPDATE general_ledger SET actual_amt=actual_amt-diff_amt , balance_fwd=balance_fwd-diff_amt WHERE gl_acc_id=debit_id AND DATE(period)=DATE(_period) ;
		UPDATE general_ledger SET balance_fwd=balance_fwd-diff_amt WHERE gl_acc_id=debit_id AND DATE(period) > DATE(_period) ;
		UPDATE general_ledger SET actual_amt=actual_amt+diff_amt , balance_fwd=balance_fwd+diff_amt WHERE gl_acc_id=credit_id AND DATE(period)=DATE(_period) ;
		UPDATE general_ledger SET balance_fwd=balance_fwd+diff_amt WHERE gl_acc_id=credit_id AND DATE(period) > DATE(_period) ;
	END IF;
	
	RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `finance_automation_insert` (`amount` DECIMAL(14,2), `debit_account` INT(11), `credit_account` INT(11), `narration` TEXT, `created_at` VARCHAR(20), `created_by` INT(11), `related_to` VARCHAR(140), `related_id` INT(11), `auto_posting` TINYINT(1)) RETURNS INT(11) DETERMINISTIC BEGIN
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE debit_id INTEGER(11) DEFAULT 0;
	DECLARE credit_id INTEGER(11) DEFAULT 0;
	
	CALL finance_journal_entry(
		amount,
		debit_account ,
		credit_account ,
		narration ,
		created_at ,
		created_by ,
		related_to ,
		related_id ,
		debit_id ,
		credit_id ,
		error
	);
	IF error=1 OR debit_id=0 OR credit_id=0 THEN 
		SET error=1;
	ELSE
		IF auto_posting = 1 THEN 
			CALL finance_journal_insert_post(	
				amount ,
				debit_account ,
				credit_account ,
				debit_id ,
				credit_id ,
				error
			);
		END IF;
	END IF;
	RETURN error;
END$$

CREATE DEFINER=`stagqbs`@`localhost` FUNCTION `finance_automation_update` (`amount` DECIMAL(14,2), `debit_account` INTEGER(11), `credit_account` INTEGER(11), `narration` TEXT, `created_at` VARCHAR(20), `created_by` INTEGER(11), `related_to` VARCHAR(140), `related_id` INTEGER(11), `auto_posting` TINYINT(1)) RETURNS INT(11) DETERMINISTIC BEGIN
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE debit_id INTEGER(11) DEFAULT 0;
	DECLARE credit_id INTEGER(11) DEFAULT 0;
	DECLARE db_prev_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_trans_date DATE;
	DECLARE diff_amt DECIMAL(14,2) DEFAULT 0.00;
	DECLARE _period DATE;
	
	SELECT amount,prev_amount,transaction_date INTO db_amount,db_prev_amount,db_trans_date FROM journal_entry WHERE related_id=related_id AND related_to=related_to LIMIT 1;
	
	UPDATE journal_entry SET amount=amount , prev_amount=db_amount WHERE related_id=related_id AND related_to=related_to;
	SELECT ROW_COUNT() INTO affected_rows;
	IF affected_rows > 0 AND auto_posting = 1 THEN
		SELECT STR_TO_DATE(CONCAT("1",",",MONTH(db_trans_date),',',YEAR(db_trans_date)),"%d,%m,%Y") INTO _period;
		SELECT (db_amount-amount) INTO diff_amt;
		UPDATE general_ledger SET actual_amt=actual_amt-diff_amt , balance_fwd=balance_fwd-diff_amt WHERE gl_acc_id=debit_id AND DATE(period)=DATE(_period) ;
		UPDATE general_ledger SET balance_fwd=balance_fwd-diff_amt WHERE gl_acc_id=debit_id AND DATE(period) > DATE(_period) ;
		UPDATE general_ledger SET actual_amt=actual_amt+diff_amt , balance_fwd=balance_fwd+diff_amt WHERE gl_acc_id=credit_id AND DATE(period)=DATE(_period) ;
		UPDATE general_ledger SET balance_fwd=balance_fwd+diff_amt WHERE gl_acc_id=credit_id AND DATE(period) > DATE(_period) ;
	END IF;
	
	RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `inventory_requisition_insert_update` (`w_req_id` INT(11), `w_related_to` VARCHAR(140), `w_related_id` INT(11), `w_qty` INT(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE ret_code TINYINT(1) DEFAULT 0;
	DECLARE db_invent_req_id INTEGER(11) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	
	SELECT invent_req_id INTO db_invent_req_id FROM inventory_requisition WHERE req_id=w_req_id AND related_to=w_related_to AND related_id=w_related_id;
	IF db_invent_req_id<> 0 THEN
		UPDATE inventory_requisition SET qty=w_qty WHERE invent_req_id=db_invent_req_id;
		SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows > 0 THEN
			SET ret_code=1;
		ELSE
			SET ret_Code=2;
		END IF;
	ELSE
		INSERT INTO inventory_requisition(req_id,related_to,related_id,qty) VALUES(w_req_id,w_related_to,w_related_id,w_qty);
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <> 0 THEN
			SET ret_code=1;
		END IF;
	END IF;
	RETURN ret_code;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `m_sale_order_items` (`w_type` VARCHAR(140), `w_type_id` INT(11), `w_related_id` INT(11), `w_quantity` INT(11), `w_price_id` INT(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE db_unit_price DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_amount DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_tax1 TINYINT(4);
	DECLARE db_tax2 TINYINT(4);
	DECLARE db_sale_item_id INTEGER(11) DEFAULT 0;
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;

	SELECT amount,t1.percent,IFNULL(t2.percent,0) INTO db_unit_price,db_tax1,db_tax2 FROM price_list JOIN taxes t1 ON price_list.tax1=t1.tax_id LEFT JOIN taxes t2 ON price_list.tax2=t2.tax_id WHERE price_id=w_price_id;
	IF w_type="quotation" THEN
		SELECT sale_item_id INTO db_sale_item_id FROM sale_order_items WHERE related_to='finished_good' AND related_id=w_related_id AND quote_id=w_type_id;
	ELSEIF w_type="order" THEN
		SELECT sale_item_id INTO db_sale_item_id FROM sale_order_items WHERE related_to='finished_good' AND related_id=w_related_id AND order_id=w_type_id;
	ELSEIF w_type="invoice" THEN
		SELECT sale_item_id INTO db_sale_item_id FROM sale_order_items WHERE related_to='finished_good' AND related_id=w_related_id AND invoice_id=w_type_id;
	END IF;
	SELECT (db_unit_price * w_quantity) INTO db_amount;
	IF db_sale_item_id = 0 THEN
		IF w_type="quotation" THEN
			INSERT INTO sale_order_items(quote_id,related_to,related_id,price_id,quantity,unit_price,amount,tax1,tax2) 
			VALUES(w_type_id,'finished_good',w_related_id,w_price_id,w_quantity,db_unit_price,db_amount,db_tax1,db_tax2);
		ELSEIF w_type="order" THEN
			INSERT INTO sale_order_items(order_id,related_to,related_id,price_id,quantity,unit_price,amount,tax1,tax2) 
			VALUES(w_type_id,'finished_good',w_related_id,w_price_id,w_quantity,db_unit_price,db_amount,db_tax1,db_tax2);
		ELSEIF w_type="invoice" THEN
			INSERT INTO sale_order_items(invoice_id,related_to,related_id,price_id,quantity,unit_price,amount,tax1,tax2) 
			VALUES(w_type_id,'finished_good',w_related_id,w_price_id,w_quantity,db_unit_price,db_amount,db_tax1,db_tax2);
		END IF;
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <= 0 THEN
			SET error=1;
		END IF;
	ELSE
		UPDATE sale_order_items SET price_id=w_price_id , quantity=w_quantity , unit_price=db_unit_price , amount=db_amount , tax1=db_tax1 , tax2=db_tax2 WHERE sale_item_id=db_sale_item_id;
	END IF;
	RETURN error;
END$$

CREATE DEFINER=`stagqbs`@`localhost` FUNCTION `m_stock_pick` (`w_stock_id` INTEGER(11), `w_qty_to_pick` INTEGER(11), `w_related_id` INTEGER(11), `w_order_id` INTEGER(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	INSERT INTO stock_entry(entry_type,stock_id,qty,order_id,created_at) VALUES(2,w_stock_id,w_qty_to_pick,w_order_id,CURRENT_DATE());
	SELECT LAST_INSERT_ID() INTO insert_id;
	IF insert_id<> 0 THEN
		UPDATE stocks SET quantity=quantity-w_qty_to_pick WHERE stock_id=w_stock_id;
		SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows <= 0 THEN
			SET error=1;
		END IF;
	ELSE
		SET error=1;
	END IF;
	RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `payroll_process` (`w_pay_entry_id` INT(11)) RETURNS TINYINT(1)  BEGIN
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE db_processed TINYINT(1) DEFAULT 0;
	DECLARE db_pay_from DATE;
	DECLARE db_pay_to DATE;

	DECLARE db_employee_id INTEGER(11) DEFAULT 0;
	DECLARE db_total_w_hours INTEGER(11) DEFAULT 0;
	DECLARE db_total_ot_hours INTEGER(11) DEFAULT 0;
	DECLARE db_w_hr_salary DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_ot_hr_salary DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_total_deductions DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_total_additions DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_gross_pay DECIMAL(14,2) DEFAULT 0.00;
	DECLARE db_net_pay DECIMAL(14,2) DEFAULT 0.00;
	DECLARE emp_done INTEGER(11) DEFAULT FALSE;
	DECLARE emp_cursor CURSOR FOR SELECT employees.employee_id,IFNULL((SELECT SUM(work_hours) FROM emp_attendance
	WHERE emp_attendance.employee_id=employees.employee_id AND DATE(rec_date) >= DATE(db_pay_from) AND DATE(rec_date) <= DATE(db_pay_to)),0) AS total_w_hr,IFNULL((SELECT SUM(ot_hours) FROM emp_attendance
	WHERE emp_attendance.employee_id=employees.employee_id AND DATE(rec_date) >= DATE(db_pay_from) AND DATE(rec_date) <= DATE(db_pay_to)),0) AS total_ot_hr,
	w_hr_salary*IFNULL((SELECT SUM(work_hours) FROM emp_attendance WHERE emp_attendance.employee_id=employees.employee_id AND DATE(rec_date) >= DATE(db_pay_from) AND DATE(rec_date) <= DATE(db_pay_to)),0) AS total_w_hr_salary,
	ot_hr_salary*IFNULL((SELECT SUM(ot_hours) FROM emp_attendance WHERE emp_attendance.employee_id=employees.employee_id AND DATE(rec_date) >= DATE(db_pay_from) AND DATE(rec_date) <= DATE(db_pay_to)),0) AS total_ot_hr_salary,
	(SELECT SUM(CASE WHEN type=1 THEN value ELSE (total_w_hr * w_hr_salary) *(value/100) END )  FROM payroll_entry 
	JOIN payroll_additions ON payroll_entry.pay_entry_id=payroll_additions.pay_entry_id 
	JOIN additions ON payroll_additions.add_id=additions.add_id WHERE payroll_entry.pay_entry_id=w_pay_entry_id) AS total_additions,
	(SELECT SUM(CASE WHEN type=1 THEN value ELSE (total_w_hr * w_hr_salary) *(value/100) END )  
	FROM payroll_entry JOIN payroll_deductions ON payroll_entry.pay_entry_id=payroll_deductions.pay_entry_id 
	JOIN deductions ON payroll_deductions.deduct_id=deductions.deduct_id WHERE payroll_entry.pay_entry_id=w_pay_entry_id) AS total_deductions
	FROM employees WHERE employees.status=0 ;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET emp_done=TRUE;

	SELECT payment_from,payment_to,processed INTO db_pay_from,db_pay_to,db_processed FROM payroll_entry WHERE pay_entry_id=w_pay_entry_id;
	IF db_processed = 1 THEN
		SET error=1;
	ELSE 
		OPEN emp_cursor;
		emp_loop: LOOP
			FETCH emp_cursor INTO db_employee_id,db_total_w_hours,db_total_ot_hours,db_w_hr_salary,db_ot_hr_salary,db_total_additions,db_total_deductions ;
			IF emp_done THEN 
				LEAVE emp_loop;
			END IF;
			SELECT (db_w_hr_salary+db_ot_hr_salary) INTO db_gross_pay;
			SELECT (db_gross_pay+db_total_additions-db_total_deductions) INTO db_net_pay;
			INSERT INTO payroll_process(pay_entry_id,employee_id,total_w_hours,total_ot_hours,w_hr_salary,ot_hr_salary,gross_pay,total_additions,total_deductions,net_pay) VALUES(w_pay_entry_id,db_employee_id,db_total_w_hours,db_total_ot_hours,db_w_hr_salary,db_ot_hr_salary,db_gross_pay,db_total_additions,db_total_deductions,db_net_pay) ;
		END LOOP ;
		CLOSE emp_cursor ;
		UPDATE payroll_entry SET processed=1 WHERE pay_entry_id=w_pay_entry_id ;
	END IF;
	RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `project_rawmaterial_insert` (`w_related_id` INT(11), `w_req_qty` INT(11), `w_project_id` INT(11), `w_update` TINYINT(1)) RETURNS TINYINT(1)  BEGIN
	DECLARE db_project_raw_id INTEGER(11) DEFAULT 0;
	DECLARE error TINYINT(1) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;

	SELECT project_raw_id INTO db_project_raw_id FROM project_rawmaterials WHERE project_id=w_project_id AND related_id=w_related_id AND req_for_dispatch=0 ;
	IF db_project_raw_id = 0 THEN
		INSERT INTO project_rawmaterials(related_to,related_id,req_qty,project_id) VALUES('raw_material',w_related_id,w_req_qty,w_project_id) ;
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <= 0 THEN 
			SET error=1;
		END IF;
	ELSE
		IF w_update = 1 THEN
			UPDATE project_rawmaterials SET req_qty=req_qty+w_req_qty WHERE project_raw_id=db_project_raw_id;
		ELSE
			UPDATE project_rawmaterials SET req_qty=w_req_qty WHERE project_raw_id=db_project_raw_id;
		END IF;
		SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows <= 0 THEN
			SET error=1;
		END IF;
	END IF;
	RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `remove_to_stock` (`w_related_to` VARCHAR(140), `w_related_id` INT(11), `w_price_id` INT(11), `w_warehouse_id` INT(11)) RETURNS TINYINT(1)  BEGIN
    DECLARE db_stock_id INTEGER(11) DEFAULT 0;
    DECLARE error TINYINT(1) DEFAULT 0;
    DECLARE affected_rows INTEGER(11) DEFAULT 0;
    
    -- Check if a stock record exists for the given parameters
    SELECT stock_id INTO db_stock_id 
    FROM stocks 
    WHERE related_to = w_related_to 
        AND related_id = w_related_id 
        AND price_id = w_price_id 
        AND warehouse_id = w_warehouse_id;

    -- If a stock record exists
    IF db_stock_id <> 0 THEN
        -- Update the quantity of the existing stock record (decrement by 1, assuming it's a delete operation)
        UPDATE stocks SET quantity = quantity - 1 WHERE stock_id = db_stock_id;

        -- Get the number of affected rows after the update
        SELECT ROW_COUNT() INTO affected_rows;

        -- If no rows were affected, set an error flag
        IF affected_rows <= 0 THEN
            SET error = 1;
        END IF;
    ELSE
        -- If no stock record exists, set an error flag
        SET error = 1;
    END IF;

    -- Return the error flag
    RETURN error;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `selection_rule_segment` (`w_rule_id` INT(11), `w_segment_id` INT(11), `w_above_below` TINYINT(1), `w_exclude` TINYINT(1), `w_segment_value_idx` TINYINT(1)) RETURNS TINYINT(1)  BEGIN
	DECLARE ret_code TINYINT(1) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	DECLARE db_rule_seg_id INTEGER(11) DEFAULT 0;
	
	SELECT rule_seg_id INTO db_rule_seg_id FROM selection_rule_segment WHERE rule_id=w_rule_id AND segment_id=w_segment_id;
	IF db_rule_seg_id<> 0 THEN
		UPDATE selection_rule_segment SET above_below=w_above_below , exclude=w_exclude , segment_value_idx=w_segment_value_idx 
		WHERE rule_seg_id=db_rule_seg_id;
				SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows > 0 THEN
			SET ret_code=1;
		ELSE
			SET ret_Code=2;
		END IF;
	ELSE
		INSERT INTO selection_rule_segment(rule_id,segment_id,above_below,exclude,segment_value_idx) 
		VALUES(w_rule_id,w_segment_id,w_above_below,w_exclude,w_segment_value_idx);
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <> 0 THEN
			SET ret_code=1;
		END IF;
	END IF;
	RETURN ret_code;	
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `supplier_segment_insert_update` (`w_supplier_id` INT(11), `w_segment_json` TEXT) RETURNS TINYINT(1)  BEGIN
	DECLARE ret_code TINYINT(1) DEFAULT 0;
	DECLARE db_supp_seg_id INTEGER(11) DEFAULT 0;
	DECLARE insert_id INTEGER(11) DEFAULT 0;
	DECLARE affected_rows INTEGER(11) DEFAULT 0;
	
	SELECT supp_seg_id INTO db_supp_seg_id FROM supplier_segment_map WHERE supplier_id=w_supplier_id;
	IF db_supp_seg_id<> 0 THEN
		UPDATE supplier_segment_map SET segment_json=w_segment_json WHERE supp_seg_id=db_supp_seg_id;
		SELECT ROW_COUNT() INTO affected_rows;
		IF affected_rows > 0 THEN
			SET ret_code=1;
		END IF;
	ELSE
		INSERT INTO supplier_segment_map(supplier_id,segment_json) VALUES(w_supplier_id,w_segment_json);
		SELECT LAST_INSERT_ID() INTO insert_id;
		IF insert_id <> 0 THEN
			SET ret_code=1;
		END IF;
	END IF;
	RETURN ret_code;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accountbase`
--

CREATE TABLE `accountbase` (
  `base_id` int(11) NOT NULL,
  `base_name` varchar(255) NOT NULL,
  `general_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accountbase`
--

INSERT INTO `accountbase` (`base_id`, `base_name`, `general_name`) VALUES
(1, 'Income', 'revenue'),
(2, 'Overheads', 'expense'),
(3, 'Fixed Assets', 'asset'),
(4, 'Accounts Payable', 'liability'),
(5, 'Accounts Receivable', 'asset'),
(6, 'Current Assets', 'asset');

-- --------------------------------------------------------

--
-- Table structure for table `account_groups`
--

CREATE TABLE `account_groups` (
  `acc_group_id` int(11) NOT NULL,
  `base_id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `profit_loss` tinyint(4) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_groups`
--

INSERT INTO `account_groups` (`acc_group_id`, `base_id`, `group_name`, `profit_loss`, `created_at`, `created_by`) VALUES
(3, 6, 'QBS', 1, '1701952649', 1),
(4, 6, 'softriders', 1, '1702013923', 1),
(8, 1, 'test', 1, '1703764174', 1),
(9, 2, 'Marketing', 1, '1703828104', 1);

-- --------------------------------------------------------

--
-- Table structure for table `additions`
--

CREATE TABLE `additions` (
  `add_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `value` decimal(14,2) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `additions`
--

INSERT INTO `additions` (`add_id`, `name`, `description`, `type`, `value`, `created_at`, `created_by`) VALUES
(1, 'Bonus 1', '', 1, 2000.00, '1651040252', 1),
(2, 'Bonus 2', '', 0, 10.00, '1651040275', 1),
(3, 'T Tax', '5', 1, 5.00, '1703164036', 1);

-- --------------------------------------------------------

--
-- Table structure for table `amenity`
--

CREATE TABLE `amenity` (
  `amenity_id` int(11) NOT NULL,
  `amenity_name` varchar(255) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `amenity`
--

INSERT INTO `amenity` (`amenity_id`, `amenity_name`, `created_at`, `created_by`) VALUES
(1, 'Security', '1648624842', 1),
(2, 'CCTV', '1648624848', 1);

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `attach_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`attach_id`, `filename`, `related_to`, `related_id`) VALUES
(8, 'journal-book.png', 'lead', 3),
(9, 'Nichiyu_files.xlsx', 'lead', 3),
(11, 'TAG_MANPOWER.docx', 'lead', 3),
(12, 'htdocscounter.png', 'lead', 1),
(13, 'htdocscounter.txt', 'lead', 1),
(16, 'Chrysanthemum.jpg', 'request', 1),
(17, 'cat.png', 'request', 1),
(18, 'enquiry_trigger.txt', 'request', 2),
(19, 'KHSSPA.docx', 'raw_material', 2),
(21, 'Desert.jpg', 'raw_material', 2),
(22, 'export.pdf', 'raw_material', 2),
(24, 'harina_sms_templates.docx', 'finished_good', 2),
(36, 'Staff-Details-Form.docx', 'employee', 1),
(38, 'cat.png', 'contractor', 1),
(39, 'Staff-Details-Form.docx', 'contractor', 1),
(40, 'ContractorImport.csv', 'contractor', 3),
(42, 'export.pdf', 'inventory_service', 1),
(46, 'form3.png', 'ticket', 1),
(51, 'Ads.docx', 'sale_order', 1),
(55, 'form2.png', 'sale_invoice', 2),
(58, 'cat.png', 'equipment', 1),
(62, 'export.pdf', 'lead', 1),
(63, 'Ads.docx', 'project_testing', 1),
(64, 'CREXI_TENX.docx', 'project_testing', 1),
(65, 'Staff-Details-Form.docx', 'project', 3),
(89, 'export(1).xlsx', 'raw_material', 24),
(113, 'rsz_whatsapp_image_2023-11-30_at_185343_0b2b413a.jpg', 'project_testing', 4),
(129, 'manageincome.png', 'credit_note', 2),
(137, 'novsales.xlsx', 'property', 4),
(141, 'file-sample_100kB-Copy.docx', 'contractor', 7),
(142, 'novsales.xlsx', 'contractor', 4),
(156, 'WhatsAppImage2023-12-25at15.07.50_d3f71240.jpg', 'employee', 6),
(163, 'ManufacturingERP.pdf', 'sale_invoice', 3),
(164, 'QBrainstormSoftwareManufacturingCompanyERPDoc.pdf', 'sale_invoice', 3),
(170, 'Outlook_Configuration.docx', 'sale_order', 1),
(171, 'ManufacturingERP.pdf', 'estimate', 3),
(172, 'insta.txt', 'quotation', 1),
(173, 'QBrainstormSoftwareManufacturingCompanyERPDoc.pdf', 'estimate', 4),
(174, 'Outlook_Configuration.docx', 'estimate', 22),
(175, 'export(9).xlsx', 'customer', 6),
(182, 'academicyearselectboxvcvrtoldcode.txt', 'quotation', 1),
(183, 'Massinfra-content.docx', 'semi_finished', 2),
(184, 'consulgurususpiciouscode.txt', 'sale_order', 27),
(186, 'cronss.txt', 'sale_invoice', 1),
(189, 'Massinfra-content.docx', 'purchase_invoice', 2),
(192, 'Massinfra-content.docx', 'project', 2),
(193, 'Massinfra-content.docx', 'equipment', 4),
(195, 'Massinfra-content.docx', 'contractor', 9),
(196, 'AttendanceImport.xlsx', 'ticket', 6),
(199, 'export(2).xlsx', 'semi_finished', 12),
(201, 'post2.png', 'rfq', 8),
(204, 'AttendanceImport(3).xlsx', 'employee', 14),
(207, 'Massinfra-content.docx', 'sale_invoice', 39),
(208, 'QbsSeo.txt', 'sale_invoice', 44),
(210, 'export(12).pdf', 'estimate', 35),
(211, 'export(9).pdf', 'quotation', 5),
(212, 'export(9).pdf', 'sale_order', 31),
(217, 'export(9).pdf', 'team', 15),
(218, 'export(8).pdf', 'project_testing', 11),
(220, 'export(6).pdf', 'equipment', 6);

-- --------------------------------------------------------

--
-- Table structure for table `auto_transaction`
--

CREATE TABLE `auto_transaction` (
  `autotrans_id` int(11) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `debit_gl_account` int(11) NOT NULL,
  `credit_gl_account` int(11) NOT NULL,
  `auto_posting` tinyint(1) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auto_transaction`
--

INSERT INTO `auto_transaction` (`autotrans_id`, `trans_id`, `debit_gl_account`, `credit_gl_account`, `auto_posting`, `active`) VALUES
(6, 1, 1, 2, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `auto_trans_list`
--

CREATE TABLE `auto_trans_list` (
  `trans_id` int(11) NOT NULL,
  `transaction_name` varchar(140) NOT NULL,
  `related_to` varchar(140) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auto_trans_list`
--

INSERT INTO `auto_trans_list` (`trans_id`, `transaction_name`, `related_to`) VALUES
(1, 'Marketing Expense', 'marketing');

-- --------------------------------------------------------

--
-- Table structure for table `bankaccounts`
--

CREATE TABLE `bankaccounts` (
  `bank_id` int(11) NOT NULL,
  `gl_acc_id` int(11) NOT NULL,
  `bank_name` varchar(140) NOT NULL,
  `bank_acc_no` varchar(40) NOT NULL DEFAULT '',
  `bank_code` varchar(255) NOT NULL,
  `branch` varchar(140) NOT NULL,
  `address` varchar(500) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bankaccounts`
--

INSERT INTO `bankaccounts` (`bank_id`, `gl_acc_id`, `bank_name`, `bank_acc_no`, `bank_code`, `branch`, `address`, `created_at`, `created_by`) VALUES
(1, 2, 'TKD Bank', '1234567890123', '1234', 'chennai', 'No.164, First Floor, Arcot Rd, Valasaravakkam', '1645264242', 1),
(2, 2, 'State', '1234567890123', '659850', 'chennai', 'No.164, First Floor, Arcot Rd, Valasaravakkam', '1645264266', 1),
(3, 1, 'state', '12454', 'IOB234', 'valasarvakkam', '12', '1703333072', 1),
(4, 15, 'testi', '123', '23', 'test', '12', '1703333140', 1),
(5, 1, 'TKD Bank', '12454', '1234', 'chennai', 'madurai', '1705750080', 1);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(140) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`, `created_at`, `created_by`) VALUES
(1, 'Audi', '1645593031', 1),
(2, 'BMW', '1645593256', 1),
(5, 'KTM', '1703420310', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contractors`
--

CREATE TABLE `contractors` (
  `contractor_id` int(11) NOT NULL,
  `con_code` varchar(140) NOT NULL,
  `name` varchar(140) NOT NULL,
  `contact_person` varchar(140) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_1` varchar(13) NOT NULL,
  `phone_2` varchar(13) NOT NULL,
  `gst_no` varchar(30) NOT NULL,
  `pan_no` varchar(30) NOT NULL,
  `website` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contractors`
--

INSERT INTO `contractors` (`contractor_id`, `con_code`, `name`, `contact_person`, `email`, `phone_1`, `phone_2`, `gst_no`, `pan_no`, `website`, `address`, `city`, `state`, `country`, `zipcode`, `active`, `description`, `created_at`, `created_by`) VALUES
(13, 'CON01', 'Production ', 'test', 'test@gmail.com', '01234567890', '01234567890', '8785657', '744168579663', '', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 1, 'szgseh', '1704176004', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contractor_payments`
--

CREATE TABLE `contractor_payments` (
  `contractor_pay_id` int(11) NOT NULL,
  `project_wgrp_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_on` date NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contractor_payments`
--

INSERT INTO `contractor_payments` (`contractor_pay_id`, `project_wgrp_id`, `payment_id`, `amount`, `paid_on`, `transaction_id`, `notes`) VALUES
(2, 7, 1, 2000.00, '2022-05-05', '', ''),
(3, 7, 1, 1000.00, '2022-05-04', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `credit_items`
--

CREATE TABLE `credit_items` (
  `credit_item_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(14,2) NOT NULL,
  `amount` decimal(14,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credit_items`
--

INSERT INTO `credit_items` (`credit_item_id`, `credit_id`, `related_to`, `related_id`, `qty`, `unit_price`, `amount`) VALUES
(1, 2, 'finished_good', 4, 1, 2000.00, 2000.00),
(2, 3, 'finished_good', 4, 15, 2000.00, 30000.00),
(3, 4, 'finished_good', 4, 1, 2000.00, 2000.00),
(4, 5, 'finished_good', 4, 10, 2000.00, 20000.00),
(5, 6, 'finished_good', 21, 1, 2000.00, 2000.00),
(6, 7, 'finished_good', 22, 12, 3000.00, 36000.00),
(7, 8, 'finished_good', 21, 1, 2000.00, 2000.00),
(8, 8, 'finished_good', 21, 4, 2000.00, 8000.00),
(9, 9, 'finished_good', 21, 1, 120.00, 120.00),
(10, 10, 'finished_good', 21, 1, 2000.00, 2000.00),
(11, 11, 'finished_good', 25, 4, 120.00, 480.00),
(12, 12, 'finished_good', 25, 2, 120.00, 240.00),
(13, 12, 'finished_good', 21, 3, 2000.00, 6000.00),
(14, 13, 'finished_good', 25, 1, 120.00, 120.00),
(15, 14, 'finished_good', 21, 1, 2000.00, 2000.00),
(16, 15, 'finished_good', 25, 1, 120.00, 120.00),
(17, 16, 'finished_good', 22, 12, 3000.00, 36000.00),
(18, 17, 'finished_good', 21, 1, 120.00, 120.00),
(19, 18, 'finished_good', 22, 2, 3000.00, 6000.00),
(20, 19, 'finished_good', 25, 1, 120.00, 120.00),
(21, 20, 'finished_good', 25, 1, 120.00, 120.00);

-- --------------------------------------------------------

--
-- Table structure for table `credit_notes`
--

CREATE TABLE `credit_notes` (
  `credit_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `applied` tinyint(1) NOT NULL DEFAULT 0,
  `issued_date` date NOT NULL,
  `other_charge` decimal(14,2) NOT NULL,
  `applied_amount` int(11) NOT NULL,
  `balance_amount` int(11) NOT NULL,
  `payment_terms` varchar(140) NOT NULL,
  `terms_condition` text NOT NULL,
  `remarks` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credit_notes`
--

INSERT INTO `credit_notes` (`credit_id`, `code`, `cust_id`, `invoice_id`, `applied`, `issued_date`, `other_charge`, `applied_amount`, `balance_amount`, `payment_terms`, `terms_condition`, `remarks`, `created_at`, `created_by`) VALUES
(14, 'C11234', 45, 60, 0, '2024-01-17', 100.00, 75, 25, '20 days', 'okay ', 'fine', '1505588866', 1),
(16, 'Gq123', 38, 0, 0, '2024-01-17', 200.00, 0, 0, 'phone pay', 'okay', 'done', '1705482219', 1),
(18, 'c41', 45, 71, 0, '2024-01-17', 1000.00, 200, 800, '1 day', 'test', 'test', '1705489497', 1),
(20, 'c-3', 46, 60, 0, '2024-01-18', 40.00, 0, 0, '30 day', 'test', 'test', '1705573261', 1),
(26, 'cn9', 45, 71, 0, '2024-01-20', 2000.00, 1150, 850, '12 day', 'fds', 'fdsf', '1705749409', 1),
(30, 'c12', 37, 56, 0, '2024-01-20', 100.00, 100, 0, 'fds', 'ytr', 'ytry', '1705753527', 1),
(31, 'c34', 45, 0, 0, '2024-01-24', 500.00, 0, 0, '1 day', 'fdf', 'fdsf', '1706095990', 1);

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `currency_id` int(11) NOT NULL,
  `iso_code` char(3) NOT NULL,
  `symbol` varchar(20) NOT NULL,
  `decimal_sep` char(1) NOT NULL,
  `thousand_sep` char(1) NOT NULL,
  `place` varchar(10) NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`currency_id`, `iso_code`, `symbol`, `decimal_sep`, `thousand_sep`, `place`, `is_default`, `created_at`, `created_by`) VALUES
(6, 'INR', 'र', '.', ',', 'before', 0, '1704190884', 1),
(8, 'INR', 'र', ',', ',', 'before', 0, '1705642847', 1),
(9, 'UAE', 'د.إ', ',', ',', 'after', 0, '1705642885', 1),
(11, 'UAE', 'د.إ', '.', '', 'before', 0, '1705643125', 1),
(12, 'INR', 'र', '.', ',', 'after', 0, '1705644716', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `cust_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `position` varchar(140) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `fax_num` varchar(11) NOT NULL,
  `office_num` varchar(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `gst` varchar(20) NOT NULL,
  `website` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `remarks` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`cust_id`, `name`, `position`, `address`, `city`, `state`, `country`, `zip`, `email`, `phone`, `fax_num`, `office_num`, `company`, `gst`, `website`, `description`, `remarks`, `created_at`, `created_by`) VALUES
(37, 'admin', 'test', 'test', 'test', 'test', 'test', 'test', 'test@1gmail.com', '9876543210', '', '', 'test company1', '1234', '', '', '', '1645095130', 1),
(38, 'admin2', 'test', 'test', 'test', 'test', 'test', 'test', 'test@2gmail.com', '9876543211', '', '', 'test company2', '1235', '', '\r', '', '1645095130', 1),
(45, 'john', 'web developer', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 'test@gmail.com', '1234567890', '1233554', '4654878554', 'qbs', '5754654466689898', '', 'sdfghdf', 'gdfshsfd', '1704452307', 1),
(46, 'jacob', 'Purchase Manager', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 'jacob@gmail.com', '7845455665', '65454546', '8765446', 'softriders', '535468564', '', 'sdvdf', 'dfgsd', '1704452363', 1),
(47, 'geroge', 'web developer', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 'hrfksj@gmail.com', '8768797887', '896987687', '7984655868', 'Google', '87987897687', '', 'drtytd', 'srthrdh', '1704452430', 1),
(48, 'Production Thamizharasi', 'web developer', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 'tamil@gmail.com', '9578523633', '3253546', '656554', 'qbs', '45666666666', '', 'sfgarg', 'sadgasfg', '1705748532', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_contacts`
--

CREATE TABLE `customer_contacts` (
  `contact_id` int(11) NOT NULL,
  `firstname` varchar(140) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `position` varchar(140) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_contacts`
--

INSERT INTO `customer_contacts` (`contact_id`, `firstname`, `lastname`, `email`, `phone`, `active`, `position`, `cust_id`, `created_at`, `created_by`) VALUES
(1, 'Production', 'jacob', 'admin3@example.com', '9080780700', 0, 'Purchase Manager', 6, '1645002120', 1),
(2, 'Production', 'john', 'admin2@example.com', '9080780700', 1, 'Purchase Manager', 6, '1645002166', 1),
(3, 'Production', 'john', 'admin@example.com', '9080780700', 1, 'Purchase Manager', 6, '1645073995', 1),
(4, 'QBS', 'Support', 'support@qbrainstorm.com', '9080780700', 1, 'werwer', 41, '1703066718', 1),
(5, 'QBS', 'Support', 'support@qbrainstorm.com', '9080780700', 1, 'werwer', 41, '1703066783', 1),
(6, 'Production', 'Thamizharasi', 'test@gmail.com', '1234567890', 1, 'web developer', 6, '1703827099', 1),
(7, 'Production', 'Thamizh', 'test@gmail.com', '1234567890', 1, 'web developer', 7, '1704446817', 1),
(10, 'QBS', 'Support', 'support@qbrainstorm.com', '9080780700', 1, 'DEV', 47, '1704958727', 1),
(11, 'test', 'qbs', 'test1@gmail.com', '1234567890', 1, 'web dev', 45, '1706098930', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_shippingaddr`
--

CREATE TABLE `customer_shippingaddr` (
  `shippingaddr_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_shippingaddr`
--

INSERT INTO `customer_shippingaddr` (`shippingaddr_id`, `address`, `city`, `state`, `country`, `zipcode`, `cust_id`, `created_at`, `created_by`) VALUES
(3, 'No.164, Second Floor, Arcot Rd, Valasaravakkam', 'Chennai', 'Tamil Nadu', 'India', '600087', 6, '1645082553', 1),
(10, 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 6, '1703827150', 1),
(11, 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', 41, '1703828468', 1),
(12, 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 7, '1704447100', 1),
(13, 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 45, '1704453160', 1),
(14, 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', 47, '1704958734', 1);

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `cf_id` int(11) NOT NULL,
  `field_type` varchar(140) NOT NULL,
  `field_related_to` varchar(255) NOT NULL,
  `field_name` varchar(140) NOT NULL,
  `field_options` varchar(255) NOT NULL,
  `required` tinyint(4) NOT NULL,
  `order_num` int(11) NOT NULL,
  `can_be_purged` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custom_fields`
--

INSERT INTO `custom_fields` (`cf_id`, `field_type`, `field_related_to`, `field_name`, `field_options`, `required`, `order_num`, `can_be_purged`) VALUES
(1, 'radio', 'customer', 'Gender', 'Male,Female,Transgender', 1, 2, 0),
(2, 'date', 'proposal', 'Payment Date', '', 1, 3, 1),
(4, 'checkbox', 'customer', 'Type', 'Grade1,Grade2,Grade3', 0, 3, 0),
(5, 'input', 'raw_material', 'Common Name', '', 1, 0, 0),
(6, 'input', 'supplier', 'Concern Name', '', 1, 1, 0),
(7, 'date', 'rfq', 'Created At', '', 1, 1, 0),
(8, 'radio', 'inventory_service', 'Provider', 'Inside,Outside', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_values`
--

CREATE TABLE `custom_field_values` (
  `cfv_id` int(11) NOT NULL,
  `cf_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `field_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custom_field_values`
--

INSERT INTO `custom_field_values` (`cfv_id`, `cf_id`, `related_id`, `field_value`) VALUES
(6, 1, 9, 'FeMale'),
(7, 1, 10, 'Female'),
(10, 1, 12, 'Male'),
(57, 1, 38, 'Male'),
(58, 4, 38, 'Grade1,Grade2'),
(63, 5, 7, 'Test'),
(70, 5, 11, 'Test'),
(73, 5, 13, 'Common'),
(74, 5, 14, 'Common'),
(75, 5, 15, 'Common'),
(86, 1, 31, 'FeMale'),
(87, 1, 32, 'emale'),
(88, 6, 3, 'dcghfyj'),
(89, 6, 4, 'awerhw'),
(91, 6, 6, 'wrewr'),
(92, 6, 7, 'Import'),
(93, 7, 1, '2024-01-09'),
(94, 7, 2, '2024-01-26'),
(95, 8, 1, 'Outside'),
(96, 8, 2, 'Inside'),
(97, 6, 18, 'werwer'),
(98, 6, 19, 'werwer'),
(99, 6, 20, 'Test'),
(100, 6, 21, 'Test 1'),
(101, 6, 24, '234432'),
(102, 6, 25, '234432'),
(103, 6, 26, '234432'),
(104, 6, 27, 'sdfsdf'),
(105, 6, 28, '345345'),
(106, 6, 29, '345345'),
(107, 6, 30, '345345'),
(108, 6, 31, 'Kumar Company'),
(109, 6, 32, '45645'),
(115, 6, 39, '45645'),
(116, 6, 40, '45645'),
(117, 6, 41, '45645'),
(118, 6, 42, '45645'),
(119, 6, 43, '45645'),
(120, 6, 44, '45645'),
(121, 6, 45, '45645'),
(124, 5, 18, 'Test'),
(125, 5, 16, 'Test'),
(126, 5, 25, 'SivaKumar'),
(127, 5, 26, 'rwet'),
(128, 5, 27, 'rwet'),
(129, 5, 28, 'rwet'),
(130, 5, 29, 'rwet'),
(131, 5, 30, 'rwet'),
(132, 5, 31, 'rwet'),
(133, 5, 32, 'rwet'),
(134, 5, 33, 'rwet'),
(135, 5, 34, 'rwet'),
(136, 5, 35, 'rwet'),
(137, 5, 36, 'rwet'),
(138, 5, 37, 'rwet'),
(139, 5, 38, 'rwet'),
(140, 5, 39, 'rwet'),
(141, 5, 40, 'rwet'),
(142, 5, 41, 'rwet'),
(146, 8, 4, 'Outside'),
(147, 5, 2, 'Test'),
(148, 5, 3, 'Test'),
(149, 5, 17, 'Test'),
(150, 5, 20, 'Common'),
(151, 5, 21, 'Common'),
(152, 5, 24, 'SevenSanjay'),
(153, 5, 42, '6456'),
(154, 5, 43, 'SivaKumar'),
(155, 1, 41, 'Male'),
(156, 1, 43, 'Male'),
(157, 4, 43, 'Grade2'),
(158, 1, 44, 'Male'),
(159, 4, 44, 'Grade2'),
(162, 1, 11, 'Female'),
(163, 5, 44, 'dfggdsfgf'),
(165, 8, 5, 'Inside'),
(166, 8, 6, 'Outside'),
(167, 6, 46, '234324'),
(168, 7, 5, '2023-12-26'),
(169, 7, 6, '2023-12-27'),
(170, 1, 6, 'Male'),
(171, 4, 6, 'Grade1'),
(173, 5, 45, 'dfggdsfgf'),
(175, 5, 47, 'setj'),
(176, 5, 46, 'aez6t'),
(178, 5, 49, 'ser'),
(181, 5, 48, 'er7yk'),
(182, 8, 7, 'Inside'),
(183, 6, 47, 'test concern'),
(184, 6, 48, 'jh'),
(185, 5, 50, 'ser'),
(187, 5, 51, 'ser'),
(188, 5, 52, 'awrweth'),
(189, 7, 7, '2023-12-29'),
(191, 5, 53, 'sdfdsf'),
(192, 7, 8, '2023-12-29'),
(193, 7, 9, '2023-12-30'),
(194, 6, 49, 'ERST5UJR5'),
(195, 7, 10, '2023-12-30'),
(196, 6, 50, 'srycfjrs'),
(197, 7, 11, '2023-12-30'),
(198, 7, 12, '2023-12-30'),
(199, 7, 13, '2023-12-30'),
(200, 6, 51, 'esthedthe'),
(201, 6, 52, 'bghkvfg'),
(202, 6, 1, 'awerhw'),
(203, 6, 2, 'dertu'),
(204, 8, 8, 'Inside'),
(205, 8, 9, 'Outside'),
(206, 8, 10, 'Inside'),
(207, 5, 54, 'xdfg'),
(208, 5, 55, 'adrgsh'),
(210, 5, 56, 'awzrhgesh'),
(211, 5, 57, 'sertyhrth'),
(212, 7, 14, '2024-01-02'),
(214, 5, 58, 'sdgr'),
(216, 5, 59, 'dxfzh'),
(220, 5, 61, 'aefgae'),
(222, 5, 62, 'dxhfxg'),
(224, 5, 63, 'Seven Sanjay'),
(225, 5, 64, 'asdfsdf'),
(226, 5, 65, 'sadd'),
(227, 5, 60, 'eharxr'),
(228, 7, 15, '2024-01-03'),
(235, 7, 16, '2024-01-09'),
(237, 5, 66, 'awerg'),
(238, 5, 67, 'aehrst'),
(239, 8, 11, 'Inside'),
(240, 1, 46, 'Male'),
(241, 4, 46, 'Grade2'),
(242, 1, 47, 'Male'),
(243, 4, 47, 'Grade2'),
(245, 1, 48, 'Female'),
(246, 4, 48, 'Grade2'),
(247, 5, 69, 'sdagsag'),
(249, 5, 70, 'fsdgsdfh'),
(250, 8, 12, 'Inside'),
(251, 5, 68, 'asdgasg'),
(252, 6, 5, 'as'),
(253, 1, 37, 'Male'),
(254, 4, 37, 'Grade1,Grade2'),
(255, 1, 45, 'Male'),
(256, 4, 45, 'Grade2');

-- --------------------------------------------------------

--
-- Table structure for table `deductions`
--

CREATE TABLE `deductions` (
  `deduct_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `value` decimal(14,2) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deductions`
--

INSERT INTO `deductions` (`deduct_id`, `name`, `description`, `type`, `value`, `created_at`, `created_by`) VALUES
(1, 'T Tax', 'hello2', 0, 5.00, '1651037240', 1),
(2, 'X Tax', '', 1, 1000.00, '1651037261', 1),
(3, 'QBS ', 'dwsd', 0, 343.00, '1703163194', 1);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_records`
--

CREATE TABLE `delivery_records` (
  `delivery_id` int(11) NOT NULL,
  `transport_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `type` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_records`
--

INSERT INTO `delivery_records` (`delivery_id`, `transport_id`, `related_to`, `related_id`, `status`, `type`) VALUES
(2, 2, 'purchase_order', 2, 2, 0),
(3, 1, 'purchase_order', 1, 2, 0),
(4, 6, 'purchase_order', 3, 2, 0),
(8, 7, 'purchase_order', 26, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `name`, `description`, `created_at`, `created_by`) VALUES
(1, 'Testing', 'Testing Product', '1648194570', 1),
(3, 'Developing', 'Developing product\r\n', '1648194606', 1),
(4, 'Marketing', 'No Department of', '1648197404', 1),
(5, 'Civil', 'Services Department', '1703144707', 1);

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `designation_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`designation_id`, `department_id`, `name`, `description`, `created_at`, `created_by`) VALUES
(1, 4, 'Executive', 'chief executive position 2', '1648199872', 1),
(2, 3, 'Manager', 'Jobs', '1648200065', 1),
(3, 3, 'Domain', '', '1703148468', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dispatch`
--

CREATE TABLE `dispatch` (
  `dispatch_id` int(100) NOT NULL,
  `order_code` varchar(255) NOT NULL,
  `warehouse` varchar(255) NOT NULL,
  `delivery_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `customer` varchar(255) NOT NULL,
  `suppiler_id` int(100) NOT NULL,
  `order_id` int(255) NOT NULL,
  `cust_id` int(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `pick_list_id` int(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dispatch`
--

INSERT INTO `dispatch` (`dispatch_id`, `order_code`, `warehouse`, `delivery_date`, `customer`, `suppiler_id`, `order_id`, `cust_id`, `status`, `pick_list_id`, `description`, `created_at`, `updated_at`) VALUES
(16, 'ghdrfg5868796', '', '2024-01-13 12:15:00', 'geroge', 0, 31, 47, 1, 0, 'asd', '1705140797', '1705140797'),
(19, 'ghdrfg5868796', '', '0000-00-00 00:00:00', 'geroge', 0, 31, 47, 3, 0, 'xgsagr', '1705146617', '1705146617'),
(20, 'ghdrfg5868796', '', '0000-00-00 00:00:00', 'geroge', 0, 31, 47, 0, 0, '', '1705148902', '1705148902'),
(21, 'ghdrfg5868796', '', '2024-01-24 15:15:00', 'geroge', 0, 31, 47, 1, 0, 'zdfhafh', '1705749070', '1705749070'),
(23, 'USAP234', '', '2024-01-22 11:11:00', 'geroge', 0, 36, 47, 2, 0, 'gdfgdf', '1705907263', '1705907263');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `emp_code` varchar(140) NOT NULL,
  `first_name` varchar(140) NOT NULL,
  `last_name` varchar(140) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT 0,
  `joining_date` date NOT NULL,
  `phone_no` varchar(13) NOT NULL,
  `mobile_no` varchar(13) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `marital_status` tinyint(1) NOT NULL DEFAULT 0,
  `blood_group` varchar(5) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `years_of_exp` tinyint(4) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `w_hr_salary` decimal(14,2) NOT NULL,
  `ot_hr_salary` decimal(14,2) NOT NULL,
  `salary` decimal(14,2) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `emp_code`, `first_name`, `last_name`, `designation_id`, `gender`, `joining_date`, `phone_no`, `mobile_no`, `email`, `date_of_birth`, `marital_status`, `blood_group`, `address`, `city`, `state`, `country`, `zipcode`, `qualification`, `years_of_exp`, `status`, `w_hr_salary`, `ot_hr_salary`, `salary`, `created_at`, `created_by`) VALUES
(13, 'EP03', 'test', 'test', 3, 1, '2024-01-10', '1234567890', '', 'support@qbrainstorm.com', '2024-01-16', 0, 'O+', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 'bca', 2, 0, 5210000.00, 55440.00, 747441.00, '1704175462', 1),
(14, 'EP01', 'Raju', 'Kumar', 1, 0, '2024-01-03', '9845612304', '456123789', 'rajukumar@gmail.com', '2024-01-03', 0, 'O+', 'Delete Address2', 'chennai2', 'Tamil Nadu', 'India', '600087', 'MSC', 12, 0, 78000.00, 68000.00, 58000.00, '1704179913', 1),
(15, 'EP02', 'Raju', 'Kumar', 3, 1, '2024-01-05', '9845612302', '', 'raju@gmail.com', '2024-01-03', 1, 'O+', 'Delete Address2', 'chennai2', 'Tamil Nadu', 'India', '600087', 'MSC', 12, 0, 78000.00, 68000.00, 58000.00, '1704197974', 1),
(16, 'EMP005', 'QBS', 'Support', 3, 0, '2024-01-19', '09080780700', '9845612304', 'test@qbrainstorm.com', '2000-04-06', 0, 'O+', 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', 'MSC', 12, 0, 78000.00, 68000.00, 58000.00, '1705663000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `emp_attendance`
--

CREATE TABLE `emp_attendance` (
  `attend_id` bigint(20) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `rec_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `work_hours` tinyint(4) NOT NULL,
  `ot_hours` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emp_attendance`
--

INSERT INTO `emp_attendance` (`attend_id`, `employee_id`, `rec_date`, `status`, `work_hours`, `ot_hours`) VALUES
(1, 1, '2022-04-01', 0, 8, 2),
(2, 2, '2022-04-01', 0, 12, 0),
(3, 13, '2024-01-01', 2, 12, 3),
(4, 13, '2022-01-02', 0, 12, 3),
(5, 2, '2022-04-02', 0, 12, 2),
(6, 3, '2022-04-02', 2, 0, 0),
(7, 13, '2024-01-09', 0, 1, 2),
(8, 13, '2024-01-19', 2, 8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE `equipments` (
  `equip_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `code` varchar(140) NOT NULL,
  `model` varchar(140) NOT NULL,
  `maker` varchar(255) NOT NULL,
  `bought_date` date NOT NULL,
  `age` varchar(140) NOT NULL,
  `work_type` varchar(50) NOT NULL,
  `consump_type` varchar(50) NOT NULL,
  `consumption` varchar(140) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equip_id`, `name`, `code`, `model`, `maker`, `bought_date`, `age`, `work_type`, `consump_type`, `consumption`, `status`, `description`, `created_at`, `created_by`, `updated_at`) VALUES
(1, 'test', 'EQ123', 'ABC-0001', 'test', '2022-03-27', '', 'Manual', 'Electric', '', 0, 'hello', '1650267326', 1, ''),
(4, 'test', 'EQ125', 'ABC-0069', 'test', '2022-04-02', '', 'Manual', 'Fuel', '4', 2, 'hello', '1650267407', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `erp_groups`
--

CREATE TABLE `erp_groups` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `related_to` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_groups`
--

INSERT INTO `erp_groups` (`group_id`, `group_name`, `related_to`) VALUES
(1, 'Construction', 'customer'),
(4, 'International', 'customer'),
(5, 'VIP', 'customer'),
(8, 'Domestic', 'customer'),
(9, 'Grade A', 'raw_material'),
(10, 'Grade B', 'raw_material'),
(11, 'Grade A', 'semi_finished'),
(12, 'Grade B', 'semi_finished'),
(13, 'Grade A', 'finished_good'),
(14, 'Grade B', 'finished_good'),
(15, 'Domestic', 'expense'),
(16, 'Supplier G1', 'supplier'),
(17, 'Supplier G2', 'supplier'),
(19, 'Serv B', 'inventory_service'),
(23, 'test', 'supplier');

-- --------------------------------------------------------

--
-- Table structure for table `erp_groups_map`
--

CREATE TABLE `erp_groups_map` (
  `groupmap_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_groups_map`
--

INSERT INTO `erp_groups_map` (`groupmap_id`, `group_id`, `related_id`) VALUES
(10, 4, 7),
(19, 4, 8),
(20, 5, 8),
(21, 5, 9),
(22, 8, 9),
(23, 5, 10),
(26, 4, 12),
(91, 5, 38),
(92, 4, 38),
(96, 17, 4),
(101, 16, 6),
(102, 17, 7),
(103, 16, 7),
(127, 17, 20),
(128, 16, 21),
(130, 1, 24),
(131, 0, 24),
(132, 234234, 24),
(133, 0, 24),
(134, 234324, 24),
(135, 0, 24),
(136, 0, 24),
(137, 0, 24),
(138, 2147483647, 24),
(139, 0, 24),
(140, 0, 24),
(141, 600087, 24),
(142, 0, 24),
(143, 0, 24),
(144, 0, 24),
(145, 234324, 24),
(146, 3423, 24),
(147, 23434, 24),
(148, 1, 24),
(149, 1, 25),
(150, 0, 25),
(151, 234234, 25),
(152, 0, 25),
(153, 234324, 25),
(154, 0, 25),
(155, 0, 25),
(156, 0, 25),
(157, 2147483647, 25),
(158, 0, 25),
(159, 0, 25),
(160, 600087, 25),
(161, 0, 25),
(162, 0, 25),
(163, 0, 25),
(164, 234324, 25),
(165, 0, 25),
(166, 0, 25),
(167, 1, 25),
(168, 1, 26),
(169, 0, 26),
(170, 234234, 26),
(171, 0, 26),
(172, 234324, 26),
(173, 0, 26),
(174, 0, 26),
(175, 0, 26),
(176, 2147483647, 26),
(177, 0, 26),
(178, 0, 26),
(179, 600087, 26),
(180, 0, 26),
(181, 0, 26),
(182, 0, 26),
(183, 234324, 26),
(184, 234234, 26),
(185, 234234, 26),
(186, 1, 26),
(187, 1, 27),
(188, 0, 27),
(189, 0, 27),
(190, 0, 27),
(191, 0, 27),
(192, 0, 27),
(193, 0, 27),
(194, 0, 27),
(195, 908078070, 27),
(196, 0, 27),
(197, 0, 27),
(198, 600087, 27),
(199, 0, 27),
(200, 0, 27),
(201, 0, 27),
(202, 234324, 27),
(203, 0, 27),
(204, 0, 27),
(205, 1, 27),
(206, 16, 3),
(207, 1, 28),
(208, 0, 28),
(209, 0, 28),
(210, 0, 28),
(211, 345345, 28),
(212, 0, 28),
(213, 0, 28),
(214, 0, 28),
(215, 2147483647, 28),
(216, 0, 28),
(217, 345345, 28),
(218, 600087, 28),
(219, 345345, 28),
(220, 345345, 28),
(221, 0, 28),
(222, 345345, 28),
(223, 0, 28),
(224, 0, 28),
(225, 1, 28),
(226, 1, 29),
(227, 0, 29),
(228, 0, 29),
(229, 0, 29),
(230, 345345, 29),
(231, 0, 29),
(232, 0, 29),
(233, 0, 29),
(234, 2147483647, 29),
(235, 0, 29),
(236, 345345, 29),
(237, 600087, 29),
(238, 345345, 29),
(239, 345345, 29),
(240, 0, 29),
(241, 345345, 29),
(242, 0, 29),
(243, 0, 29),
(244, 1, 29),
(245, 1, 30),
(246, 0, 30),
(247, 0, 30),
(248, 0, 30),
(249, 345345, 30),
(250, 0, 30),
(251, 0, 30),
(252, 0, 30),
(253, 2147483647, 30),
(254, 0, 30),
(255, 345345, 30),
(256, 600087, 30),
(257, 345345, 30),
(258, 345345, 30),
(259, 0, 30),
(260, 345345, 30),
(261, 0, 30),
(262, 0, 30),
(263, 1, 30),
(264, 17, 31),
(265, 1, 32),
(266, 0, 32),
(267, 456456, 32),
(268, 0, 32),
(269, 456456, 32),
(270, 0, 32),
(271, 0, 32),
(272, 0, 32),
(273, 2147483647, 32),
(274, 0, 32),
(275, 0, 32),
(276, 600087, 32),
(277, 4456456, 32),
(278, 456456, 32),
(279, 0, 32),
(280, 456456, 32),
(281, 0, 32),
(282, 0, 32),
(283, 1, 32),
(296, 16, 39),
(297, 17, 39),
(298, 17, 40),
(299, 16, 40),
(300, 17, 41),
(301, 16, 42),
(302, 17, 43),
(303, 17, 44),
(304, 17, 45),
(305, 5, 41),
(306, 8, 43),
(307, 5, 43),
(308, 4, 43),
(309, 1, 43),
(310, 8, 44),
(311, 5, 44),
(312, 4, 44),
(313, 1, 44),
(316, 5, 11),
(317, 17, 46),
(318, 5, 6),
(319, 8, 6),
(320, 16, 47),
(321, 16, 48),
(322, 17, 49),
(323, 23, 50),
(324, 16, 51),
(325, 16, 52),
(326, 17, 1),
(327, 17, 2),
(331, 4, 46),
(332, 8, 47),
(333, 5, 48),
(334, 17, 5),
(335, 5, 37),
(336, 4, 37),
(337, 1, 37),
(338, 4, 45),
(339, 8, 45);

-- --------------------------------------------------------

--
-- Table structure for table `erp_jobqueue`
--

CREATE TABLE `erp_jobqueue` (
  `job_id` int(11) NOT NULL,
  `job_name` varchar(255) NOT NULL,
  `job_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `attempt` tinyint(4) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `priority` tinyint(4) NOT NULL DEFAULT 0,
  `run_at` varchar(20) NOT NULL,
  `system` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_jobqueue`
--

INSERT INTO `erp_jobqueue` (`job_id`, `job_name`, `job_params`, `attempt`, `status`, `priority`, `run_at`, `system`) VALUES
(1, 'notify', '{\"notify_id\":20}', 3, 5, 3, '1702256760', 0),
(2, 'notify', '{\"notify_id\":21}', 3, 5, 3, '1702576980', 0),
(3, 'notify', '{\"notify_id\":22}', 3, 5, 3, '1703074140', 0),
(4, 'notify', '{\"notify_id\":23}', 3, 5, 3, '1703074620', 0),
(5, 'notify', '{\"notify_id\":24}', 3, 5, 3, '1703082360', 0),
(6, 'notify', '{\"notify_id\":25}', 3, 5, 3, '1703428380', 0),
(9, 'notify', '{\"notify_id\":28}', 3, 5, 3, '1703087460', 0),
(10, 'notify', '{\"notify_id\":29}', 3, 5, 3, '1703524560', 0),
(11, 'notify', '{\"notify_id\":30}', 3, 5, 3, '1703524560', 0),
(12, 'notify', '{\"notify_id\":31}', 3, 5, 3, '1703591520', 0),
(13, 'notify', '{\"notify_id\":32}', 3, 5, 3, '1703594340', 0),
(14, 'notify', '{\"notify_id\":33}', 3, 5, 3, '1703594340', 0),
(15, 'notify', '{\"notify_id\":34}', 3, 5, 3, '1703594340', 0),
(16, 'notify', '{\"notify_id\":35}', 3, 5, 3, '1703594340', 0),
(17, 'notify', '{\"notify_id\":36}', 3, 5, 3, '1703595780', 0),
(18, 'notify', '{\"notify_id\":37}', 3, 5, 3, '1703509920', 0),
(22, 'notify', '{\"notify_id\":\"19\"}', 3, 5, 3, '1651901160', 0),
(23, 'notify', '{\"notify_id\":40}', 3, 5, 3, '1703714040', 0),
(28, 'notify', '{\"notify_id\":45}', 3, 5, 3, '1701724080', 0),
(29, 'notify', '{\"notify_id\":46}', 3, 5, 3, '1703195460', 0),
(32, 'rfqsend', '{\"supp_rfq_id\":\"5\"}', 3, 5, 3, '1703673627', 0),
(34, 'rfqsend', '{\"supp_rfq_id\":\"5\"}', 3, 5, 3, '1703677637', 0),
(40, 'notify', '{\"notify_id\":\"15\"}', 3, 5, 3, '1651931400', 0),
(41, 'notify', '{\"notify_id\":\"49\"}', 3, 5, 3, '1703782500', 0),
(42, 'notify', '{\"notify_id\":54}', 3, 5, 3, '1703871840', 0),
(44, 'notify', '{\"notify_id\":56}', 3, 5, 3, '1703891220', 0),
(45, 'notify', '{\"notify_id\":57}', 3, 5, 3, '1702501560', 0),
(46, 'notify', '{\"notify_id\":58}', 3, 5, 3, '1702328760', 0),
(49, 'notify', '{\"notify_id\":\"59\"}', 3, 5, 3, '1703891580', 0),
(50, 'notify', '{\"notify_id\":60}', 3, 5, 3, '1703200800', 0),
(51, 'notify', '{\"notify_id\":61}', 3, 5, 3, '1703719740', 0),
(53, 'notify', '{\"notify_id\":63}', 3, 5, 3, '1703547120', 0),
(54, 'notify', '{\"notify_id\":64}', 3, 5, 3, '1703111520', 0),
(56, 'notify', '{\"notify_id\":65}', 3, 5, 3, '1703759940', 0),
(57, 'notify', '{\"notify_id\":66}', 3, 5, 3, '1703846400', 0),
(61, 'notify', '{\"notify_id\":68}', 3, 5, 3, '1703934480', 0),
(62, 'notify', '{\"notify_id\":69}', 3, 5, 3, '1703934600', 0),
(63, 'notify', '{\"notify_id\":70}', 3, 5, 3, '1704021360', 0),
(65, 'notify', '{\"notify_id\":\"71\"}', 3, 5, 3, '1703848800', 0),
(67, 'notify', '{\"notify_id\":73}', 3, 5, 3, '1703935380', 0),
(69, 'notify', '{\"notify_id\":74}', 3, 5, 3, '1703936160', 0),
(70, 'notify', '{\"notify_id\":75}', 3, 5, 3, '1703849760', 0),
(72, 'notify', '{\"notify_id\":\"76\"}', 3, 5, 3, '1703849880', 0),
(73, 'notify', '{\"notify_id\":77}', 3, 5, 3, '1703997600', 0),
(77, 'notify', '{\"notify_id\":80}', 3, 5, 3, '1701724080', 0),
(80, 'notify', '{\"notify_id\":\"81\"}', 3, 5, 3, '1703851500', 0),
(81, 'notify', '{\"notify_id\":82}', 3, 5, 3, '1703701020', 0),
(82, 'notify', '{\"notify_id\":83}', 3, 5, 3, '1703873880', 0),
(83, 'notify', '{\"notify_id\":84}', 3, 5, 3, '1703877480', 0),
(84, 'notify', '{\"notify_id\":85}', 3, 5, 3, '1703960400', 0),
(85, 'notify', '{\"notify_id\":86}', 3, 5, 3, '1703704860', 0),
(86, 'notify', '{\"notify_id\":87}', 3, 5, 3, '1703946960', 0),
(87, 'notify', '{\"notify_id\":88}', 3, 5, 3, '1703947620', 0),
(88, 'notify', '{\"notify_id\":89}', 3, 5, 3, '1703948040', 0),
(89, 'notify', '{\"notify_id\":90}', 3, 5, 3, '1703948460', 0),
(90, 'notify', '{\"notify_id\":91}', 3, 5, 3, '1703948460', 0),
(91, 'notify', '{\"notify_id\":92}', 3, 5, 3, '1703948520', 0),
(92, 'notify', '{\"notify_id\":93}', 3, 5, 3, '1703948580', 0),
(93, 'notify', '{\"notify_id\":94}', 3, 5, 3, '1703948640', 0),
(94, 'notify', '{\"notify_id\":95}', 3, 5, 3, '1703950320', 0),
(95, 'notify', '{\"notify_id\":96}', 3, 5, 3, '1703869680', 0),
(96, 'rfqsend', '{\"supp_rfq_id\":\"14\"}', 3, 5, 3, '1704172781', 0),
(97, 'rfqsend', '{\"supp_rfq_id\":\"14\"}', 3, 5, 3, '1704173222', 0),
(98, 'rfqsend', '{\"supp_rfq_id\":\"14\"}', 3, 5, 3, '1704173395', 0),
(99, 'notify', '{\"notify_id\":97}', 3, 5, 3, '1704196260', 0),
(100, 'rfqsend', '{\"supp_rfq_id\":\"14\"}', 3, 5, 3, '1704188744', 0),
(102, 'notify', '{\"notify_id\":99}', 3, 5, 3, '1704265140', 0),
(103, 'notify', '{\"notify_id\":100}', 3, 5, 3, '1704378240', 0),
(104, 'notify', '{\"notify_id\":101}', 3, 5, 3, '1704470760', 0),
(105, 'notify', '{\"notify_id\":102}', 3, 5, 3, '1704986580', 0),
(106, 'notify', '{\"notify_id\":103}', 3, 5, 3, '1704986580', 0),
(107, 'notify', '{\"notify_id\":104}', 3, 5, 3, '1704904380', 0),
(108, 'notify', '{\"notify_id\":105}', 3, 5, 3, '1705166940', 0),
(109, 'notify', '{\"notify_id\":106}', 3, 5, 3, '1704477000', 0),
(113, 'notify', '{\"notify_id\":\"107\"}', 3, 5, 3, '1704550260', 0),
(114, 'rfqsend', '{\"supp_rfq_id\":\"1\"}', 3, 5, 3, '1704777800', 0),
(116, 'notify', '{\"notify_id\":111}', 3, 5, 3, '1704847200', 0),
(117, 'notify', '{\"notify_id\":112}', 3, 5, 3, '1704937380', 0),
(119, 'notify', '{\"notify_id\":114}', 3, 5, 3, '1705583460', 0),
(120, 'rfqsend', '{\"supp_rfq_id\":\"1\"}', 3, 5, 3, '1704970930', 0),
(121, 'rfqsend', '{\"supp_rfq_id\":\"1\"}', 3, 5, 3, '1705057291', 0),
(122, 'notify', '{\"notify_id\":115}', 3, 5, 3, '1705573680', 0),
(123, 'rfqsend', '{\"supp_rfq_id\":\"1\"}', 3, 5, 3, '1705743775', 0),
(124, 'rfqsend', '{\"supp_rfq_id\":\"1\"}', 3, 5, 3, '1705743787', 0),
(129, 'notify', '{\"notify_id\":118}', 3, 5, 3, '1706129040', 0),
(130, 'notify', '{\"notify_id\":119}', 3, 5, 3, '1706028540', 0),
(131, 'notify', '{\"notify_id\":120}', 3, 5, 3, '1706119920', 0),
(132, 'notify', '{\"notify_id\":121}', 3, 5, 3, '1706206380', 0),
(134, 'notify', '{\"notify_id\":123}', 3, 5, 3, '1706119440', 0),
(135, 'notify', '{\"notify_id\":\"122\"}', 3, 5, 3, '1706205420', 0);

-- --------------------------------------------------------

--
-- Table structure for table `erp_log`
--

CREATE TABLE `erp_log` (
  `log_id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `log_text` text NOT NULL,
  `ref_link` varchar(255) NOT NULL,
  `additional_info` varchar(1000) DEFAULT NULL,
  `done_by` varchar(120) NOT NULL,
  `created_at` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_log`
--

INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(1, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplierview/3', NULL, 'Admin', '1702030129'),
(2, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplierview/3', NULL, 'Admin', '1702030198'),
(3, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702030402'),
(4, 'GL Account Import', '[ GL Account successfully imported ]', '', NULL, 'Admin', '1702031806'),
(5, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702032309'),
(6, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702032884'),
(7, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702032890'),
(8, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702032907'),
(9, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033451'),
(10, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033458'),
(11, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033473'),
(12, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033615'),
(13, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033632'),
(14, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033703'),
(15, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702033888'),
(16, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702034094'),
(17, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702034098'),
(18, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702034110'),
(19, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702034164'),
(20, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', NULL, 'Admin', '1702034216'),
(21, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702034839'),
(22, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702034851'),
(23, 'Supplier Update', '[ Supplier failed to update ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702034929'),
(24, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702035679'),
(25, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702035745'),
(26, 'Equipment Deletion', '[ Equipment successfully deleted ]', 'erp/asset/equipments', '{\"equip_id\":\"3\",\"name\":\"Nottu\",\"code\":\"54\",\"model\":\"126\",\"maker\":\"4654\",\"bought_date\":\"2023-12-07\",\"age\":\"1421\",\"work_type\":\"Automatic\",\"consump_type\":\"Electric\",\"consumption\":\"5\",\"status\":\"0\",\"description\":\"aqwss\",\"created_at\":\"2023-12-08 08:42:43\",\"created_by\":\"1\",\"updated_at\":\"2023-12-08 08:42:43\"}', 'Admin', '1702035833'),
(27, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702035845'),
(28, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '1702035914'),
(29, 'Equipment Deletion', '[ Equipment successfully deleted ]', 'erp/asset/equipments', '{\"equip_id\":\"3\",\"name\":\"Nottu\",\"code\":\"54\",\"model\":\"126\",\"maker\":\"4654\",\"bought_date\":\"2023-12-07\",\"age\":\"1421\",\"work_type\":\"Automatic\",\"consump_type\":\"Electric\",\"consumption\":\"5\",\"status\":\"0\",\"description\":\"aqwss\",\"created_at\":\"2023-12-08 08:42:43\",\"created_by\":\"1\",\"updated_at\":\"2023-12-08 08:42:43\"}', 'Admin', '1702036146'),
(30, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '1702036203'),
(31, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '1702036253'),
(32, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-08 12:44:34'),
(33, 'Warehouse Insert', '[ Warehouse successfully created ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-08 12:45:04'),
(34, 'Warehouse Insert', '[ Warehouse successfully created ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-08 12:46:58'),
(35, 'Warehouse Insert', '[ Warehouse successfully created ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-08 12:48:47'),
(36, 'Warehouse Insert', '[ Warehouse successfully created ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-08 12:52:45'),
(37, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-08 13:02:20'),
(38, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-08 13:09:30'),
(39, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-08 13:09:58'),
(40, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-08 13:14:22'),
(41, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-08 13:23:01'),
(42, 'Supplier Import', '[ Supplier successfully imported ]', '', '', 'Admin', '2023-12-08 13:25:47'),
(43, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-08 13:29:03'),
(44, 'Equipment Update', '[ Equipment successfully updated ]', 'erp/asset/edit_equipment/4', '', 'Admin', '2023-12-08 13:37:02'),
(45, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-08 13:43:41'),
(46, 'GL Account Delete', '[ GL Account successfully deleted ]', 'erp/finance/glaccounts/', '', 'Admin', '2023-12-08 13:58:28'),
(47, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-09 04:54:06'),
(48, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-09 04:56:38'),
(49, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-09 04:57:45'),
(50, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-09 05:55:48'),
(51, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 05:56:07'),
(52, 'Warehouse Update', '[ Warehouse failed to update ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 05:56:34'),
(53, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 05:57:00'),
(54, 'Supplier Contact Update', '[ Supplier Contact failed to update ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:00:13'),
(55, 'Supplier Contact Update', '[ Supplier Contact successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:00:32'),
(56, 'Supplier Contact Update', '[ Supplier Contact successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:01:16'),
(57, 'Warehouse Insert', '[ Warehouse successfully created ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:05:55'),
(58, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:06:54'),
(59, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:12:11'),
(60, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:13:19'),
(61, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:13:48'),
(62, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:16:20'),
(63, 'Warehouse Update', '[ Warehouse failed to update ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 06:16:34'),
(64, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:47:32'),
(65, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:48:12'),
(66, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:48:29'),
(67, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 06:54:56'),
(68, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-09 08:47:53'),
(69, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 08:52:07'),
(70, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:01:12'),
(71, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:01:36'),
(72, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:04:29'),
(73, 'GL Account Import', '[ GL Account partially imported ]', '', '', 'Admin', '2023-12-09 09:09:13'),
(74, 'GL Account Import', '[ GL Account partially imported ]', '', '', 'Admin', '2023-12-09 09:12:32'),
(75, 'GL Account Import', '[ GL Account partially imported ]', '', '', 'Admin', '2023-12-09 09:16:44'),
(76, 'GL Account Import', '[ GL Account partially imported ]', '', '', 'Admin', '2023-12-09 09:19:10'),
(77, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:27:38'),
(78, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:29:52'),
(79, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:31:24'),
(80, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:32:11'),
(81, 'GL Account Import', '[ GL Account failed to import ]', '', '', 'Admin', '2023-12-09 09:37:33'),
(82, 'GL Account Import', '[ GL Account failed to import ]', '', '', 'Admin', '2023-12-09 09:38:10'),
(83, 'GL Account Import', '[ GL Account failed to import ]', '', '', 'Admin', '2023-12-09 09:38:47'),
(84, 'GL Account Import', '[ GL Account failed to import ]', '', '', 'Admin', '2023-12-09 09:39:26'),
(85, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:40:04'),
(86, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:40:24'),
(87, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:40:51'),
(88, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:46:00'),
(89, 'GL Account Import', '[ GL Account successfully imported ]', '', '', 'Admin', '2023-12-09 09:49:32'),
(90, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:51:37'),
(91, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 09:53:00'),
(92, 'GL Account Update', '[ GL Account successfully updated ]', 'erp/finance/glaccounts/', '', 'Admin', '2023-12-09 09:55:31'),
(93, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-09 10:09:28'),
(94, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 10:10:03'),
(95, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 10:12:18'),
(96, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 10:13:50'),
(97, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 10:19:59'),
(98, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 10:34:26'),
(99, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:08:49'),
(100, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:09:07'),
(101, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:09:21'),
(102, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:09:39'),
(103, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:09:58'),
(104, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:10:32'),
(105, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:20:19'),
(106, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:21:28'),
(107, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:26:01'),
(108, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:32:08'),
(109, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:32:40'),
(110, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:33:47'),
(111, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:34:05'),
(112, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:34:58'),
(113, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Admin', '2023-12-09 11:35:21'),
(114, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-09 11:35:42'),
(115, 'Warehouse Insert', '[ Warehouse successfully created]', 'erp/warehouse/warehouses', '', 'Admin', '2023-12-09 11:36:10'),
(116, 'Supplier Import', '[ Supplier successfully imported ]', '', '', 'Admin', '2023-12-09 11:44:53'),
(117, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete10', '{\"warehouse_id\":\"10\",\"name\":\"sagana\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"1\",\"description\":\"uykf\",\"aisle_count\":\"85\",\"racks_per_aisle\":\"87\",\"shelf_per_rack\":\"7\",\"bins_per_shelf\":\"87\"}', 'Admin', '2023-12-09 11:54:17'),
(118, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete5', '{\"warehouse_id\":\"5\",\"name\":\"ashok\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"0\",\"description\":\"\",\"aisle_count\":\"0\",\"racks_per_aisle\":\"0\",\"shelf_per_rack\":\"0\",\"bins_per_shelf\":\"0\"}', 'Admin', '2023-12-09 11:55:19'),
(119, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete12', '{\"warehouse_id\":\"12\",\"name\":\"Thamizharasi\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"1\",\"description\":\"srhnsh\",\"aisle_count\":\"44\",\"racks_per_aisle\":\"45\",\"shelf_per_rack\":\"635\",\"bins_per_shelf\":\"55\"}', 'Admin', '2023-12-09 11:55:27'),
(120, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-09 11:58:25'),
(121, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-09 12:50:34'),
(122, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-09 12:51:29'),
(123, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/4', '', 'Admin', '2023-12-09 12:57:44'),
(124, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/4', '', 'Admin', '2023-12-09 12:57:54'),
(125, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 05:04:28'),
(126, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/21', '', 'Admin', '2023-12-10 05:09:03'),
(127, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/21', '', 'Admin', '2023-12-10 05:09:30'),
(128, 'Supplier Contact Update', '[ Supplier Contact successfully updated ]', 'erp/supplier/supplier-view/21', '', 'Admin', '2023-12-10 05:09:42'),
(129, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 05:10:31'),
(130, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 06:06:24'),
(131, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 06:17:39'),
(132, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 07:01:25'),
(133, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-10 07:02:39'),
(134, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 08:35:12'),
(135, 'Supplier Source Insert', '[ Supplier Source successfully created ]', 'erp/supplier/sources', '', 'Admin', '2023-12-10 08:37:14'),
(136, 'Supplier Source Insert', '[ Supplier Source successfully created ]', 'erp/supplier/sources', '', 'Admin', '2023-12-10 08:37:34'),
(137, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 08:43:46'),
(138, 'Supplier Source Delete', '[ Supplier Source successfully deleted ]', '', '', 'Admin', '2023-12-10 08:45:31'),
(139, 'Supplier Source Delete', '[ Supplier Source successfully deleted ]', '', '', 'Admin', '2023-12-10 08:45:37'),
(140, 'Supplier Source Update', '[ Supplier Source successfully updated ]', 'erp/supplier/sources', '', 'Admin', '2023-12-10 08:57:29'),
(141, 'Supplier Source Update', '[ Supplier Source successfully updated ]', 'erp/supplier/sources', '', 'Admin', '2023-12-10 08:57:46'),
(142, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 09:29:58'),
(143, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 09:38:47'),
(144, 'Supplier Segment Update', '[ Supplier Segment successfully updated ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 09:41:33'),
(145, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 10:01:37'),
(146, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 10:02:00'),
(147, 'Supplier Segment Update', '[ Supplier Segment successfully updated ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 10:03:02'),
(148, 'Supplier Segment Update', '[ Supplier Segment successfully updated ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 10:03:19'),
(149, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 10:06:15'),
(150, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'Admin', '2023-12-10 10:07:09'),
(151, 'Selection Rule Insert', '[ Selection Rule successfully created ]', '', '', 'Admin', '2023-12-10 10:54:41'),
(152, 'Selection Rule Update', '[ Selection Rule successfully updated ]', '', '', 'Admin', '2023-12-10 10:57:17'),
(153, 'Selection Rule Update', '[ Selection Rule successfully updated ]', '', '', 'Admin', '2023-12-10 10:57:35'),
(154, 'Selection Rule Insert', '[ Selection Rule successfully created ]', '', '', 'Admin', '2023-12-10 10:58:18'),
(155, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:08:51'),
(156, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:09:00'),
(157, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:10:00'),
(158, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:11:37'),
(159, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/2', '', 'Admin', '2023-12-10 11:12:27'),
(160, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:25:35'),
(161, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:32:00'),
(162, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 11:34:02'),
(163, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 11:34:21'),
(164, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:34:33'),
(165, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 11:35:26'),
(166, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/40', '', 'Admin', '2023-12-10 11:40:13'),
(167, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/40', '', 'Admin', '2023-12-10 11:40:36'),
(168, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/40', '', 'Admin', '2023-12-10 11:40:50'),
(169, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/40', '', 'Admin', '2023-12-10 11:40:58'),
(170, 'GRN Update', '[ GRN failed to update ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:49:44'),
(171, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 11:57:28'),
(172, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 12:00:54'),
(173, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-10 12:02:15'),
(174, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-10 12:44:47'),
(175, 'Supplier Contact Update', '[ Supplier Contact successfully updated ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 12:58:56'),
(176, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 12:59:07'),
(177, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 12:59:22'),
(178, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/41', '', 'Admin', '2023-12-10 12:59:41'),
(179, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-10 13:29:06'),
(180, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-10 13:30:00'),
(181, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-10 13:36:54'),
(182, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 05:03:02'),
(183, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 05:11:37'),
(184, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 05:14:37'),
(185, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/31', '', 'Admin', '2023-12-11 05:47:47'),
(186, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/31', '', 'Admin', '2023-12-11 05:47:52'),
(187, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/31', '', 'Admin', '2023-12-11 05:48:04'),
(188, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/31', '', 'Admin', '2023-12-11 05:48:16'),
(189, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/21', '', 'Admin', '2023-12-11 05:55:42'),
(190, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/21', '', 'Admin', '2023-12-11 06:12:04'),
(191, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/21', '', 'Admin', '2023-12-11 06:13:26'),
(192, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Admin', '2023-12-11 06:13:53'),
(193, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/45', '', 'Admin', '2023-12-11 06:14:05'),
(194, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/45', '', 'Admin', '2023-12-11 06:14:10'),
(195, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/45', '', 'Admin', '2023-12-11 06:14:23'),
(196, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/45', '', 'Admin', '2023-12-11 06:14:34'),
(197, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 06:27:07'),
(198, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 07:38:49'),
(199, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 11:23:22'),
(200, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 11:33:33'),
(201, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 11:37:11'),
(202, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 12:55:55'),
(203, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-11 13:28:34'),
(204, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Admin', '2023-12-11 13:35:15'),
(205, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-12 04:45:41'),
(206, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-12 04:50:58'),
(207, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/rawmaterials-view/24', '', 'Admin', '2023-12-12 05:36:40'),
(208, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 05:37:40'),
(209, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 05:38:00'),
(210, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 05:39:01'),
(211, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 05:39:57'),
(212, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Admin', '2023-12-12 05:40:13'),
(213, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 05:46:17'),
(214, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-12 06:03:45'),
(215, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-12 06:05:34'),
(216, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-12 06:06:29'),
(217, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 06:19:26'),
(219, 'Stock Transfer', '[ Stock Transfer failed ]', 'erp/warehouse/currentstock', '', 'Admin', '2023-12-12 07:15:24'),
(220, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Admin', '2023-12-12 07:16:24'),
(221, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Admin', '2023-12-12 07:17:13'),
(222, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Admin', '2023-12-12 07:18:20'),
(223, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Admin', '2023-12-12 07:25:34'),
(225, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Admin', '2023-12-12 07:40:16'),
(228, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-12 08:39:09'),
(229, 'Stock Alert Update', '[ Stock Alert successfully updated ]', 'erp/inventory/semifinishedview/2', '', 'Admin', '2023-12-12 08:45:28'),
(230, 'Stock Alert Update', '[ Stock Alert successfully updated ]', 'erp/inventory/semifinishedview/2', '', 'Admin', '2023-12-12 08:45:43'),
(231, 'Stock Alert Update', '[ Stock Alert failed to update ]', 'erp/inventory/semifinishedview/2', '', 'Admin', '2023-12-12 08:45:46'),
(232, 'Stock Alert Update', '[ Stock Alert successfully updated ]', 'erp/inventory/semifinishedview/2', '', 'Admin', '2023-12-12 08:51:59'),
(233, 'Semi Finished Update', '[ Semi Finished successfully updated ]', '', '', 'Admin', '2023-12-12 08:52:43'),
(234, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/1', '', 'Admin', '2023-12-12 08:52:55'),
(235, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Admin', '2023-12-12 08:53:51'),
(236, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete7', '{\"warehouse_id\":\"7\",\"name\":\"divya\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"1\",\"description\":\"ftjyguj\",\"aisle_count\":\"44\",\"racks_per_aisle\":\"547\",\"shelf_per_rack\":\"635\",\"bins_per_shelf\":\"5\"}', 'Admin', '2023-12-12 09:06:53'),
(237, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Admin', '2023-12-12 09:25:46'),
(238, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Admin', '2023-12-12 09:27:27'),
(239, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-12 09:28:23'),
(240, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/4', '{\"estimate_id\":\"4\",\"code\":\"EST2\",\"estimate_date\":\"2022-05-05\",\"terms_condition\":\"hello\",\"name\":\"Sam\",\"cust_id\":\"9\",\"shippingaddr_id\":\"0\"}', 'Admin', '2023-12-12 09:28:30'),
(244, 'Finished Good Update', '[ Finished Good successfully updated ]', '', '', 'Admin', '2023-12-12 09:52:32'),
(245, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/finishedgood-view/7', '', 'Admin', '2023-12-12 10:03:20'),
(246, 'Stock Alert Update', '[ Stock Alert successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/finishedgood-view/7', '', 'Admin', '2023-12-12 10:03:25'),
(247, 'Finished Good Update', '[ Finished Good successfully updated ]', '', '', 'Admin', '2023-12-12 10:03:46'),
(253, 'Finished Good Update', '[ Finished Good successfully updated ]', '', '', 'Admin', '2023-12-12 10:20:38'),
(254, ' Service Insert', '[ Service successfully created ]', '', '', 'Admin', '2023-12-12 10:37:22'),
(255, 'Quotation Update', '[ Quotation successfully updated ]', 'erp/sale/quotationview/1', '', 'Admin', '2023-12-12 10:52:22'),
(256, ' Service Update', '[ Service successfully updated ]', '', '', 'Admin', '2023-12-12 11:02:41'),
(257, ' Service Update', '[ Service successfully updated ]', '', '', 'Admin', '2023-12-12 11:02:49'),
(258, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 11:54:04'),
(259, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 11:54:12'),
(260, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:06:26'),
(261, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:06:34'),
(262, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:07:07'),
(263, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:07:53'),
(264, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:10:30'),
(265, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:12:26'),
(266, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:13:58'),
(267, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:14:19'),
(268, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:14:53'),
(269, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:15:12'),
(270, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:16:07'),
(271, 'Amenity Update', '[ Amenity failed to update ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:16:14'),
(272, 'Amenity Update', '[ Amenity successfully updated ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:19:19'),
(273, 'Amenity Update', '[ Amenity successfully updated ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:19:28'),
(274, 'Amenity Insert', '[ Amenity successfully created ]', 'erp/inventory/amenity', '', 'Admin', '2023-12-12 12:19:33'),
(275, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/7', '', 'Admin', '2023-12-12 13:07:39'),
(276, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/8', '', 'Admin', '2023-12-12 13:08:13'),
(277, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/3', '', 'Admin', '2023-12-12 13:32:41'),
(278, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/1', '', 'Admin', '2023-12-12 13:42:22'),
(279, 'Property Unit Update', '[ Property Unit failed to update ]', 'erp/inventory/property-view/1', '', 'Admin', '2023-12-12 13:43:33'),
(280, 'Property Unit Update', '[ Property Unit failed to update ]', 'erp/inventory/property-view/1', '', 'Admin', '2023-12-12 13:43:41'),
(281, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/8', '', 'Admin', '2023-12-12 13:44:16'),
(282, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/5', '', 'Admin', '2023-12-12 13:46:21'),
(283, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-13 07:10:15'),
(284, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/3', '', 'Admin', '2023-12-13 07:16:54'),
(285, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/4', '', 'Admin', '2023-12-13 07:24:10'),
(286, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/4', '', 'Admin', '2023-12-13 07:24:22'),
(287, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/4', '', 'Admin', '2023-12-13 07:25:28'),
(288, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-13 07:28:18'),
(289, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/2', '', 'Admin', '2023-12-13 07:29:16'),
(290, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-13 07:52:29'),
(291, 'Property Unit Update', '[ Property Unit failed to update ]', 'erp/inventory/property-view/2', '', 'Admin', '2023-12-13 07:53:56'),
(292, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/3', '', 'Admin', '2023-12-13 07:58:39'),
(293, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/3', '', 'Admin', '2023-12-13 08:00:51'),
(294, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/7', '', 'Admin', '2023-12-13 08:01:02'),
(295, ' Service Update', '[ Service successfully updated ]', '', '', 'Admin', '2023-12-13 08:35:52'),
(296, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/3', '', 'Admin', '2023-12-13 08:39:49'),
(297, 'Property Unit Update', '[ Property Unit successfully updated ]', 'erp/inventory/property-view/8', '', 'Admin', '2023-12-13 08:40:05'),
(298, ' Service Update', '[ Service successfully updated ]', '', '', 'Admin', '2023-12-13 08:40:49'),
(299, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/8', '', 'Admin', '2023-12-13 08:41:42'),
(300, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/8', '', 'Admin', '2023-12-13 08:41:54'),
(301, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/9', '', 'Admin', '2023-12-13 08:42:33'),
(302, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Admin', '2023-12-13 09:14:36'),
(303, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Admin', '2023-12-13 09:17:08'),
(304, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Admin', '2023-12-13 09:19:03'),
(305, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Admin', '2023-12-13 09:19:33'),
(306, 'Unit Update', '[ Unit successfully updated ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:36:24'),
(307, 'Unit Update', '[ Unit successfully updated ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:36:30'),
(308, 'Unit Insert', '[ Unit successfully created ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:36:36'),
(309, 'Unit Insert', '[ Unit successfully created ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:36:55'),
(310, 'Unit Update', '[ Unit successfully updated ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:37:03'),
(311, 'Unit Delete', '[ Unit successfully deleted ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:37:09'),
(312, 'Unit Update', '[ Unit successfully updated ]', 'erp/inventory/units', '', 'Admin', '2023-12-13 09:37:22'),
(313, 'Brand Insert', '[ Brand successfully created ]', 'erp/inventory/brands', '', 'Admin', '2023-12-13 10:02:41'),
(314, 'Brand Update', '[ Brand successfully updated ]', 'erp/inventory/brands', '', 'Admin', '2023-12-13 10:03:23'),
(315, 'Brand Delete', '[ Brand successfully deleted ]', 'erp/inventory/brands', '', 'Admin', '2023-12-13 10:04:32'),
(316, 'Brand Insert', '[ Brand successfully created ]', 'erp/inventory/brands', '', 'Admin', '2023-12-13 10:04:48'),
(317, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 05:06:27'),
(318, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 06:12:15'),
(319, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 06:12:25'),
(320, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 06:16:14'),
(321, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 06:32:24'),
(322, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 11:30:58'),
(323, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project-management/teams-view/3', '', 'Admin', '2023-12-14 11:40:07'),
(324, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project-management/teams-view/3', '', 'Admin', '2023-12-14 12:22:01'),
(325, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-14 12:33:32'),
(326, 'Quotation Notification Insert', '[ Quotation Notification successfully created ]', 'erp/sale/quotationview/1', '', 'Admin', '2023-12-14 12:34:01'),
(327, 'Quotation Notification Delete', '[ Quotation Notification successfully deleted ]', 'erp/sale/quotationview/1', '', 'Admin', '2023-12-14 12:58:19'),
(328, 'Team Update', '[ Team failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-14 13:20:13'),
(329, 'Team Update', '[ Team failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-14 13:20:22'),
(330, 'Team Update', '[ Team failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-14 13:20:26'),
(331, 'Team Update', '[ Team successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-14 13:20:32'),
(332, 'Team Update', '[ Team successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-14 13:20:41'),
(333, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/4', '', 'Admin', '2023-12-14 13:21:32'),
(334, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-15 05:16:44'),
(335, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-15 05:21:53'),
(336, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-15 05:25:22'),
(337, 'Workgroup Insert', '[ Workgroup successfully created ]', 'erp/project/workgroups/', '', 'Admin', '2023-12-15 06:28:21'),
(338, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Admin', '2023-12-15 07:08:15'),
(339, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Admin', '2023-12-15 07:08:29'),
(340, 'Workgroup Insert', '[ Workgroup successfully created ]', 'erp/project/workgroups/', '', 'Admin', '2023-12-15 07:10:04'),
(341, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/10', '', 'Admin', '2023-12-15 07:27:34'),
(342, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/5', '', 'Admin', '2023-12-15 08:01:10'),
(343, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/6', '', 'Admin', '2023-12-15 08:06:02'),
(344, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/7', '', 'Admin', '2023-12-15 08:31:06'),
(345, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-15 10:58:54'),
(346, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/1', '', 'Admin', '2023-12-15 11:01:51'),
(347, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-16 05:00:04'),
(348, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:08:19'),
(349, 'Project Phase Update', '[ Project Phase successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:08:44'),
(350, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:17:31'),
(351, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:18:10'),
(352, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:18:25'),
(353, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:18:40'),
(354, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:20:07'),
(355, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 05:38:09'),
(356, 'Project Update', '[ Project successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:14:56'),
(357, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:15:42'),
(358, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:15:49'),
(359, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:16:06'),
(360, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:26:24'),
(361, 'Project Expense Update', '[ Project Expense successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:31:27'),
(362, 'Project Rawmaterials Update', '[ Project Rawmaterials failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:38:49'),
(363, 'Project Rawmaterials Update', '[ Project Rawmaterials successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:39:12'),
(364, 'Project Rawmaterials Update', '[ Project Rawmaterials successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:39:49'),
(365, 'Project Rawmaterials Dispatch', '[ Project Rawmaterials Dispatch successfully done ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:39:54'),
(366, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-16 06:46:39'),
(367, 'Project Update', '[ Project successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Admin', '2023-12-16 06:54:52'),
(368, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 06:59:51'),
(369, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:00:10'),
(370, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:00:23'),
(371, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:01:01'),
(372, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:04:21'),
(373, 'Project Rawmaterials Update', '[ Project Rawmaterials successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:04:34'),
(374, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:05:10'),
(375, 'Project Expense Update', '[ Project Expense failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:22:51'),
(376, 'Project Expense Update', '[ Project Expense failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:26:13'),
(377, 'Project Expense Update', '[ Project Expense failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:26:26'),
(378, 'Project Expense Update', '[ Project Expense failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:26:37'),
(379, 'Project Expense Update', '[ Project Expense successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/8', '', 'Admin', '2023-12-16 07:27:01'),
(380, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-16 09:03:13'),
(381, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:34:08'),
(382, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:34:30'),
(383, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/rawmaterials-view/17', '', 'Admin', '2023-12-16 09:34:58'),
(384, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:35:22');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(385, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:35:55'),
(386, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:37:10'),
(387, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:37:25'),
(388, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:37:39'),
(389, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Admin', '2023-12-16 09:38:06'),
(390, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-18 07:03:38'),
(391, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-18 11:30:44'),
(392, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-18 13:56:39'),
(393, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-20 05:31:53'),
(394, 'Lead Insert', '[ Lead successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/14', '', 'Admin', '2023-12-20 05:41:57'),
(395, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/12', '', 'Admin', '2023-12-20 06:46:23'),
(396, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/12', '', 'Admin', '2023-12-20 06:46:58'),
(397, 'Lead Update', '[ Lead successfully updated ]', 'erp/crm/leadview/5', '', 'Admin', '2023-12-20 06:57:06'),
(398, 'Lead Update', '[ Lead successfully updated ]', 'erp/crm/leadview/11', '', 'Admin', '2023-12-20 06:57:30'),
(399, 'Lead Update', '[ Lead successfully updated ]', 'erp/crm/leadview/1', '', 'Admin', '2023-12-20 06:57:56'),
(400, 'Lead Update', '[ Lead successfully updated ]', 'erp/crm/leadview/1', '', 'Admin', '2023-12-20 06:58:07'),
(401, 'Lead Import', '[ Lead partially imported ]', '', '', 'Admin', '2023-12-20 07:57:45'),
(402, 'Lead Import', '[ Lead partially imported ]', '', '', 'Admin', '2023-12-20 07:59:12'),
(403, 'Lead Import', '[ Lead partially imported ]', '', '', 'Admin', '2023-12-20 08:34:56'),
(404, 'Lead Update', '[ Lead successfully updated ]', 'erp/crm/leadview/15', '', 'Admin', '2023-12-20 08:37:18'),
(405, 'Lead Import', '[ Lead partially imported ]', '', '', 'Admin', '2023-12-20 08:40:04'),
(406, 'Lead Import', '[ Lead partially imported ]', '', '', 'Admin', '2023-12-20 08:40:35'),
(407, 'Lead Import', '[ Lead partially imported ]', '', '', 'Admin', '2023-12-20 08:54:18'),
(408, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/16', '', 'Admin', '2023-12-20 08:55:16'),
(409, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/16', '', 'Admin', '2023-12-20 09:03:16'),
(410, 'Customer Insert', '[ Customer successfully created ]', 'erp/crm/customerview/44', '', 'Admin', '2023-12-20 09:31:04'),
(411, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/11', '', 'Admin', '2023-12-20 09:55:32'),
(412, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/11', '', 'Admin', '2023-12-20 09:55:58'),
(413, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/11', '', 'Admin', '2023-12-20 09:56:30'),
(414, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:06:23'),
(415, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:11:14'),
(416, 'Customer Notification Insert', '[ Customer Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:26:55'),
(417, 'Customer Notification Delete', '[ Customer Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:30:43'),
(418, 'Customer Notification Delete', '[ Customer Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:31:43'),
(419, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:55:54'),
(420, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:56:59'),
(421, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 10:59:32'),
(422, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 11:37:04'),
(423, 'Customer Shipping Address Delete', '[ Customer Shipping Address successfully deleted ]', '/erp/crm/lead-customer-view/41', '', 'Admin', '2023-12-20 11:38:36'),
(424, 'Finance Automation', '[ Finance Automation added Marketing Entry ; ID= ]', '', '', 'Admin', '2023-12-20 13:04:59'),
(425, 'Marketing Insert', '[ Marketing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:04:59'),
(426, 'Marketing Update', '[ Marketing failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:06:52'),
(427, 'Marketing Update', '[ Marketing failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:06:56'),
(428, 'Marketing Update', '[ Marketing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:07:09'),
(429, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:17:08'),
(430, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:17:14'),
(431, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:17:19'),
(432, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:17:28'),
(433, 'Finance Automation', '[ Finance Automation added Marketing Entry ; ID= ]', '', '', 'Admin', '2023-12-20 13:24:17'),
(434, 'Marketing Insert', '[ Marketing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:24:17'),
(435, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:24:30'),
(436, 'Marketing Update', '[ Marketing failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:25:37'),
(437, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-20 13:26:39'),
(438, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Admin', '2023-12-20 13:48:11'),
(439, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Admin', '2023-12-20 13:50:57'),
(440, 'Ticket Update', '[ Ticket successfully updated ]', 'erp/crm/tickets', '', 'Admin', '2023-12-20 13:55:48'),
(441, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-21 04:58:43'),
(442, 'Ticket Update', '[ Ticket successfully updated ]', 'erp/crm/tickets', '', 'Admin', '2023-12-21 04:59:38'),
(443, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Admin', '2023-12-21 05:37:07'),
(444, 'Department Update', '[ Department failed to update ]', 'erp/hr/departments/', '', 'Admin', '2023-12-21 07:44:20'),
(445, 'Department Insert', '[ Department successfully created ]', 'erp/hr/departments/', '', 'Admin', '2023-12-21 07:45:07'),
(446, 'Department Update', '[ Department successfully updated ]', 'erp/hr/departments/', '', 'Admin', '2023-12-21 07:45:59'),
(447, 'Department Insert', '[ Department successfully created ]', 'erp/hr/departments/', '', 'Admin', '2023-12-21 07:46:10'),
(448, 'Department Delete', '[ Department successfully deleted ]', 'erp/hr/departments/', '', 'Admin', '2023-12-21 07:51:26'),
(449, 'Designation Update', '[ Designation successfully updated ]', 'erp/hr/designation/', '', 'Admin', '2023-12-21 08:46:08'),
(450, 'Designation Update', '[ Designation successfully updated ]', 'erp/hr/designation/', '', 'Admin', '2023-12-21 08:46:26'),
(451, 'Designation Insert', '[ Designation successfully created ]', 'erp/hr/designation/', '', 'Admin', '2023-12-21 08:47:48'),
(452, 'Designation Insert', '[ Designation successfully created ]', 'erp/hr/designation/', '', 'Admin', '2023-12-21 08:48:21'),
(453, 'Designation Delete', '[ Designation successfully deleted ]', 'erp/hr/designation/', '', 'Admin', '2023-12-21 08:48:29'),
(454, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 09:19:23'),
(455, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 09:20:24'),
(456, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Admin', '2023-12-21 09:21:30'),
(457, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 09:25:24'),
(458, 'Employee Import', '[ Employee partially imported ]', '', '', 'Admin', '2023-12-21 09:56:09'),
(459, 'Employee Import', '[ Employee partially imported ]', '', '', 'Admin', '2023-12-21 09:56:52'),
(460, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 10:05:24'),
(461, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 10:05:41'),
(462, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 10:06:18'),
(463, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 10:06:34'),
(464, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Admin', '2023-12-21 10:07:21'),
(465, 'Employee Import', '[ Employee partially imported ]', '', '', 'Admin', '2023-12-21 10:07:47'),
(466, 'Contractor Import', '[ Contractor successfully imported ]', '', '', 'Admin', '2023-12-21 10:27:14'),
(467, 'Contractor Import', '[ Contractor successfully imported ]', '', '', 'Admin', '2023-12-21 10:27:29'),
(468, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Admin', '2023-12-21 10:39:33'),
(469, 'Contractor Update', '[ Contractor successfully updated ]', 'erp/hr/contractors/', '', 'Admin', '2023-12-21 11:03:51'),
(470, 'Contractor Import', '[ Contractor successfully imported ]', '', '', 'Admin', '2023-12-21 11:04:18'),
(471, 'Deduction Insert', '[ Deduction successfully created ]', 'erp/hr/deductions/', '', 'Admin', '2023-12-21 12:53:44'),
(472, 'Deduction Update', '[ Deduction successfully updated ]', 'erp/hr/deductions/', '', 'Admin', '2023-12-21 12:56:33'),
(473, 'Addition Insert', '[ Addition successfully created ]', 'erp/hr/additions/', '', 'Admin', '2023-12-21 13:07:52'),
(474, 'Addition Update', '[ Addition failed to update ]', 'erp/hr/additions/', '', 'Admin', '2023-12-21 13:10:16'),
(475, 'Addition Update', '[ Addition successfully updated ]', 'erp/hr/additions/', '', 'Admin', '2023-12-21 13:10:25'),
(476, 'Payroll Insert', '[ Payroll successfully created ]', 'erp/hr/payrolls', '', 'Admin', '2023-12-21 13:32:43'),
(477, 'Payroll Process', '[ Payroll successfully processed ]', 'erp/hr/payrolls', '', 'Admin', '2023-12-21 13:39:18'),
(478, 'Payroll Process', '[ Payroll successfully processed ]', 'erp/hr/payrolls', '', 'Admin', '2023-12-21 13:39:23'),
(479, 'Login', '[ User successfully logged in ]', '', '', 'Admin', '2023-12-22 04:49:04'),
(480, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Admin', '2023-12-22 05:43:30'),
(481, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Admin', '2023-12-22 05:44:19'),
(482, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Admin', '2023-12-22 05:47:31'),
(483, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Admin', '2023-12-22 05:47:50'),
(484, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Admin', '2023-12-22 06:04:13'),
(485, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Admin', '2023-12-22 06:05:48'),
(486, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Admin', '2023-12-22 07:19:08'),
(487, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Admin', '2023-12-22 07:19:24'),
(488, 'Role Update', '[ Role successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/role-view/19', '', 'Admin', '2023-12-22 07:31:04'),
(489, 'Role Insert', '[ Role successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/role-view/20', '', 'Admin', '2023-12-22 07:32:21'),
(490, 'Role Delete', '[ Role successfully deleted ; ID=20 ]', '', '', 'Admin', '2023-12-22 07:32:33'),
(491, 'Mail Settings Update', '[ Mail Settings successfully updated ]', '', '', 'Admin', '2023-12-22 07:36:49'),
(492, 'Mail Settings Update', '[ Mail Settings successfully updated ]', '', '', 'Admin', '2023-12-22 08:53:23'),
(493, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-22 12:17:54'),
(494, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-22 12:23:07'),
(495, 'Group Update', '[ Group successfully updated ]', '', '', 'QBS', '2023-12-22 12:36:52'),
(496, 'Group Update', '[ Group successfully updated ]', '', '', 'QBS', '2023-12-22 12:36:59'),
(497, 'Group Insert', '[ Group successfully inserted ]', '', '', 'QBS', '2023-12-22 12:37:34'),
(498, 'Group Delete', '[ Group successfully deleted ]', '', '', 'QBS', '2023-12-22 12:39:51'),
(499, 'Finance Settings Update', '[ Finance Settings successfully updated ]', '', '', 'QBS', '2023-12-22 12:49:47'),
(500, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-23 05:20:08'),
(501, 'Journal Entry Insert', '[ Journal Entry successfully created ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-23 06:03:21'),
(502, 'Journal Entry Insert', '[ Journal Entry successfully created ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-23 06:10:09'),
(503, 'Journal Entry Insert', '[ Journal Entry successfully created ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-23 06:10:39'),
(504, 'Journal Entry Post', '[ Journal Entry successfully posted ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-23 06:31:01'),
(505, 'Journal Entry Post', '[ Journal Entry successfully posted ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-23 06:55:04'),
(506, 'Payment Mode Insert', '[ Payment Mode successfully created ]', 'erp/finance/paymentmode/', '', 'QBS', '2023-12-23 07:13:25'),
(507, 'Payment Mode Update', '[ Payment Mode successfully updated ]', 'erp/finance/paymentmode/', '', 'QBS', '2023-12-23 07:17:09'),
(508, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-23 07:58:55'),
(509, 'Tax Update', '[ Tax successfully updated ]', 'erp/finance/tax/', '', 'QBS', '2023-12-23 08:50:13'),
(510, 'Tax Update', '[ Tax successfully updated ]', 'erp/finance/tax/', '', 'QBS', '2023-12-23 08:50:58'),
(511, 'Tax Insert', '[ Tax successfully created ]', 'erp/finance/tax/', '', 'QBS', '2023-12-23 08:51:17'),
(512, 'Currency Update', '[ Currency failed to update ]', '', '', 'QBS', '2023-12-23 08:58:35'),
(513, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'QBS', '2023-12-23 08:59:16'),
(514, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-23 09:15:50'),
(515, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'QBS', '2023-12-23 10:24:52'),
(516, 'Transport Type Delete', '[ Transport Type failed to delete ]', '', '', 'QBS', '2023-12-23 10:25:47'),
(517, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'QBS', '2023-12-23 10:25:56'),
(518, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'QBS', '2023-12-23 10:26:00'),
(519, 'Transport Type Update', '[ Transport Type successfully updated ]', '', '', 'QBS', '2023-12-23 10:26:30'),
(520, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'QBS', '2023-12-23 10:26:40'),
(521, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-23 10:35:35'),
(522, 'Transport Insert', '[ Transport successfully created ]', '', '', 'QBS', '2023-12-23 10:36:29'),
(523, 'Transport Update', '[ Transport successfully updated ]', '', '', 'QBS', '2023-12-23 10:44:02'),
(524, 'Transport Update', '[ Transport failed to update ]', '', '', 'QBS', '2023-12-23 10:44:12'),
(525, 'Transport Update', '[ Transport successfully updated ]', '', '', 'QBS', '2023-12-23 10:44:23'),
(526, 'GL Account Update', '[ GL Account successfully updated ]', 'erp/finance/glaccounts/', '', 'QBS', '2023-12-23 10:45:07'),
(527, 'Transport Delete', '[ Transport failed to delete ]', '', '', 'QBS', '2023-12-23 10:48:51'),
(528, 'Transport Insert', '[ Transport successfully created ]', '', '', 'QBS', '2023-12-23 10:49:05'),
(529, 'Transport Delete', '[ Transport successfully deleted ]', '', '', 'QBS', '2023-12-23 10:49:11'),
(530, 'Transport Update', '[ Transport successfully updated ]', '', '', 'QBS', '2023-12-23 10:50:29'),
(531, 'Delivery Record Update', '[ Delivery Record failed to update ]', '', '', 'QBS', '2023-12-23 11:00:23'),
(532, 'Delivery Record Update', '[ Delivery Record successfully updated ]', '', '', 'QBS', '2023-12-23 11:00:29'),
(533, 'Transport Insert', '[ Transport successfully created ]', '', '', 'QBS', '2023-12-23 11:05:50'),
(534, 'Transport Update', '[ Transport failed to update ]', '', '', 'QBS', '2023-12-23 11:05:59'),
(535, 'Transport Update', '[ Transport successfully updated ]', '', '', 'QBS', '2023-12-23 11:29:34'),
(536, 'Group Insert', '[ Group successfully inserted ]', '', '', 'QBS', '2023-12-23 11:46:06'),
(537, 'Group Delete', '[ Group successfully deleted ]', '', '', 'QBS', '2023-12-23 11:46:16'),
(538, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-23 11:49:58'),
(539, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-23 11:52:46'),
(540, 'Role Delete', '[ Role successfully deleted ; ID=17 ]', '', '', 'QBS', '2023-12-23 11:56:46'),
(541, 'Group Delete', '[ Group successfully deleted ]', '', '', 'QBS', '2023-12-23 11:57:07'),
(542, 'Bank Account Insert', '[ Bank Account successfully created ]', 'erp/finance/bankaccounts/', '', 'QBS', '2023-12-23 12:05:40'),
(543, 'Payroll Delete', '[ Payroll successfully deleted ]', 'erp/hr/payrolls', '', 'QBS', '2023-12-23 12:07:22'),
(544, 'Addition Delete', '[ Addition successfully deleted ]', 'erp/hr/additions/', '', 'QBS', '2023-12-23 12:11:53'),
(545, 'Deduction Delete', '[ Deduction successfully deleted ]', 'erp/hr/deductions/', '', 'QBS', '2023-12-23 12:14:19'),
(546, 'Contractor Delete', '[ Contractor successfully deleted ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-23 12:18:17'),
(547, 'Employee Delete', '[ Employee successfully deleted ]', 'erp/hr/employees/', '', 'QBS', '2023-12-23 12:22:35'),
(548, 'Designation Insert', '[ Designation successfully created ]', 'erp/hr/designation/', '', 'QBS', '2023-12-23 12:23:25'),
(549, 'Designation Delete', '[ Designation successfully deleted ]', 'erp/hr/designation/', '', 'QBS', '2023-12-23 12:23:30'),
(550, 'Department Insert', '[ Department successfully created ]', 'erp/hr/departments/', '', 'QBS', '2023-12-23 12:23:40'),
(551, 'Department Delete', '[ Department successfully deleted ]', 'erp/hr/departments/', '', 'QBS', '2023-12-23 12:23:45'),
(552, 'Transport Delete', '[ Transport successfully deleted ]', '', '', 'QBS', '2023-12-23 12:24:05'),
(553, 'Bank Account Update', '[ Bank Account failed to update ]', 'erp/finance/bankaccounts/', '', 'QBS', '2023-12-23 12:28:53'),
(554, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'QBS', '2023-12-23 12:29:25'),
(555, 'Team Delete', '[ Team successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/4', '', 'QBS', '2023-12-23 12:30:23'),
(556, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/5', '', 'QBS', '2023-12-23 12:30:43'),
(557, 'Team Delete', '[ Team successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/5', '', 'QBS', '2023-12-23 12:30:48'),
(558, 'Team Member Delete', '[ Team Member successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams', '', 'QBS', '2023-12-23 12:37:56'),
(559, 'Project Expense Delete', '[ Project Expense successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-23 12:50:36'),
(560, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-23 12:52:27'),
(561, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 05:07:25'),
(562, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 05:10:43'),
(563, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-24 05:13:11'),
(564, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 05:14:38'),
(565, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-24 05:16:09'),
(566, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/7', '', 'QBS', '2023-12-24 05:22:07'),
(567, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/8', '', 'QBS', '2023-12-24 05:28:29'),
(568, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-24 05:33:21'),
(569, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-24 05:33:42'),
(570, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 05:40:51'),
(571, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-24 05:47:34'),
(572, 'Project Rawmaterials Delete', '[ Project Rawmaterials successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'QBS', '2023-12-24 05:50:23'),
(573, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 05:54:08'),
(574, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'QBS', '2023-12-24 05:57:18'),
(575, 'Bank Account Update', '[ Bank Account failed to update ]', 'erp/finance/bankaccounts/', '', 'QBS', '2023-12-24 05:57:18'),
(576, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'QBS', '2023-12-24 05:58:52'),
(577, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:46:30'),
(578, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:46:56'),
(579, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:48:08'),
(580, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:48:24'),
(581, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:48:41'),
(582, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:49:34'),
(583, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:49:58'),
(584, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/9', '', 'QBS', '2023-12-24 06:51:02'),
(585, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 06:59:17'),
(586, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 07:08:13'),
(587, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 07:08:32'),
(588, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/10', '', 'QBS', '2023-12-24 07:40:25'),
(589, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/10', '', 'QBS', '2023-12-24 07:40:41'),
(590, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/10', '', 'QBS', '2023-12-24 07:41:13'),
(591, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/10', '', 'QBS', '2023-12-24 07:41:41'),
(592, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/10', '', 'QBS', '2023-12-24 07:42:41'),
(593, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/10', '', 'QBS', '2023-12-24 07:45:10'),
(594, 'Project Update', '[ Project successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'QBS', '2023-12-24 07:49:57'),
(595, 'Team Delete', '[ Team successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/3', '', 'QBS', '2023-12-24 07:50:53'),
(596, 'Team Member Delete', '[ Team Member successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams', '', 'QBS', '2023-12-24 07:53:55'),
(597, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 07:54:25'),
(598, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/2', '', 'QBS', '2023-12-24 07:54:25'),
(599, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 07:54:35'),
(600, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 07:54:39'),
(601, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 07:54:49'),
(602, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/6', '', 'QBS', '2023-12-24 07:58:29'),
(603, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 08:34:43'),
(604, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 08:34:46'),
(605, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 08:34:56'),
(606, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 08:39:35'),
(607, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/7', '', 'QBS', '2023-12-24 08:58:09'),
(608, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/7', '', 'QBS', '2023-12-24 08:59:06'),
(609, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/23', '', 'QBS', '2023-12-24 09:09:37'),
(610, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/23', '', 'QBS', '2023-12-24 09:15:21'),
(611, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/23', '', 'QBS', '2023-12-24 09:15:58'),
(612, 'Transport Insert', '[ Transport successfully created ]', '', '', 'QBS', '2023-12-24 09:16:46'),
(613, 'Transport Update', '[ Transport failed to update ]', '', '', 'QBS', '2023-12-24 09:17:00'),
(614, 'Transport Update', '[ Transport failed to update ]', '', '', 'QBS', '2023-12-24 09:19:41'),
(615, 'Delivery Record Update', '[ Delivery Record successfully updated ]', '', '', 'QBS', '2023-12-24 09:20:24'),
(616, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/8', '', 'QBS', '2023-12-24 09:30:11'),
(617, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 09:33:41'),
(618, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/22', '', 'QBS', '2023-12-24 09:33:56'),
(619, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/24', '', 'QBS', '2023-12-24 09:43:54'),
(620, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/24', '', 'QBS', '2023-12-24 09:44:38'),
(621, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/5', '[]', 'QBS', '2023-12-24 10:54:46'),
(622, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/8', '', 'QBS', '2023-12-24 10:58:31'),
(623, 'Workgroup Delete', '[ Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'QBS', '2023-12-24 11:00:36'),
(624, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'QBS', '2023-12-24 11:01:26'),
(625, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/rawmaterials-view/44', '', 'QBS', '2023-12-24 11:01:52'),
(626, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/22', '[{\"invent_req_id\":\"21\",\"req_id\":\"22\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"22\",\"req_code\":\"6969\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"sdfsd\",\"remarks\":\"\",\"created_at\":\"1703401157\",\"created_by\":\"1\"}]', 'QBS', '2023-12-24 11:08:04'),
(627, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/23', '', 'QBS', '2023-12-24 11:09:12'),
(628, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 11:13:28'),
(629, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-24 11:15:26'),
(630, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/12', '', 'QBS', '2023-12-24 11:47:35'),
(631, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'QBS', '2023-12-24 11:51:43'),
(632, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/rawmaterials-view/45', '', 'QBS', '2023-12-24 11:51:56'),
(633, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'erp/inventory/semifinishedview/11', '', 'QBS', '2023-12-24 11:56:42'),
(634, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/24', '', 'QBS', '2023-12-24 11:58:52'),
(635, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/finishedgood-view/15', '', 'QBS', '2023-12-24 12:01:15'),
(636, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/24', '', 'QBS', '2023-12-24 12:03:19'),
(637, ' Service Insert', '[ Service successfully created ]', '', '', 'QBS', '2023-12-24 12:09:57'),
(638, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'QBS', '2023-12-24 12:17:44'),
(639, 'Brand Delete', '[ Brand successfully deleted ]', 'erp/inventory/brands', '', 'QBS', '2023-12-24 12:18:25'),
(640, 'Brand Insert', '[ Brand successfully created ]', 'erp/inventory/brands', '', 'QBS', '2023-12-24 12:18:30'),
(641, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/3', '', 'QBS', '2023-12-24 12:18:59'),
(642, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/10', '', 'QBS', '2023-12-24 12:31:37'),
(643, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/10', '', 'QBS', '2023-12-24 12:32:03'),
(644, 'Amenity Insert', '[ Amenity successfully created ]', 'erp/inventory/amenity', '', 'QBS', '2023-12-24 12:34:45'),
(645, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/24', '', 'QBS', '2023-12-24 12:47:25'),
(646, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 04:53:03'),
(647, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 05:11:03'),
(648, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 05:12:51'),
(649, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'QBS', '2023-12-26 05:20:12'),
(650, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'QBS', '2023-12-26 05:20:17'),
(651, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 05:21:15'),
(652, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/11', '', 'QBS', '2023-12-26 05:26:28'),
(653, 'Property Unit Insert', '[ Property Unit successfully created ]', 'erp/inventory/propertyview/11', '', 'QBS', '2023-12-26 05:27:04'),
(654, ' Service Insert', '[ Service successfully created ]', '', '', 'QBS', '2023-12-26 05:33:07'),
(655, 'Department Insert', '[ Department successfully created ]', 'erp/hr/departments/', '', 'QBS', '2023-12-26 05:38:47'),
(656, 'Department Delete', '[ Department successfully deleted ]', 'erp/hr/departments/', '', 'QBS', '2023-12-26 05:38:54'),
(657, 'Designation Insert', '[ Designation successfully created ]', 'erp/hr/designation/', '', 'QBS', '2023-12-26 05:39:39'),
(658, 'Designation Delete', '[ Designation successfully deleted ]', 'erp/hr/designation/', '', 'QBS', '2023-12-26 05:39:44'),
(659, 'Deduction Delete', '[ Deduction successfully deleted ]', 'erp/hr/deductions/', '', 'QBS', '2023-12-26 05:40:15'),
(660, 'Addition Insert', '[ Addition successfully created ]', 'erp/hr/additions/', '', 'QBS', '2023-12-26 05:40:32'),
(661, 'Addition Delete', '[ Addition successfully deleted ]', 'erp/hr/additions/', '', 'QBS', '2023-12-26 05:40:37'),
(662, 'Payroll Insert', '[ Payroll successfully created ]', 'erp/hr/payrolls', '', 'QBS', '2023-12-26 05:41:55'),
(663, 'Payroll Delete', '[ Payroll successfully deleted ]', 'erp/hr/payrolls', '', 'QBS', '2023-12-26 05:42:01'),
(664, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 05:43:27'),
(665, 'Contractor Delete', '[ Contractor successfully deleted ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 05:44:05'),
(666, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 05:48:57'),
(667, 'Contractor Delete', '[ Contractor failed to delete ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 05:49:44'),
(668, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 06:00:21'),
(673, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 06:24:50'),
(674, 'Contractor Delete', '[ Contractor and related data deleted successfully ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 06:29:52'),
(675, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 06:32:42'),
(676, 'Contractor Delete', '[ Contractor and related data deleted successfully ]', 'erp/hr/contractors/', '', 'QBS', '2023-12-26 06:34:07'),
(679, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 06:58:49'),
(683, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'QBS', '2023-12-26 07:05:13'),
(684, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'QBS', '2023-12-26 07:07:56'),
(685, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:10:32'),
(691, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:21:10'),
(692, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:21:34'),
(696, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'QBS', '2023-12-26 07:27:04'),
(697, 'Group Insert', '[ Group successfully inserted ]', '', '', 'QBS', '2023-12-26 07:31:12'),
(698, 'Group Delete', '[ Group successfully deleted ]', '', '', 'QBS', '2023-12-26 07:31:20'),
(699, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'QBS', '2023-12-26 07:33:02'),
(700, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:33:18'),
(701, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:42:52'),
(702, 'Login', '[ User successfully logged in ]', '', '', 'QBS', '2023-12-26 07:47:43'),
(703, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/2', '', 'QBS', '2023-12-26 07:53:47'),
(704, 'Credit Notes Notification Delete', '[ Credit Notes Notification successfully deleted ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:58:53'),
(705, 'Credit Notes Notification Delete', '[ Credit Notes Notification failed to delete ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:59:15'),
(706, 'Credit Notes Notification Delete', '[ Credit Notes Notification failed to delete ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:59:24'),
(707, 'Credit Notes Notification Delete', '[ Credit Notes Notification failed to delete ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 07:59:40'),
(708, 'Credit Notes Notification Delete', '[ Credit Notes Notification failed to delete ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 08:36:50'),
(709, 'Credit Notes Notification Delete', '[ Credit Notes Notification failed to delete ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 08:40:32'),
(710, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'QBS', '2023-12-26 08:48:46'),
(711, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 08:50:46'),
(712, 'Credit Notes Notification Delete', '[ Credit Notes Notification failed to delete ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 08:50:55'),
(713, 'Credit Notes Notification Delete', '[ Credit Notes Notification successfully deleted ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 08:55:52'),
(714, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 08:56:15'),
(715, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'QBS', '2023-12-26 09:17:29'),
(716, 'Credit Notes Notification Update', '[ Credit Notes Notification successfully updated ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 09:21:41'),
(717, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/25', '', 'QBS', '2023-12-26 09:38:40'),
(718, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'QBS', '2023-12-26 09:42:46'),
(719, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:46:32'),
(720, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:46:55'),
(721, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:47:15'),
(722, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:49:07'),
(723, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:49:59'),
(724, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:50:29'),
(725, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:50:42'),
(726, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'QBS', '2023-12-26 09:51:57'),
(727, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/23', '', 'QBS', '2023-12-26 09:55:01'),
(728, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/23', '', 'QBS', '2023-12-26 09:55:30'),
(729, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/24', '', 'QBS', '2023-12-26 09:57:51'),
(730, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'QBS', '2023-12-26 09:58:31'),
(731, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/25', '[{\"invent_req_id\":\"24\",\"req_id\":\"25\",\"related_to\":\"semi_finished\",\"related_id\":\"1\",\"qty\":\"1\"},{\"req_id\":\"25\",\"req_code\":\"123456\",\"assigned_to\":\"1\",\"status\":\"0\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"test\",\"remarks\":\"\",\"created_at\":\"1703583520\",\"created_by\":\"1\"}]', 'QBS', '2023-12-26 10:22:20'),
(732, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/24', '[{\"invent_req_id\":\"23\",\"req_id\":\"24\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"24\",\"req_code\":\"691\",\"assigned_to\":\"1\",\"status\":\"2\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"Hello\",\"remarks\":\"nothing\",\"created_at\":\"1703411034\",\"created_by\":\"1\"}]', 'QBS', '2023-12-26 10:29:55'),
(733, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/23', '[{\"invent_req_id\":\"22\",\"req_id\":\"23\",\"related_to\":\"raw_material\",\"related_id\":\"3\",\"qty\":\"1\"},{\"req_id\":\"23\",\"req_code\":\"REQ-125\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"Test\",\"remarks\":\"\",\"created_at\":\"1703408977\",\"created_by\":\"1\"}]', 'QBS', '2023-12-26 10:29:59'),
(734, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/6', '[{\"invent_req_id\":\"7\",\"req_id\":\"6\",\"related_to\":\"semi_finished\",\"related_id\":\"7\",\"qty\":\"10\"},{\"invent_req_id\":\"8\",\"req_id\":\"6\",\"related_to\":\"semi_finished\",\"related_id\":\"8\",\"qty\":\"10\"},{\"req_id\":\"6\",\"req_code\":\"REQ-124\",\"assigned_to\":\"3\",\"status\":\"2\",\"priority\":\"2\",\"mail_sent\":\"1\",\"description\":\"hello world\",\"remarks\":\"go purchase everything you want !!!!\",\"created_at\":\"1646743525\",\"created_by\":\"2\"}]', 'QBS', '2023-12-26 10:30:48'),
(735, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/26', '', 'QBS', '2023-12-26 10:32:08'),
(736, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/27', '', 'QBS', '2023-12-26 10:34:07'),
(737, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/28', '', 'QBS', '2023-12-26 10:34:46'),
(738, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/27', '', 'QBS', '2023-12-26 10:35:09'),
(739, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/28', '', 'QBS', '2023-12-26 10:35:14'),
(740, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/27', '', 'QBS', '2023-12-26 10:35:43'),
(741, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/5', '', 'QBS', '2023-12-26 10:39:29'),
(742, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/5', '', 'QBS', '2023-12-26 10:43:27'),
(743, 'Credit Notes Notification Update', '[ Credit Notes Notification successfully updated ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 11:13:54'),
(744, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/12', '', 'QBS', '2023-12-26 11:19:32'),
(745, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/2', '', 'QBS', '2023-12-26 11:20:13'),
(746, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/12', '', 'QBS', '2023-12-26 11:20:19'),
(747, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/12', '', 'QBS', '2023-12-26 11:20:29'),
(748, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/12', '', 'QBS', '2023-12-26 11:22:26'),
(749, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/3', '', 'QBS', '2023-12-26 11:30:15'),
(750, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/3', '', 'QBS', '2023-12-26 11:30:29'),
(751, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'QBS', '2023-12-26 11:33:41'),
(752, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/3', '', 'QBS', '2023-12-26 11:48:16'),
(753, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/28', '[{\"invent_req_id\":\"28\",\"req_id\":\"28\",\"related_to\":\"semi_finished\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"28\",\"req_code\":\"RFQ-125\",\"assigned_to\":\"1\",\"status\":\"1\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"testing 2\",\"remarks\":\"\",\"created_at\":\"1703586886\",\"created_by\":\"1\"}]', 'QBS', '2023-12-26 11:54:30'),
(754, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/29', '', 'QBS', '2023-12-26 11:55:26'),
(755, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/29', '[{\"invent_req_id\":\"29\",\"req_id\":\"29\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"29\",\"req_code\":\"RFQ-125\",\"assigned_to\":\"1\",\"status\":\"0\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"test\",\"remarks\":\"\",\"created_at\":\"1703591726\",\"created_by\":\"1\"}]', 'QBS', '2023-12-26 11:55:32'),
(756, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/5', '', 'QBS', '2023-12-26 12:02:00'),
(757, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/30', '', 'QBS', '2023-12-26 12:09:29'),
(758, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/30', '', 'QBS', '2023-12-26 12:09:33'),
(759, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/30', '', 'QBS', '2023-12-26 12:09:42'),
(760, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/4', '', 'QBS', '2023-12-26 12:11:18'),
(761, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:18:06');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(762, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:28:12'),
(763, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:28:36'),
(764, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:29:31'),
(765, 'Journal Entry Delete', '[ Journal Entry successfully deleted ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-26 12:31:26'),
(766, 'Automation Delete', '[ Automation successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'QBS', '2023-12-26 12:33:17'),
(767, 'Automation Insert', '[ Automation successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'QBS', '2023-12-26 12:33:29'),
(768, 'Automation Update', '[ Automation successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'QBS', '2023-12-26 12:33:41'),
(769, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:35:44'),
(770, 'Payment Mode Delete', '[ Payment Mode successfully deleted ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-26 12:37:20'),
(771, 'Tax Insert', '[ Tax successfully created ]', 'erp/finance/tax/', '', 'QBS', '2023-12-26 12:39:56'),
(772, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:42:36'),
(773, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:43:05'),
(774, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:44:51'),
(775, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'QBS', '2023-12-26 12:44:56'),
(776, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:45:10'),
(777, 'Tax Delete', '[ Tax successfully deleted ]', 'erp/finance/tax/', '', 'QBS', '2023-12-26 12:45:13'),
(778, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:46:16'),
(779, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:46:40'),
(780, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:47:05'),
(781, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 12:47:27'),
(782, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-26 12:48:54'),
(783, 'Journal Entry Post', '[ Journal Entry successfully posted ]', 'erp/finance/journalentry/', '', 'QBS', '2023-12-26 12:49:47'),
(784, 'GL Account Delete', '[ GL Account successfully deleted ]', 'erp/finance/glaccounts/', '', 'QBS', '2023-12-26 12:50:32'),
(785, 'Account Group Insert', '[ Account Group successfully created ]', 'erp/finance/accountgroup/', '', 'QBS', '2023-12-26 12:50:46'),
(786, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:04:38'),
(787, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification failed to delete ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:05:29'),
(788, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:05:45'),
(789, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'QBS', '2023-12-26 13:08:11'),
(790, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'QBS', '2023-12-26 13:08:38'),
(791, 'Logout', '[ User successfully logout ]', '', '', 'QBS', '2023-12-26 13:19:53'),
(792, 'Logout', '[ User successfully logout ]', '', '', 'QBS', '2023-12-26 13:20:38'),
(793, 'Logout', '[ User successfully logout ]', '', '', 'QBS', '2023-12-26 13:22:54'),
(794, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:29:37'),
(795, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:31:36'),
(796, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:32:32'),
(797, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:32:40'),
(798, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'QBS', '2023-12-26 13:50:27'),
(799, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 04:48:48'),
(800, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 04:54:35'),
(801, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-27 04:55:34'),
(802, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 04:56:51'),
(803, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 04:58:45'),
(804, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-27 04:59:23'),
(805, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-27 05:00:55'),
(806, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-27 05:01:24'),
(807, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-27 05:01:36'),
(808, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Suppoer', '2023-12-27 05:05:44'),
(809, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 05:05:51'),
(810, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 05:06:44'),
(811, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 05:07:29'),
(812, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 05:58:19'),
(813, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Qbs Suppoer', '2023-12-27 06:35:50'),
(814, 'RFQ Update', '[ RFQ successfully updated ]', 'erp/procurement/rfqview/5', '', 'Qbs Suppoer', '2023-12-27 06:53:43'),
(815, 'RFQ Update', '[ RFQ successfully updated ]', 'erp/procurement/rfqview/5', '', 'Qbs Suppoer', '2023-12-27 06:55:17'),
(816, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:01:12'),
(817, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:02:37'),
(818, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/31', '', 'Qbs Suppoer', '2023-12-27 07:04:28'),
(819, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/31', '', 'Qbs Suppoer', '2023-12-27 07:06:53'),
(820, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/31', '', 'Qbs Suppoer', '2023-12-27 07:08:11'),
(821, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/31', '', 'Qbs Suppoer', '2023-12-27 07:08:32'),
(822, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/6', '', 'Qbs Suppoer', '2023-12-27 07:09:35'),
(823, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/32', '', 'Qbs Suppoer', '2023-12-27 07:11:16'),
(824, 'Transport Insert', '[ Transport successfully created ]', '', '', 'Qbs Suppoer', '2023-12-27 07:19:58'),
(825, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:22:01'),
(826, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:22:44'),
(827, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:43:36'),
(828, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:44:11'),
(829, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:44:23'),
(830, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Suppoer', '2023-12-27 07:44:32'),
(831, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-27 08:49:18'),
(832, 'Warehouse Insert', '[ Warehouse successfully created]', 'erp/warehouse/warehouses', '', 'Qbs Suppoer', '2023-12-27 10:30:38'),
(833, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete3', '{\"warehouse_id\":\"3\",\"name\":\"Thamizharasi\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"0\",\"description\":\"\",\"aisle_count\":\"0\",\"racks_per_aisle\":\"0\",\"shelf_per_rack\":\"0\",\"bins_per_shelf\":\"0\"}', 'Qbs Suppoer', '2023-12-27 10:31:39'),
(834, 'Warehouse Insert', '[ Warehouse successfully created]', 'erp/warehouse/warehouses', '', 'Qbs Suppoer', '2023-12-27 10:32:02'),
(835, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Qbs Suppoer', '2023-12-27 10:32:20'),
(836, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete14', '{\"warehouse_id\":\"14\",\"name\":\"ashok kumar\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"1\",\"description\":\"okay \",\"aisle_count\":\"44\",\"racks_per_aisle\":\"45\",\"shelf_per_rack\":\"55\",\"bins_per_shelf\":\"5\"}', 'Qbs Suppoer', '2023-12-27 10:32:26'),
(837, 'Warehouse Insert', '[ Warehouse successfully created]', 'erp/warehouse/warehouses', '', 'Qbs Suppoer', '2023-12-27 10:32:48'),
(838, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/2', '', 'Qbs Suppoer', '2023-12-27 10:33:28'),
(839, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Suppoer', '2023-12-27 10:33:51'),
(840, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Suppoer', '2023-12-27 10:34:10'),
(841, 'RFQ Resend', '[ RFQ Resend sucessfully created ]', 'erp/procurement/rfqview/5', '', 'Qbs Suppoer', '2023-12-27 10:36:57'),
(842, 'RFQ Resend', '[ RFQ Resend sucessfully created ]', 'erp/procurement/rfqview/5', '', 'Qbs Suppoer', '2023-12-27 10:38:39'),
(843, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Suppoer', '2023-12-27 10:53:28'),
(844, 'RFQ Resend', '[ RFQ Resend sucessfully created ]', 'erp/procurement/rfqview/5', '', 'Qbs Suppoer', '2023-12-27 11:43:47'),
(845, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/39', '', 'Qbs Suppoer', '2023-12-27 12:11:57'),
(846, 'GRN Insert', '[ GRN successfully created ]', 'erp/procurement/orderview/3', '', 'Qbs Suppoer', '2023-12-27 12:26:48'),
(847, 'Purchase Invoice Insert', '[ Purchase Invoice successfully created ]', 'erp/procurement/orderview/3', '', 'Qbs Suppoer', '2023-12-27 12:29:47'),
(848, 'Purchase Payment Insert', '[ Purchase Payment successfully created ]', 'erp/procurement/invoiceview/2', '', 'Qbs Suppoer', '2023-12-27 12:59:42'),
(849, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/3', '', 'Qbs Suppoer', '2023-12-27 13:58:04'),
(850, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 04:34:23'),
(851, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 04:37:25'),
(852, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 04:48:02'),
(853, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 04:51:09'),
(854, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 06:46:05'),
(855, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 07:22:44'),
(856, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 07:23:11'),
(857, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 07:26:39'),
(858, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 07:28:31'),
(859, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 07:29:06'),
(860, 'Credit Note Insert', '[ Credit Note successfully created ]', 'erp/sale/creditview/3', '', 'Qbs Suppoer', '2023-12-28 07:33:15'),
(861, 'Credit Note Insert', '[ Credit Note successfully created ]', 'erp/sale/creditview/4', '', 'Qbs Suppoer', '2023-12-28 07:34:59'),
(862, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/40', '', 'Qbs Suppoer', '2023-12-28 07:56:17'),
(863, 'Credit Note Insert', '[ Credit Note successfully created ]', 'erp/sale/creditview/5', '', 'Qbs Suppoer', '2023-12-28 09:07:10'),
(864, 'Account Group Insert', '[ Account Group successfully created ]', 'erp/finance/accountgroup/', '', 'Qbs Suppoer', '2023-12-28 09:18:55'),
(865, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 09:32:52'),
(866, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 09:40:44'),
(867, 'Account Group Delete', '[ Account Group successfully deleted ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 09:46:12'),
(868, 'GL Account Delete', '[ GL Account successfully deleted ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 09:46:24'),
(869, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 10:29:28'),
(870, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-28 10:30:12'),
(871, 'Sale Order Notification Delete', '[ Sale Order Notification successfully deleted ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 10:40:43'),
(872, 'Sale Order Notification Delete', '[ Sale Order Notification failed to delete ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 10:41:42'),
(873, 'Sale Order Notification Delete', '[ Sale Order Notification successfully deleted ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 10:41:53'),
(874, 'Sale Order Notification Delete', '[ Sale Order Notification successfully deleted ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 10:42:00'),
(875, 'GL Account Insert', '[ GL Account successfully created ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 10:46:31'),
(876, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'Qbs Suppoer', '2023-12-28 10:47:00'),
(877, 'GL Account Delete', '[ GL Account failed to delete ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 10:47:52'),
(878, 'Sale Order Notification Update', '[ Sale Order Notification successfully updated ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 10:48:34'),
(879, 'GL Account Update', '[ GL Account successfully updated ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 10:48:35'),
(880, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 10:48:40'),
(881, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 10:48:50'),
(882, 'Sale Order Notification Update', '[ Sale Order Notification successfully updated ]', 'erp/sale/orderview/1', '', 'Qbs Suppoer', '2023-12-28 10:48:53'),
(883, 'Account Group Update', '[ Account Group successfully updated ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 10:49:23'),
(884, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 10:49:30'),
(885, 'GL Account Delete', '[ GL Account failed to delete ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 10:51:20'),
(886, 'Account Group Delete', '[ Account Group successfully deleted ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 10:53:05'),
(887, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 10:53:20'),
(888, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/4', '', 'Qbs Suppoer', '2023-12-28 11:43:32'),
(889, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/4', '', 'Qbs Suppoer', '2023-12-28 11:44:33'),
(890, 'GL Account Update', '[ GL Account successfully updated ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:44:41'),
(891, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/4', '', 'Qbs Suppoer', '2023-12-28 11:45:02'),
(892, 'GL Account Delete', '[ GL Account failed to delete ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:48:47'),
(893, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 11:49:04'),
(894, 'Account Group Insert', '[ Account Group successfully created ]', 'erp/finance/accountgroup/', '', 'Qbs Suppoer', '2023-12-28 11:49:17'),
(895, 'Account Group Delete', '[ Account Group successfully deleted ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 11:49:24'),
(896, 'Account Group Insert', '[ Account Group successfully created ]', 'erp/finance/accountgroup/', '', 'Qbs Suppoer', '2023-12-28 11:49:34'),
(897, 'GL Account Update', '[ GL Account successfully updated ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:49:51'),
(898, 'Bank Account Update', '[ Bank Account failed to update ]', 'erp/finance/bankaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:50:37'),
(899, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:50:50'),
(900, 'Account Group Delete', '[ Account Group failed to delete ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-28 11:51:08'),
(901, 'GL Account Delete', '[ GL Account failed to delete ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:51:28'),
(902, 'GL Account Update', '[ GL Account successfully updated ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 11:52:09'),
(903, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/26', '', 'Qbs Suppoer', '2023-12-28 11:54:10'),
(904, 'GL Account Insert', '[ GL Account successfully created ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 12:00:37'),
(905, 'GL Account Delete', '[ GL Account successfully deleted ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-28 12:00:48'),
(906, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/3', '{\"estimate_id\":\"3\",\"code\":\"EST1\",\"estimate_date\":\"2022-04-05\",\"terms_condition\":\"Hello\",\"name\":\"Kevin\",\"cust_id\":\"8\",\"shippingaddr_id\":\"0\"}', 'Qbs Suppoer', '2023-12-28 12:16:34'),
(907, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/4', '', 'Qbs Suppoer', '2023-12-28 12:18:22'),
(908, 'Estimate Notification Delete', '[ Estimate Notification successfully deleted ]', 'erp/sale/estimateview/4', '', 'Qbs Suppoer', '2023-12-28 12:30:09'),
(909, 'Estimate Notification Delete', '[ Estimate Notification failed to delete ]', 'erp/sale/estimateview/4', '', 'Qbs Suppoer', '2023-12-28 12:31:46'),
(910, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/4', '', 'Qbs Suppoer', '2023-12-28 12:33:03'),
(911, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/4', '', 'Qbs Suppoer', '2023-12-28 12:33:30'),
(912, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/4', '', 'Qbs Suppoer', '2023-12-28 12:33:54'),
(913, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:34:30'),
(914, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/4', '{\"estimate_id\":\"4\",\"code\":\"EST2\",\"estimate_date\":\"2022-05-05\",\"terms_condition\":\"hello\",\"name\":\"Sam\",\"cust_id\":\"9\",\"shippingaddr_id\":\"0\"}', 'Qbs Suppoer', '2023-12-28 12:35:17'),
(915, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/23', '', 'Qbs Suppoer', '2023-12-28 12:35:46'),
(916, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:38:11'),
(917, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:40:16'),
(918, 'Estimate Notification Update', '[ Estimate Notification successfully updated ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:41:07'),
(919, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:41:12'),
(920, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/23', '', 'Qbs Suppoer', '2023-12-28 12:41:25'),
(921, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/23', '', 'Qbs Suppoer', '2023-12-28 12:41:36'),
(922, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/23', '', 'Qbs Suppoer', '2023-12-28 12:41:46'),
(923, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:42:12'),
(924, 'Estimate Notification Update', '[ Estimate Notification successfully updated ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:42:17'),
(925, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:57:16'),
(926, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-28 12:57:49'),
(927, 'Quotation Notification Update', '[ Quotation Notification successfully updated ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-28 12:58:50'),
(928, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-28 13:01:52'),
(929, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 04:54:16'),
(930, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 04:56:05'),
(931, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 05:07:21'),
(932, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 05:09:39'),
(933, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 05:10:02'),
(934, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 05:10:32'),
(935, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 05:11:41'),
(936, 'Lead Insert', '[ Lead successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/17', '', 'Qbs Suppoer', '2023-12-29 05:14:50'),
(937, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/6', '', 'Qbs Suppoer', '2023-12-29 05:16:05'),
(938, 'Customer Contact Update', '[ Customer Contact successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:16:52'),
(939, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:18:19'),
(940, 'Customer Shipping Address Update', '[ Customer Shipping Address successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:18:51'),
(941, 'Customer Shipping Address Delete', '[ Customer Shipping Address successfully deleted ]', '/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:18:59'),
(942, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:19:10'),
(943, 'Customer Notification Insert', '[ Customer Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:20:08'),
(944, 'Customer Notification Update', '[ Customer Notification successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:21:22'),
(945, 'Customer Notification Update', '[ Customer Notification successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:21:36'),
(946, 'Customer Notification Delete', '[ Customer Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:22:00'),
(947, 'Customer Notification Delete', '[ Customer Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/6', '', 'Qbs Suppoer', '2023-12-29 05:22:12'),
(948, 'Finance Automation', '[ Finance Automation added Marketing Entry ; ID= ]', '', '', 'Qbs Suppoer', '2023-12-29 05:22:59'),
(949, 'Marketing Insert', '[ Marketing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:22:59'),
(950, 'Marketing Update', '[ Marketing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:23:15'),
(951, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:23:21'),
(952, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:23:47'),
(953, 'Ticket Update', '[ Ticket successfully updated ]', 'erp/crm/tickets', '', 'Qbs Suppoer', '2023-12-29 05:23:57'),
(954, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Suppoer', '2023-12-29 05:24:27'),
(955, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:31:50'),
(956, 'Account Group Update', '[ Account Group successfully updated ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-29 05:34:42'),
(957, 'Account Group Delete', '[ Account Group successfully deleted ]', 'erp/finance/accountgroups/', '', 'Qbs Suppoer', '2023-12-29 05:34:47'),
(958, 'Account Group Insert', '[ Account Group successfully created ]', 'erp/finance/accountgroup/', '', 'Qbs Suppoer', '2023-12-29 05:35:04'),
(959, 'GL Account Import', '[ GL Account successfully imported ]', '', '', 'Qbs Suppoer', '2023-12-29 05:35:36'),
(960, 'GL Account Delete', '[ GL Account failed to delete ]', 'erp/finance/glaccounts/', '', 'Qbs Suppoer', '2023-12-29 05:35:58'),
(961, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Suppoer', '2023-12-29 05:37:07'),
(962, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'Qbs Suppoer', '2023-12-29 05:37:56'),
(963, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Suppoer', '2023-12-29 05:38:06'),
(964, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/11', '', 'Qbs Suppoer', '2023-12-29 05:39:05'),
(965, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:39:30'),
(966, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Suppoer', '2023-12-29 05:39:56'),
(967, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 05:40:01'),
(968, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:40:04'),
(969, 'Customer Notification Insert', '[ Customer Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Qbs Suppoer', '2023-12-29 05:40:45'),
(970, 'Journal Entry Delete', '[ Journal Entry successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Suppoer', '2023-12-29 05:40:58'),
(971, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:41:06'),
(972, 'Journal Entry Delete', '[ Journal Entry successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Suppoer', '2023-12-29 05:41:07'),
(973, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/41', '', 'Qbs Suppoer', '2023-12-29 05:41:08'),
(974, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:41:54'),
(975, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Suppoer', '2023-12-29 05:42:07'),
(976, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:42:18'),
(977, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:42:33'),
(978, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Suppoer', '2023-12-29 05:43:28'),
(979, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 05:46:19'),
(980, 'Automation Delete', '[ Automation successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Suppoer', '2023-12-29 05:47:48'),
(981, 'Automation Insert', '[ Automation successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Suppoer', '2023-12-29 05:48:41'),
(982, 'Payment Mode Update', '[ Payment Mode successfully updated ]', 'erp/finance/paymentmode/', '', 'Qbs Suppoer', '2023-12-29 05:49:08'),
(983, 'Payment Mode Delete', '[ Payment Mode successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Suppoer', '2023-12-29 05:49:17'),
(984, 'Payment Mode Insert', '[ Payment Mode successfully created ]', 'erp/finance/paymentmode/', '', 'Qbs Suppoer', '2023-12-29 05:49:26'),
(985, 'Tax Insert', '[ Tax successfully created ]', 'erp/finance/tax/', '', 'Qbs Suppoer', '2023-12-29 05:49:53'),
(986, 'Tax Delete', '[ Tax successfully deleted ]', 'erp/finance/tax/', '', 'Qbs Suppoer', '2023-12-29 05:50:08'),
(987, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:50:14'),
(988, 'Estimate Notification Update', '[ Estimate Notification successfully updated ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:50:38'),
(989, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Suppoer', '2023-12-29 05:50:56'),
(990, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:51:15'),
(991, 'Estimate Notification Delete', '[ Estimate Notification successfully deleted ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 05:51:22'),
(992, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Suppoer', '2023-12-29 05:52:02'),
(993, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Suppoer', '2023-12-29 05:52:07'),
(994, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 05:54:00'),
(995, 'Quotation Notification Update', '[ Quotation Notification successfully updated ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 05:57:56'),
(996, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 05:58:18'),
(997, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 05:58:46'),
(998, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 05:58:56'),
(999, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 05:59:12'),
(1000, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 05:59:38'),
(1001, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 06:01:14'),
(1002, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 06:01:48'),
(1003, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:05:47'),
(1004, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:05:59'),
(1005, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 06:06:04'),
(1006, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 06:06:10'),
(1007, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:06:30'),
(1008, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:06:40'),
(1009, 'Quotation Notification Insert', '[ Quotation Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/quotations_view/1', '', 'Qbs Suppoer', '2023-12-29 06:06:55'),
(1010, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 06:07:10'),
(1011, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:07:19'),
(1012, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:07:46'),
(1013, 'Quotation Notification Insert', '[ Quotation Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/quotations_view/2', '', 'Qbs Suppoer', '2023-12-29 06:08:58'),
(1014, 'Quotation Notification Update', '[ Quotation Notification successfully updated ]', 'erp/sale/quotationview/2', '', 'Qbs Suppoer', '2023-12-29 06:09:11'),
(1015, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/2', '', 'Qbs Suppoer', '2023-12-29 06:09:19'),
(1016, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/2', '', 'Qbs Suppoer', '2023-12-29 06:09:25'),
(1017, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/2', '', 'Qbs Suppoer', '2023-12-29 06:09:37'),
(1018, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 06:11:01'),
(1020, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:12:22'),
(1021, 'Semi Finished Update', '[ Semi Finished successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:13:23'),
(1022, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/27', '', 'Qbs Suppoer', '2023-12-29 06:14:15'),
(1023, 'Stock Alert Update', '[ Stock Alert failed to update ]', 'erp/inventory/semifinishedview/2', '', 'Qbs Suppoer', '2023-12-29 06:14:30'),
(1024, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/27', '', 'Qbs Suppoer', '2023-12-29 06:15:05'),
(1025, 'Sale Order Notification Update', '[ Sale Order Notification successfully updated ]', 'erp/sale/orderview/27', '', 'Qbs Suppoer', '2023-12-29 06:15:41'),
(1026, 'Sale Order Notification Delete', '[ Sale Order Notification successfully deleted ]', 'erp/sale/orderview/27', '', 'Qbs Suppoer', '2023-12-29 06:15:56'),
(1027, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/27', '', 'Qbs Suppoer', '2023-12-29 06:17:21'),
(1028, 'Sale Order Notification Delete', '[ Sale Order Notification successfully deleted ]', 'erp/sale/orderview/27', '', 'Qbs Suppoer', '2023-12-29 06:18:18'),
(1029, 'Finished Good Update', '[ Finished Good successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:19:49'),
(1031, ' Service Insert', '[ Service successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:21:22'),
(1032, ' Service Update', '[ Service successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:21:33'),
(1033, 'Amenity Insert', '[ Amenity successfully created ]', 'erp/inventory/amenity', '', 'Qbs Suppoer', '2023-12-29 06:23:57'),
(1034, 'Amenity Update', '[ Amenity successfully updated ]', 'erp/inventory/amenity', '', 'Qbs Suppoer', '2023-12-29 06:24:05'),
(1035, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/12', '', 'Qbs Suppoer', '2023-12-29 06:25:07'),
(1036, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/12', '', 'Qbs Suppoer', '2023-12-29 06:26:00'),
(1037, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-29 06:26:29'),
(1038, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-29 06:28:14'),
(1039, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-29 06:28:37'),
(1040, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-29 06:28:45'),
(1041, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Qbs Suppoer', '2023-12-29 06:29:03'),
(1042, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Suppoer', '2023-12-29 06:29:15'),
(1043, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-29 06:29:23'),
(1044, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Suppoer', '2023-12-29 06:29:36'),
(1045, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/1', '', 'Qbs Suppoer', '2023-12-29 06:29:38'),
(1046, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Suppoer', '2023-12-29 06:29:45'),
(1047, 'Unit Insert', '[ Unit successfully created ]', 'erp/inventory/units', '', 'Qbs Suppoer', '2023-12-29 06:29:55'),
(1048, 'Unit Update', '[ Unit successfully updated ]', 'erp/inventory/units', '', 'Qbs Suppoer', '2023-12-29 06:30:12'),
(1049, 'Unit Delete', '[ Unit successfully deleted ]', 'erp/inventory/units', '', 'Qbs Suppoer', '2023-12-29 06:30:32'),
(1050, 'Brand Insert', '[ Brand successfully created ]', 'erp/inventory/brands', '', 'Qbs Suppoer', '2023-12-29 06:30:46'),
(1051, 'Brand Update', '[ Brand successfully updated ]', 'erp/inventory/brands', '', 'Qbs Suppoer', '2023-12-29 06:31:05'),
(1052, 'Brand Delete', '[ Brand successfully deleted ]', 'erp/inventory/brands', '', 'Qbs Suppoer', '2023-12-29 06:31:10'),
(1053, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete15', '{\"warehouse_id\":\"15\",\"name\":\"ashok kumar\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"1\",\"description\":\"okay\",\"aisle_count\":\"44\",\"racks_per_aisle\":\"78\",\"shelf_per_rack\":\"635\",\"bins_per_shelf\":\"87\"}', 'Qbs Suppoer', '2023-12-29 06:33:05'),
(1054, 'Credit Notes Notification Update', '[ Credit Notes Notification successfully updated ]', 'erp/sale/creditview/2', '', 'Qbs Suppoer', '2023-12-29 06:33:45'),
(1055, 'Credit Notes Notification Delete', '[ Credit Notes Notification successfully deleted ]', 'erp/sale/creditview/2', '', 'Qbs Suppoer', '2023-12-29 06:33:57'),
(1056, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/55846', '', 'Qbs Suppoer', '2023-12-29 06:34:51'),
(1057, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/3', '', 'Qbs Suppoer', '2023-12-29 06:35:23'),
(1058, 'Stock Transfer', '[ Stock Transfer failed ]', 'erp/warehouse/currentstock', '', 'Qbs Suppoer', '2023-12-29 06:36:39'),
(1059, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Suppoer', '2023-12-29 06:36:51'),
(1060, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Suppoer', '2023-12-29 06:37:20'),
(1061, 'Credit Notes Notification Update', '[ Credit Notes Notification successfully updated ]', 'erp/sale/creditview/3', '', 'Qbs Suppoer', '2023-12-29 06:40:17'),
(1062, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/27', '[{\"invent_req_id\":\"27\",\"req_id\":\"27\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"27\",\"req_code\":\"RFQ-124\",\"assigned_to\":\"1\",\"status\":\"2\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"testing\",\"remarks\":\"trying\",\"created_at\":\"1703586847\",\"created_by\":\"1\"}]', 'Qbs Suppoer', '2023-12-29 06:46:15'),
(1063, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/33', '[{\"invent_req_id\":\"33\",\"req_id\":\"33\",\"related_to\":\"semi_finished\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"33\",\"req_code\":\"55454\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"1\",\"mail_sent\":\"1\",\"description\":\"aeryea\",\"remarks\":\"\",\"created_at\":\"1703832198\",\"created_by\":\"1\"}]', 'Qbs Suppoer', '2023-12-29 06:46:21'),
(1064, 'Supplier Import', '[ Supplier successfully imported ]', '', '', 'Qbs Suppoer', '2023-12-29 06:46:31'),
(1065, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/30', '[{\"invent_req_id\":\"30\",\"req_id\":\"30\",\"related_to\":\"semi_finished\",\"related_id\":\"2\",\"qty\":\"5\"},{\"req_id\":\"30\",\"req_code\":\"test-123\",\"assigned_to\":\"1\",\"status\":\"2\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"test\",\"remarks\":\"going on\",\"created_at\":\"1703592568\",\"created_by\":\"1\"}]', 'Qbs Suppoer', '2023-12-29 06:47:14'),
(1066, 'RFQ Update', '[ RFQ successfully updated ]', 'erp/procurement/rfqview/6', '', 'Qbs Suppoer', '2023-12-29 06:48:26'),
(1067, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/6', '', 'Qbs Suppoer', '2023-12-29 06:49:35'),
(1068, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:49:59'),
(1069, 'Purchase Payment Insert', '[ Purchase Payment successfully created ]', 'erp/procurement/invoiceview/2', '', 'Qbs Suppoer', '2023-12-29 06:51:28'),
(1070, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/48', '', 'Qbs Suppoer', '2023-12-29 06:51:29'),
(1071, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:54:11'),
(1072, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:54:25'),
(1073, 'Transport Type Update', '[ Transport Type successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:54:43'),
(1074, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'Qbs Suppoer', '2023-12-29 06:54:49'),
(1075, 'Transport Insert', '[ Transport successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 06:55:08'),
(1076, 'Transport Update', '[ Transport successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:55:17'),
(1077, 'Transport Delete', '[ Transport successfully deleted ]', '', '', 'Qbs Suppoer', '2023-12-29 06:55:23'),
(1078, 'Delivery Record Update', '[ Delivery Record successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:55:45'),
(1079, 'Delivery Record Update', '[ Delivery Record successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 06:55:50'),
(1080, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/9', '', 'Qbs Suppoer', '2023-12-29 06:56:36'),
(1081, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/9', '', 'Qbs Suppoer', '2023-12-29 06:57:10'),
(1082, 'Workgroup Insert', '[ Workgroup successfully created ]', 'erp/project/workgroups/', '', 'Qbs Suppoer', '2023-12-29 07:00:13'),
(1083, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/21', '', 'Qbs Suppoer', '2023-12-29 07:00:32'),
(1084, 'Workgroup Delete', '[ Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Suppoer', '2023-12-29 07:00:57'),
(1085, 'Supplier Contact Update', '[ Supplier Contact successfully updated ]', 'erp/supplier/supplier-view/21', '', 'Qbs Suppoer', '2023-12-29 07:01:09'),
(1086, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/19', '', 'Qbs Suppoer', '2023-12-29 07:01:48'),
(1087, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/21', '', 'Qbs Suppoer', '2023-12-29 07:02:33'),
(1088, 'Project Update', '[ Project successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/19', '', 'Qbs Suppoer', '2023-12-29 07:03:24'),
(1089, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:03:48'),
(1090, 'Project Phase Update', '[ Project Phase successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:04:33'),
(1091, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/21', '', 'Qbs Suppoer', '2023-12-29 07:05:26'),
(1092, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/21', '', 'Qbs Suppoer', '2023-12-29 07:05:38'),
(1093, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:05:59'),
(1094, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:06:36'),
(1095, 'Project Rawmaterials Update', '[ Project Rawmaterials successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:07:01'),
(1096, 'Project Rawmaterials Delete', '[ Project Rawmaterials successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:07:10'),
(1097, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Qbs Suppoer', '2023-12-29 07:07:12'),
(1098, 'Supplier Source Update', '[ Supplier Source successfully updated ]', 'erp/supplier/sources', '', 'Qbs Suppoer', '2023-12-29 07:08:23'),
(1099, 'Supplier Source Update', '[ Supplier Source successfully updated ]', 'erp/supplier/sources', '', 'Qbs Suppoer', '2023-12-29 07:08:28'),
(1100, 'Supplier Source Insert', '[ Supplier Source successfully created ]', 'erp/supplier/sources', '', 'Qbs Suppoer', '2023-12-29 07:08:40'),
(1101, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Suppoer', '2023-12-29 07:08:45');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(1102, 'Supplier Source Delete', '[ Supplier Source successfully deleted ]', '', '', 'Qbs Suppoer', '2023-12-29 07:08:51'),
(1103, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Suppoer', '2023-12-29 07:09:48'),
(1104, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Suppoer', '2023-12-29 07:10:04'),
(1105, 'Supplier Segment Update', '[ Supplier Segment successfully updated ]', 'erp/supplier/segments', '', 'Qbs Suppoer', '2023-12-29 07:11:12'),
(1106, 'Supplier Segment Insert', '[ Supplier Segment successfully created ]', 'erp/supplier/segments', '', 'Qbs Suppoer', '2023-12-29 07:11:29'),
(1107, 'Equipment Insert', '[ Equipment successfully created ]', 'erp/assets/add_equipment/5', '', 'Qbs Suppoer', '2023-12-29 07:11:32'),
(1108, 'Equipment Deletion', '[ Equipment successfully deleted ]', 'erp/assets/delete_equipment/5', '{\"equip_id\":\"5\",\"name\":\"Thamizharasi\",\"code\":\"b6501\",\"model\":\"esrah\",\"maker\":\"aerah\",\"bought_date\":\"2023-12-29\",\"age\":\"20\",\"work_type\":\"Automatic\",\"consump_type\":\"Electric\",\"consumption\":\"eth\",\"status\":\"1\",\"description\":\"eaaaaar\",\"created_at\":\"2023-12-29 07:11:32\",\"created_by\":\"1\",\"updated_at\":\"2023-12-29 07:11:32\"}', 'Qbs Suppoer', '2023-12-29 07:11:46'),
(1109, 'Equipment Update', '[ Equipment successfully updated ]', 'erp/asset/edit_equipment/2', '', 'Qbs Suppoer', '2023-12-29 07:12:09'),
(1110, 'Equipment Deletion', '[ Equipment successfully deleted ]', 'erp/assets/delete_equipment/2', '{\"equip_id\":\"2\",\"name\":\"test124\",\"code\":\"EQ124\",\"model\":\"ABC-0002\",\"maker\":\"test\",\"bought_date\":\"2022-04-02\",\"age\":\"\",\"work_type\":\"Manual\",\"consump_type\":\"Fuel\",\"consumption\":\"\",\"status\":\"1\",\"description\":\"hello\",\"created_at\":\"1650267407\",\"created_by\":\"1\",\"updated_at\":\"\"}', 'Qbs Suppoer', '2023-12-29 07:12:16'),
(1111, 'Selection Rule Insert', '[ Selection Rule successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 07:12:51'),
(1112, 'Department Insert', '[ Department successfully created ]', 'erp/hr/departments/', '', 'Qbs Suppoer', '2023-12-29 07:13:10'),
(1113, 'Department Update', '[ Department successfully updated ]', 'erp/hr/departments/', '', 'Qbs Suppoer', '2023-12-29 07:13:28'),
(1114, 'Department Delete', '[ Department successfully deleted ]', 'erp/hr/departments/', '', 'Qbs Suppoer', '2023-12-29 07:13:33'),
(1115, 'Designation Insert', '[ Designation successfully created ]', 'erp/hr/designation/', '', 'Qbs Suppoer', '2023-12-29 07:15:27'),
(1116, 'Designation Update', '[ Designation successfully updated ]', 'erp/hr/designation/', '', 'Qbs Suppoer', '2023-12-29 07:15:41'),
(1117, 'Designation Delete', '[ Designation successfully deleted ]', 'erp/hr/designation/', '', 'Qbs Suppoer', '2023-12-29 07:15:44'),
(1118, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Suppoer', '2023-12-29 07:22:37'),
(1119, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Qbs Suppoer', '2023-12-29 07:23:16'),
(1122, 'Employee Import', '[ Employee partially imported ]', '', '', 'Qbs Suppoer', '2023-12-29 07:24:40'),
(1123, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Qbs Suppoer', '2023-12-29 07:25:29'),
(1125, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Suppoer', '2023-12-29 07:27:20'),
(1126, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Suppoer', '2023-12-29 07:28:00'),
(1127, 'Deduction Insert', '[ Deduction successfully created ]', 'erp/hr/deductions/', '', 'Qbs Suppoer', '2023-12-29 07:29:34'),
(1128, 'Role Update', '[ Role successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/role-view/21', '', 'Qbs Suppoer', '2023-12-29 07:29:38'),
(1129, 'Deduction Delete', '[ Deduction successfully deleted ]', 'erp/hr/deductions/', '', 'Qbs Suppoer', '2023-12-29 07:29:39'),
(1130, 'Deduction Update', '[ Deduction successfully updated ]', 'erp/hr/deductions/', '', 'Qbs Suppoer', '2023-12-29 07:29:47'),
(1131, 'Addition Insert', '[ Addition successfully created ]', 'erp/hr/additions/', '', 'Qbs Suppoer', '2023-12-29 07:30:06'),
(1132, 'Role Update', '[ Role successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/role-view/22', '', 'Qbs Suppoer', '2023-12-29 07:30:14'),
(1133, 'Addition Update', '[ Addition successfully updated ]', 'erp/hr/additions/', '', 'Qbs Suppoer', '2023-12-29 07:30:17'),
(1134, 'Addition Delete', '[ Addition successfully deleted ]', 'erp/hr/additions/', '', 'Qbs Suppoer', '2023-12-29 07:30:22'),
(1135, 'Payroll Insert', '[ Payroll successfully created ]', 'erp/hr/payrolls', '', 'Qbs Suppoer', '2023-12-29 07:30:46'),
(1136, 'Payroll Update', '[ Payroll successfully updated ]', 'erp/hr/payrolls', '', 'Qbs Suppoer', '2023-12-29 07:31:00'),
(1137, 'Payroll Update', '[ Payroll successfully updated ]', 'erp/hr/payrolls', '', 'Qbs Suppoer', '2023-12-29 07:31:00'),
(1138, 'Payroll Process', '[ Payroll successfully processed ]', 'erp/hr/payrolls', '', 'Qbs Suppoer', '2023-12-29 07:31:06'),
(1139, 'Payroll Delete', '[ Payroll successfully deleted ]', 'erp/hr/payrolls', '', 'Qbs Suppoer', '2023-12-29 07:31:19'),
(1140, 'Group Insert', '[ Group successfully inserted ]', '', '', 'Qbs Suppoer', '2023-12-29 07:32:09'),
(1141, 'Finance Settings Update', '[ Finance Settings successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 07:33:23'),
(1142, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Suppoer', '2023-12-29 07:35:16'),
(1143, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Suppoer', '2023-12-29 07:36:10'),
(1144, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 07:36:29'),
(1145, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 07:42:52'),
(1146, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 07:43:12'),
(1147, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 07:43:50'),
(1148, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 07:45:54'),
(1149, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 07:47:02'),
(1150, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 07:49:41'),
(1151, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:06:36'),
(1152, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:17:21'),
(1153, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 09:21:23'),
(1154, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:24:31'),
(1155, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:31:35'),
(1156, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:31:49'),
(1157, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:32:32'),
(1158, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:33:45'),
(1159, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 09:34:34'),
(1160, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 09:37:38'),
(1161, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Suppoer', '2023-12-29 09:38:01'),
(1162, 'Ticket Update', '[ Ticket successfully updated ]', 'erp/crm/tickets', '', 'Qbs Suppoer', '2023-12-29 09:38:12'),
(1163, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 09:38:18'),
(1164, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Suppoer', '2023-12-29 09:39:03'),
(1165, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Suppoer', '2023-12-29 09:39:39'),
(1166, 'Bank Account Update', '[ Bank Account successfully updated ]', 'erp/finance/bankaccounts/', '', 'Qbs Suppoer', '2023-12-29 09:51:34'),
(1167, 'Journal Entry Delete', '[ Journal Entry successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Suppoer', '2023-12-29 09:54:11'),
(1168, 'Journal Entry Insert', '[ Journal Entry successfully created ]', 'erp/finance/journalentry/', '', 'Qbs Suppoer', '2023-12-29 09:58:50'),
(1169, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Suppoer', '2023-12-29 10:02:27'),
(1170, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 10:05:45'),
(1171, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Suppoer', '2023-12-29 10:07:53'),
(1172, 'Automation Delete', '[ Automation successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Suppoer', '2023-12-29 10:09:54'),
(1173, 'Automation Insert', '[ Automation successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Suppoer', '2023-12-29 10:10:17'),
(1174, 'Automation Update', '[ Automation successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Suppoer', '2023-12-29 10:11:29'),
(1175, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/34', '', 'Qbs Suppoer', '2023-12-29 10:12:04'),
(1176, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/35', '', 'Qbs Suppoer', '2023-12-29 10:12:41'),
(1177, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/36', '', 'Qbs Suppoer', '2023-12-29 10:13:09'),
(1178, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/36', '[{\"invent_req_id\":\"39\",\"req_id\":\"36\",\"related_to\":\"raw_material\",\"related_id\":\"24\",\"qty\":\"10\"},{\"req_id\":\"36\",\"req_code\":\"testing testing\",\"assigned_to\":\"1\",\"status\":\"0\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"test\",\"remarks\":\"\",\"created_at\":\"1703844788\",\"created_by\":\"1\"}]', 'Qbs Suppoer', '2023-12-29 10:13:51'),
(1179, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/32', '', 'Qbs Suppoer', '2023-12-29 10:14:23'),
(1180, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/32', '', 'Qbs Suppoer', '2023-12-29 10:14:30'),
(1181, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/22', '', 'Qbs Suppoer', '2023-12-29 10:15:12'),
(1182, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/5', '', 'Qbs Suppoer', '2023-12-29 10:15:47'),
(1183, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:45:42'),
(1184, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:45:56'),
(1185, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:47:00'),
(1186, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:51:03'),
(1187, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:51:10'),
(1188, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:51:25'),
(1189, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:52:01'),
(1190, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 10:52:16'),
(1191, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/37', '', 'Qbs Suppoer', '2023-12-29 10:53:13'),
(1192, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/37', '', 'Qbs Suppoer', '2023-12-29 10:53:29'),
(1193, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:14:19'),
(1194, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:16:17'),
(1195, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:16:25'),
(1196, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:17:35'),
(1197, 'Quotation Notification Delete', '[ Quotation Notification failed to delete ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:17:59'),
(1198, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-29 11:19:39'),
(1199, 'Quotation Notification Delete', '[ Quotation Notification successfully deleted ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:22:00'),
(1200, 'Quotation Notification Delete', '[ Quotation Notification successfully deleted ]', 'erp/sale/quotationview/1', '', 'Qbs Suppoer', '2023-12-29 11:24:54'),
(1201, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 11:26:03'),
(1202, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/24', '', 'Qbs Suppoer', '2023-12-29 11:38:54'),
(1203, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 11:41:07'),
(1204, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 11:48:05'),
(1205, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'erp/inventory/semifinishedview/12', '', 'Qbs Suppoer', '2023-12-29 11:56:39'),
(1206, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 11:58:03'),
(1207, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 11:59:26'),
(1208, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'erp/inventory/semifinishedview/14', '', 'Qbs Suppoer', '2023-12-29 12:00:04'),
(1209, 'Requisition Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/6', '[{\"rfq_id\":\"6\",\"rfq_code\":\"RFQ1436\",\"req_id\":\"31\",\"expiry_date\":\"2023-12-31\",\"terms_condition\":\"fsdg\",\"created_at\":\"1703660975\",\"created_by\":\"1\",\"status\":\"0\"},{\"supp_rfq_id\":\"7\",\"rfq_id\":\"6\",\"supplier_id\":\"3\",\"selection_rule\":\"supply_list\",\"mail_status\":\"0\",\"send_contacts\":\"1\",\"include_attach\":\"1\",\"responded\":\"0\",\"responded_at\":\"\"}]', 'Qbs Support', '2023-12-29 12:11:01'),
(1210, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 12:13:30'),
(1211, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 12:14:04'),
(1212, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/7', '', 'Qbs Support', '2023-12-29 12:14:39'),
(1213, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Suppoer', '2023-12-29 12:16:00'),
(1214, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/7', '', 'Qbs Support', '2023-12-29 12:19:33'),
(1215, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Suppoer', '2023-12-29 13:04:09'),
(1216, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/rfqview/7', '', 'Qbs Support', '2023-12-29 13:18:29'),
(1217, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/rfqview/7', '', 'Qbs Support', '2023-12-29 13:19:51'),
(1218, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/rfqview/7', '', 'Qbs Support', '2023-12-29 13:19:56'),
(1219, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/31', '[{\"invent_req_id\":\"31\",\"req_id\":\"31\",\"related_to\":\"semi_finished\",\"related_id\":\"2\",\"qty\":\"10\"},{\"req_id\":\"31\",\"req_code\":\"Orders\",\"assigned_to\":\"1\",\"status\":\"2\",\"priority\":\"2\",\"mail_sent\":\"0\",\"description\":\"zdfsf\",\"remarks\":\"test\",\"created_at\":\"1703660668\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-29 13:26:11'),
(1220, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/8', '', 'Qbs Support', '2023-12-29 13:26:54'),
(1221, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/8', '', 'Qbs Support', '2023-12-29 13:27:17'),
(1222, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-29 13:55:45'),
(1223, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-30 04:48:59'),
(1224, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Support', '2023-12-30 04:58:40'),
(1225, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 04:59:58'),
(1226, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 05:02:44'),
(1227, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-30 05:05:09'),
(1228, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 05:14:25'),
(1229, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:27:36'),
(1230, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/32', '[{\"invent_req_id\":\"32\",\"req_id\":\"32\",\"related_to\":\"semi_finished\",\"related_id\":\"8\",\"qty\":\"15\"},{\"req_id\":\"32\",\"req_code\":\"Order Y\",\"assigned_to\":\"1\",\"status\":\"2\",\"priority\":\"3\",\"mail_sent\":\"0\",\"description\":\"tes\",\"remarks\":\"test\",\"created_at\":\"1703661076\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 05:32:47'),
(1231, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:02'),
(1232, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:04'),
(1233, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:05'),
(1234, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:06'),
(1235, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:06'),
(1236, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:06'),
(1237, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:06'),
(1238, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:06'),
(1239, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/38', '', 'Qbs Support', '2023-12-30 05:33:20'),
(1240, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/38', '[{\"invent_req_id\":\"41\",\"req_id\":\"38\",\"related_to\":\"raw_material\",\"related_id\":\"47\",\"qty\":\"1\"},{\"req_id\":\"38\",\"req_code\":\"55454\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"werttyhyjh\",\"remarks\":\"\",\"created_at\":\"1703914056\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 05:33:27'),
(1241, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:36:32'),
(1242, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:36:38'),
(1243, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:36:42'),
(1244, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/40', '', 'Qbs Support', '2023-12-30 05:37:28'),
(1245, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/41', '', 'Qbs Support', '2023-12-30 05:38:04'),
(1246, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/37', '[{\"invent_req_id\":\"40\",\"req_id\":\"37\",\"related_to\":\"raw_material\",\"related_id\":\"42\",\"qty\":\"10\"},{\"req_id\":\"37\",\"req_code\":\"testing testing\",\"assigned_to\":\"1\",\"status\":\"1\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"wrtwer\",\"remarks\":\"\",\"created_at\":\"1703847192\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 05:38:32'),
(1247, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:50:33'),
(1248, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:50:35'),
(1249, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:50:36'),
(1250, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:52:23'),
(1251, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:54:17'),
(1252, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:54:23'),
(1253, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:54:28'),
(1254, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/40', '[{\"invent_req_id\":\"43\",\"req_id\":\"40\",\"related_to\":\"semi_finished\",\"related_id\":\"2\",\"qty\":\"1\"},{\"req_id\":\"40\",\"req_code\":\"swa585\",\"assigned_to\":\"3\",\"status\":\"0\",\"priority\":\"3\",\"mail_sent\":\"0\",\"description\":\"sadegrwe6at\",\"remarks\":\"\",\"created_at\":\"1703914648\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 05:55:11'),
(1255, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 05:56:09'),
(1256, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/42', '', 'Qbs Support', '2023-12-30 05:57:16'),
(1257, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/42', '', 'Qbs Support', '2023-12-30 05:57:27'),
(1258, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/42', '[{\"invent_req_id\":\"45\",\"req_id\":\"42\",\"related_to\":\"raw_material\",\"related_id\":\"47\",\"qty\":\"2\"},{\"req_id\":\"42\",\"req_code\":\"sdaga54684\",\"assigned_to\":\"1\",\"status\":\"1\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"dwsghserj\",\"remarks\":\"\",\"created_at\":\"1703915836\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 05:57:33'),
(1259, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/43', '', 'Qbs Support', '2023-12-30 05:58:22'),
(1260, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/43', '', 'Qbs Support', '2023-12-30 05:58:30'),
(1261, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/43', '', 'Qbs Support', '2023-12-30 05:58:49'),
(1262, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/9', '', 'Qbs Support', '2023-12-30 05:59:25'),
(1263, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/9', '', 'Qbs Support', '2023-12-30 06:00:52'),
(1264, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Support', '2023-12-30 06:05:39'),
(1265, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 06:05:49'),
(1266, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 06:08:49'),
(1267, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/3', '', 'Qbs Support', '2023-12-30 06:33:21'),
(1268, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Qbs Support', '2023-12-30 06:33:56'),
(1269, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 06:36:44'),
(1270, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 07:05:10'),
(1271, 'RFQ Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/9', '[{\"rfq_id\":\"9\",\"rfq_code\":\"gtydtjk8778\",\"req_id\":\"43\",\"expiry_date\":\"2023-12-30\",\"terms_condition\":\"awerg\",\"created_at\":\"1703915965\",\"created_by\":\"1\",\"status\":\"0\"},{\"supp_rfq_id\":\"10\",\"rfq_id\":\"9\",\"supplier_id\":\"21\",\"selection_rule\":\"supply_list\",\"mail_status\":\"0\",\"send_contacts\":\"0\",\"include_attach\":\"1\",\"responded\":\"0\",\"responded_at\":\"\"}]', 'Qbs Support', '2023-12-30 07:05:29'),
(1272, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/10', '', 'Qbs Support', '2023-12-30 07:06:37'),
(1273, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 07:09:13'),
(1274, 'RFQ Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/10', '[{\"rfq_id\":\"10\",\"rfq_code\":\"test\",\"req_id\":\"43\",\"expiry_date\":\"2023-12-31\",\"terms_condition\":\"rest\",\"created_at\":\"1703919997\",\"created_by\":\"1\",\"status\":\"0\"}]', 'Qbs Support', '2023-12-30 07:10:34'),
(1275, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/11', '', 'Qbs Support', '2023-12-30 07:11:01'),
(1276, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/11', '', 'Qbs Support', '2023-12-30 07:14:10'),
(1277, 'RFQ Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/11', '[{\"rfq_id\":\"11\",\"rfq_code\":\"TEST-123\",\"req_id\":\"43\",\"expiry_date\":\"2024-01-06\",\"terms_condition\":\"test\",\"created_at\":\"1703920261\",\"created_by\":\"1\",\"status\":\"0\"},{\"supp_rfq_id\":\"11\",\"rfq_id\":\"11\",\"supplier_id\":\"7\",\"selection_rule\":\"3\",\"mail_status\":\"0\",\"send_contacts\":\"0\",\"include_attach\":\"0\",\"responded\":\"0\",\"responded_at\":\"\"}]', 'Qbs Support', '2023-12-30 07:14:32'),
(1278, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/12', '', 'Qbs Support', '2023-12-30 07:14:50'),
(1279, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/12', '', 'Qbs Support', '2023-12-30 07:15:36'),
(1280, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/12', '', 'Qbs Support', '2023-12-30 07:15:55'),
(1281, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/50', '', 'Qbs Support', '2023-12-30 07:22:32'),
(1282, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/10', '', 'Qbs Support', '2023-12-30 07:31:14'),
(1283, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2023-12-30 07:58:40'),
(1284, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2023-12-30 07:59:13'),
(1285, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2023-12-30 08:00:28'),
(1286, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/4', '', 'Qbs Support', '2023-12-30 08:49:01'),
(1287, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 08:49:07'),
(1288, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2023-12-30 08:52:52'),
(1289, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/20', '', 'Qbs Support', '2023-12-30 09:11:11'),
(1290, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/3', '', 'Qbs Support', '2023-12-30 09:35:39'),
(1291, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/3', '', 'Qbs Support', '2023-12-30 09:44:28'),
(1292, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/21', '', 'Qbs Support', '2023-12-30 09:49:06'),
(1293, 'RFQ Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/12', '[{\"rfq_id\":\"12\",\"rfq_code\":\"TEST-123\",\"req_id\":\"43\",\"expiry_date\":\"2024-01-06\",\"terms_condition\":\"test\",\"created_at\":\"1703920490\",\"created_by\":\"1\",\"status\":\"0\"},{\"supp_rfq_id\":\"13\",\"rfq_id\":\"12\",\"supplier_id\":\"3\",\"selection_rule\":\"supplier_name\",\"mail_status\":\"0\",\"send_contacts\":\"0\",\"include_attach\":\"0\",\"responded\":\"0\",\"responded_at\":\"\"}]', 'Qbs Support', '2023-12-30 09:52:53'),
(1294, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/44', '', 'Qbs Support', '2023-12-30 09:53:18'),
(1295, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/44', '', 'Qbs Support', '2023-12-30 09:53:25'),
(1296, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/44', '', 'Qbs Support', '2023-12-30 09:53:32'),
(1297, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/13', '', 'Qbs Support', '2023-12-30 09:53:48'),
(1298, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/39', '', 'Qbs Support', '2023-12-30 10:09:19'),
(1299, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/39', '[{\"invent_req_id\":\"42\",\"req_id\":\"39\",\"related_to\":\"raw_material\",\"related_id\":\"47\",\"qty\":\"2\"},{\"req_id\":\"39\",\"req_code\":\"5489887\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"2\",\"mail_sent\":\"0\",\"description\":\"wsfrweage\",\"remarks\":\"\",\"created_at\":\"1703914592\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 10:09:26'),
(1300, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/43', '[{\"invent_req_id\":\"46\",\"req_id\":\"43\",\"related_to\":\"raw_material\",\"related_id\":\"47\",\"qty\":\"2\"},{\"req_id\":\"43\",\"req_code\":\"ftui8987\",\"assigned_to\":\"1\",\"status\":\"2\",\"priority\":\"1\",\"mail_sent\":\"0\",\"description\":\"ashgerth\",\"remarks\":\"drjhysy\",\"created_at\":\"1703915902\",\"created_by\":\"1\"}]', 'Qbs Support', '2023-12-30 10:09:34'),
(1301, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/41', '', 'Qbs Support', '2023-12-30 10:10:43'),
(1302, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/13', '', 'Qbs Support', '2023-12-30 10:11:28'),
(1303, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/9', '', 'Qbs Support', '2023-12-30 10:27:12'),
(1305, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2023-12-30 10:32:45'),
(1312, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'Qbs Support', '2023-12-30 10:36:09'),
(1313, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 10:49:35'),
(1314, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 11:13:30'),
(1315, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 11:19:01'),
(1316, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 11:33:04'),
(1317, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2023-12-30 11:40:54'),
(1318, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/11', '', 'Qbs Support', '2023-12-30 11:42:25'),
(1319, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/12', '', 'Qbs Support', '2023-12-30 12:37:11'),
(1320, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/13', '', 'Qbs Support', '2023-12-30 12:37:31'),
(1321, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2023-12-30 12:45:42'),
(1322, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-30 12:48:47'),
(1323, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2023-12-30 12:48:51'),
(1324, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-30 12:50:28'),
(1325, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2023-12-30 12:50:31'),
(1326, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2023-12-30 12:51:27'),
(1327, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2023-12-30 12:51:30'),
(1328, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-02 05:03:10'),
(1329, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2024-01-02 05:06:49'),
(1330, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-02 05:06:54'),
(1331, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-02 05:07:12'),
(1332, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-02 05:07:30'),
(1333, 'Workgroup Delete', '[ Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2024-01-02 05:10:35'),
(1334, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2024-01-02 05:12:10'),
(1335, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'erp/procurement/rfqview/13', '', 'Qbs Support', '2024-01-02 05:16:11'),
(1336, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/14', '', 'Qbs Support', '2024-01-02 05:23:23'),
(1337, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'erp/procurement/rfqview/13', '', 'Qbs Support', '2024-01-02 05:23:32'),
(1338, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/15', '', 'Qbs Support', '2024-01-02 05:23:44'),
(1339, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:25:54'),
(1340, 'RFQ Resend', '[ RFQ Resend sucessfully created ]', 'erp/procurement/rfqview/13', '', 'Qbs Support', '2024-01-02 05:26:25'),
(1341, 'Project Phase Update', '[ Project Phase successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:28:18'),
(1342, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:28:30'),
(1343, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:42'),
(1344, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:42'),
(1345, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:42'),
(1346, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:43'),
(1347, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:43'),
(1348, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:43'),
(1349, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/1', '', 'Qbs Support', '2024-01-02 05:33:43'),
(1350, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:37:09'),
(1351, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:42:22'),
(1352, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:42:31'),
(1353, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:42:51'),
(1354, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:43:45'),
(1355, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:44:09'),
(1356, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:44:20'),
(1357, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:44:48'),
(1358, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:45:02'),
(1359, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/2', '', 'Qbs Support', '2024-01-02 05:45:31'),
(1366, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-02 06:00:52'),
(1367, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-02 06:01:01'),
(1369, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-02 06:01:19'),
(1370, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-02 06:01:31'),
(1371, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-02 06:02:15'),
(1373, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-02 06:04:22'),
(1374, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-02 06:04:31'),
(1378, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:07:50'),
(1379, 'Contractor Delete', '[ Contractor and related data deleted successfully ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:07:55'),
(1381, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:08:56'),
(1382, 'Contractor Delete', '[ Contractor and related data deleted successfully ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:09:02'),
(1384, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:09:56'),
(1385, 'Contractor Delete', '[ Contractor and related data deleted successfully ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:12:42'),
(1386, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 06:13:24'),
(1387, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 06:14:12'),
(1388, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 06:17:25'),
(1389, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 06:18:21'),
(1390, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 06:20:45'),
(1391, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/1', '', 'Qbs Support', '2024-01-02 06:21:09'),
(1392, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:33:18'),
(1393, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:33:42'),
(1394, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:34:06'),
(1395, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:37:55'),
(1396, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:38:24'),
(1397, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:39:58'),
(1398, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:40:21'),
(1399, ' Service Insert', '[ Service successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:47:18'),
(1400, ' Service Insert', '[ Service successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:47:41'),
(1401, ' Service Insert', '[ Service successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:48:06'),
(1402, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:50:52'),
(1403, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:53:21'),
(1404, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 06:53:55'),
(1405, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-02 06:54:14'),
(1406, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-02 06:59:22'),
(1407, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 07:02:53'),
(1408, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 07:09:38'),
(1409, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'Qbs Support', '2024-01-02 07:10:16'),
(1410, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'Qbs Support', '2024-01-02 07:10:25'),
(1411, 'Purchase Invoice Insert', '[ Purchase Invoice successfully created ]', 'erp/procurement/orderview/9', '', 'Qbs Support', '2024-01-02 07:10:28'),
(1412, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-02 07:18:33'),
(1413, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 07:19:35'),
(1414, 'GRN Insert', '[ GRN successfully created ]', 'erp/procurement/orderview/9', '', 'Qbs Support', '2024-01-02 07:19:51'),
(1415, 'Contractor Update', '[ Contractor successfully updated ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 07:21:14'),
(1416, 'Contractor Update', '[ Contractor successfully updated ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-02 07:21:23'),
(1417, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 07:21:48'),
(1418, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/41', '', 'Qbs Support', '2024-01-02 07:22:53'),
(1419, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp.hr.attendance', '', 'Qbs Support', '2024-01-02 07:26:45'),
(1420, 'Purchase Payment Insert', '[ Purchase Payment successfully created ]', 'erp/procurement/invoiceview/3', '', 'Qbs Support', '2024-01-02 07:27:56'),
(1421, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:34:54'),
(1422, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:36:07'),
(1423, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/55847', '', 'Qbs Support', '2024-01-02 07:37:05'),
(1424, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-02 07:40:45'),
(1425, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:42:13'),
(1426, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:45:46'),
(1427, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:48:41'),
(1428, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:51:11'),
(1429, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:52:28'),
(1430, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:53:44'),
(1431, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:55:37'),
(1432, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/45', '', 'Qbs Support', '2024-01-02 07:57:06');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(1433, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/45', '', 'Qbs Support', '2024-01-02 07:57:12'),
(1434, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/45', '', 'Qbs Support', '2024-01-02 07:57:17'),
(1435, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/14', '', 'Qbs Support', '2024-01-02 07:57:42'),
(1436, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:58:33'),
(1437, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 07:59:55'),
(1438, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 08:01:12'),
(1439, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Support', '2024-01-02 08:43:34'),
(1440, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 08:45:14'),
(1441, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 08:53:51'),
(1442, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 09:00:27'),
(1443, 'Manage Stock Deletion', '[ Manage Stock successfully deleted ]', 'erp.warehouse.managestock.delete2', '{\"stock_id\":\"2\",\"related_to\":\"raw_material\",\"related_id\":\"16\",\"warehouse_id\":\"1\",\"quantity\":\"0\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-02 09:05:01'),
(1444, 'Manage Stock Deletion', '[ Manage Stock successfully deleted ]', 'erp.warehouse.managestock.delete1', '{\"stock_id\":\"1\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"warehouse_id\":\"1\",\"quantity\":\"8\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-02 09:05:07'),
(1445, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-02 09:05:32'),
(1446, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-02 09:05:44'),
(1447, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-02 09:09:08'),
(1448, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2024-01-02 09:19:00'),
(1449, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/4', '', 'Qbs Support', '2024-01-02 09:21:22'),
(1450, 'Supplier Update', '[ Supplier successfully updated ]', 'erp/supplier/supplier-view/4', '', 'Qbs Support', '2024-01-02 09:21:37'),
(1451, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'erp/procurement/rfqview/13', '', 'Qbs Support', '2024-01-02 09:42:14'),
(1452, 'RFQ Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/13', '[{\"rfq_id\":\"13\",\"rfq_code\":\"RFQ6969\",\"req_id\":\"44\",\"expiry_date\":\"2024-01-06\",\"terms_condition\":\"test\",\"created_at\":\"1703930028\",\"created_by\":\"1\",\"status\":\"1\"},{\"supp_rfq_id\":\"14\",\"rfq_id\":\"13\",\"supplier_id\":\"3\",\"selection_rule\":\"supply_list\",\"mail_status\":\"0\",\"send_contacts\":\"0\",\"include_attach\":\"1\",\"responded\":\"0\",\"responded_at\":\"\"}]', 'Qbs Support', '2024-01-02 09:42:19'),
(1453, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 09:52:22'),
(1454, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:12:45'),
(1455, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:13:41'),
(1456, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-02 10:16:14'),
(1457, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:17:10'),
(1458, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:17:29'),
(1459, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-02 10:20:54'),
(1460, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-02 10:21:09'),
(1461, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:21:19'),
(1462, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-02 10:21:24'),
(1463, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-02 10:21:39'),
(1464, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:21:50'),
(1465, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:22:16'),
(1466, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:22:35'),
(1467, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-02 10:23:20'),
(1468, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-02 10:24:29'),
(1469, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 10:29:19'),
(1470, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-02 10:29:27'),
(1471, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 10:30:59'),
(1472, 'Raw Material Update', '[ Raw Material successfully updated ]', 'erp.inventory.rawmaterialedit', '', 'Qbs Support', '2024-01-02 10:31:07'),
(1473, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 10:35:07'),
(1474, 'Raw Material Update', '[ Raw Material successfully updated ]', 'erp.inventory.rawmaterialedit', '', 'Qbs Support', '2024-01-02 10:36:31'),
(1475, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 10:40:13'),
(1476, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-02 10:40:27'),
(1477, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:43:13'),
(1478, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:43:36'),
(1479, 'Property Type Insert', '[ Property Type successfully created ]', 'erp/inventory/propertytype', '', 'Qbs Support', '2024-01-02 10:44:38'),
(1480, 'Property Type Update', '[ Property Type successfully updated ]', 'erp/inventory/propertytype', '', 'Qbs Support', '2024-01-02 10:44:53'),
(1481, 'Property Type Update', '[ Property Type successfully updated ]', 'erp/inventory/propertytype', '', 'Qbs Support', '2024-01-02 10:46:53'),
(1482, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 10:48:41'),
(1483, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-02 10:51:17'),
(1484, 'Requisition Update', '[ Requisition failed to update ]', 'erp/procurement/requisitionview/46', '', 'Qbs Support', '2024-01-02 10:55:16'),
(1485, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 10:55:36'),
(1486, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/47', '', 'Qbs Support', '2024-01-02 11:12:56'),
(1487, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:17:43'),
(1488, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:19:29'),
(1489, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:24:40'),
(1490, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:25:12'),
(1491, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:25:53'),
(1492, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:27:01'),
(1493, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:27:33'),
(1494, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:29:23'),
(1495, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:30:27'),
(1496, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:31:03'),
(1497, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:35:33'),
(1498, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:36:55'),
(1499, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:37:19'),
(1500, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:38:59'),
(1501, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:41:44'),
(1502, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:46:32'),
(1503, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-02 11:47:18'),
(1504, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:49:05'),
(1505, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 11:49:32'),
(1506, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:00:52'),
(1507, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:01:14'),
(1508, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:02:42'),
(1509, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:03:19'),
(1510, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:05:17'),
(1511, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:07:22'),
(1512, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-02 12:19:34'),
(1513, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-02 12:20:02'),
(1514, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-02 12:20:59'),
(1515, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-02 12:38:32'),
(1516, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/22', '{\"estimate_id\":\"22\",\"code\":\"56\",\"estimate_date\":\"2023-12-28\",\"terms_condition\":\"s\",\"name\":\"jacob\",\"cust_id\":\"6\",\"shippingaddr_id\":\"2\"}', 'Qbs Support', '2024-01-02 13:10:38'),
(1517, 'Transport Type Update', '[ Transport Type successfully updated ]', '', '', 'Qbs Support', '2024-01-02 13:31:19'),
(1518, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'Qbs Support', '2024-01-02 13:31:31'),
(1519, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-02 13:54:06'),
(1520, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 05:09:55'),
(1521, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 05:55:20'),
(1522, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 06:18:02'),
(1523, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-03 06:22:17'),
(1524, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-03 06:22:22'),
(1525, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-03 06:22:26'),
(1526, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-03 06:22:34'),
(1527, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Support', '2024-01-03 06:22:54'),
(1528, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '1', '', 'Qbs Support', '2024-01-03 06:26:21'),
(1529, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-03 06:27:32'),
(1530, 'Manage Stock Deletion', '[ Manage Stock failed to delete ]', '22', '', 'Qbs Support', '2024-01-03 06:27:40'),
(1531, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/23', '', 'Qbs Support', '2024-01-03 06:40:15'),
(1532, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/29', '', 'Qbs Support', '2024-01-03 06:46:53'),
(1533, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 07:19:07'),
(1534, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 07:19:14'),
(1535, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 07:19:18'),
(1536, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 07:27:40'),
(1537, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/29', '', 'Qbs Support', '2024-01-03 07:34:37'),
(1538, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/29', '', 'Qbs Support', '2024-01-03 07:36:00'),
(1539, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 07:42:10'),
(1540, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/46', '[{\"invent_req_id\":\"56\",\"req_id\":\"46\",\"related_to\":\"raw_material\",\"related_id\":\"46\",\"qty\":\"1\"},{\"req_id\":\"46\",\"req_code\":\"REQ -1\",\"assigned_to\":\"1\",\"status\":\"0\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"need some pens for office use. and magnisum\",\"remarks\":\"\",\"created_at\":\"1704190365\",\"created_by\":\"1\"}]', 'Qbs Support', '2024-01-03 07:42:54'),
(1541, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/48', '', 'Qbs Support', '2024-01-03 07:55:20'),
(1542, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-03 07:58:23'),
(1543, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 08:38:15'),
(1544, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/49', '', 'Qbs Support', '2024-01-03 08:39:06'),
(1545, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 08:49:41'),
(1546, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/50', '', 'Qbs Support', '2024-01-03 08:53:25'),
(1547, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/29', '', 'Qbs Support', '2024-01-03 08:56:00'),
(1548, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/51', '', 'Qbs Support', '2024-01-03 08:59:01'),
(1549, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/52', '', 'Qbs Support', '2024-01-03 08:59:34'),
(1550, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/53', '', 'Qbs Support', '2024-01-03 08:59:50'),
(1551, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/54', '', 'Qbs Support', '2024-01-03 09:01:55'),
(1552, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/55', '', 'Qbs Support', '2024-01-03 09:05:28'),
(1553, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/56', '', 'Qbs Support', '2024-01-03 09:07:04'),
(1554, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/57', '', 'Qbs Support', '2024-01-03 09:09:21'),
(1555, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/58', '', 'Qbs Support', '2024-01-03 09:32:39'),
(1556, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/29', '', 'Qbs Support', '2024-01-03 09:58:58'),
(1557, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/59', '', 'Qbs Support', '2024-01-03 10:18:35'),
(1558, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/60', '', 'Qbs Support', '2024-01-03 10:19:16'),
(1559, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/61', '', 'Qbs Support', '2024-01-03 10:20:00'),
(1560, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/62', '', 'Qbs Support', '2024-01-03 10:20:16'),
(1561, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/63', '', 'Qbs Support', '2024-01-03 10:29:19'),
(1562, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/64', '', 'Qbs Support', '2024-01-03 10:30:36'),
(1563, 'warehouse Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete29', '{\"order_id\":\"29\",\"code\":\"test128\",\"order_date\":\"2024-01-03\",\"order_expiry\":\"2024-01-04\",\"cust_id\":\"6\",\"shippingaddr_id\":\"10\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"discount\":\"0.00\",\"terms_condition\":\"edet\",\"payment_terms\":\"20 days\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"1\",\"stock_pick\":\"0\",\"created_at\":\"1704264413\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-03 10:33:04'),
(1564, 'warehouse Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete27', '{\"order_id\":\"27\",\"code\":\"test21\",\"order_date\":\"2023-12-29\",\"order_expiry\":\"2023-12-29\",\"cust_id\":\"43\",\"shippingaddr_id\":\"0\",\"transport_req\":\"1\",\"trans_charge\":\"20.00\",\"discount\":\"0.00\",\"terms_condition\":\"test\",\"payment_terms\":\"3 day\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"1\",\"stock_pick\":\"0\",\"created_at\":\"1703830455\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-03 10:33:13'),
(1565, 'warehouse Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete26', '{\"order_id\":\"26\",\"code\":\"th2002\",\"order_date\":\"2023-12-28\",\"order_expiry\":\"2023-12-30\",\"cust_id\":\"6\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"discount\":\"0.00\",\"terms_condition\":\"okay\",\"payment_terms\":\"20 days\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"1\",\"stock_pick\":\"0\",\"created_at\":\"1703764450\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-03 10:33:21'),
(1566, 'Manage Stock Deletion', '[ Manage Stock successfully deleted ]', 'erp.warehouse.managestock.delete10', '{\"stock_id\":\"10\",\"related_to\":\"finished_good\",\"related_id\":\"4\",\"warehouse_id\":\"2\",\"quantity\":\"0\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-03 11:17:11'),
(1567, 'Manage Stock Deletion', '[ Manage Stock successfully deleted ]', 'erp.warehouse.managestock.delete8', '{\"stock_id\":\"8\",\"related_to\":\"raw_material\",\"related_id\":\"16\",\"warehouse_id\":\"2\",\"quantity\":\"0\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-03 11:17:17'),
(1568, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2024-01-03 11:23:12'),
(1569, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 11:23:17'),
(1570, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/66', '', 'Qbs Support', '2024-01-03 11:48:54'),
(1571, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/67', '', 'Qbs Support', '2024-01-03 11:51:06'),
(1572, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/68', '', 'Qbs Support', '2024-01-03 11:54:34'),
(1573, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-03 12:04:38'),
(1574, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-03 12:04:52'),
(1575, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/69', '', 'Qbs Support', '2024-01-03 12:06:38'),
(1576, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/70', '', 'Qbs Support', '2024-01-03 12:06:59'),
(1577, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/71', '', 'Qbs Support', '2024-01-03 12:07:21'),
(1578, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/72', '', 'Qbs Support', '2024-01-03 12:08:02'),
(1579, 'User Update', '[ User failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Support', '2024-01-03 12:10:25'),
(1580, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Support', '2024-01-03 12:10:39'),
(1581, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Support', '2024-01-03 12:10:57'),
(1582, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/73', '', 'Qbs Support', '2024-01-03 12:24:24'),
(1583, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/39', '', 'Qbs Support', '2024-01-03 12:28:50'),
(1584, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/39', '', 'Qbs Support', '2024-01-03 12:29:00'),
(1585, 'Sale Invoice Notification Delete', '[ Sale Invoice Notification successfully deleted ]', 'erp/sale/invoiceview/39', '', 'Qbs Support', '2024-01-03 12:29:08'),
(1586, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/74', '', 'Qbs Support', '2024-01-03 12:29:47'),
(1587, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/39', '', 'Qbs Support', '2024-01-03 12:30:03'),
(1588, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/39', '', 'Qbs Support', '2024-01-03 12:30:12'),
(1589, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/39', '', 'Qbs Support', '2024-01-03 12:30:17'),
(1590, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/75', '', 'Qbs Support', '2024-01-03 12:31:39'),
(1591, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/76', '', 'Qbs Support', '2024-01-03 12:32:17'),
(1592, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/41', '', 'Qbs Support', '2024-01-03 12:33:43'),
(1593, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/77', '', 'Qbs Support', '2024-01-03 12:34:30'),
(1594, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/78', '', 'Qbs Support', '2024-01-03 12:34:41'),
(1595, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/79', '', 'Qbs Support', '2024-01-03 12:35:52'),
(1596, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/80', '', 'Qbs Support', '2024-01-03 12:42:14'),
(1597, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Qbs Support', '2024-01-03 12:42:47'),
(1598, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete13', '{\"warehouse_id\":\"13\",\"name\":\"vinitha\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"1\",\"description\":\"okay\",\"aisle_count\":\"45\",\"racks_per_aisle\":\"547\",\"shelf_per_rack\":\"98\",\"bins_per_shelf\":\"5\"}', 'Qbs Support', '2024-01-03 12:42:55'),
(1599, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/81', '', 'Qbs Support', '2024-01-03 12:43:29'),
(1600, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-03 12:45:10'),
(1601, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/82', '', 'Qbs Support', '2024-01-03 12:45:20'),
(1602, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-03 12:46:09'),
(1603, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Support', '2024-01-03 12:47:12'),
(1604, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/83', '', 'Qbs Support', '2024-01-03 12:48:20'),
(1605, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/84', '', 'Qbs Support', '2024-01-03 12:50:16'),
(1606, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/85', '', 'Qbs Support', '2024-01-03 12:51:58'),
(1607, 'Requisition Insert', '[ Requisition failed to create ]', 'erp/crm/requisitionview/86', '', 'Qbs Support', '2024-01-03 12:53:14'),
(1608, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/87', '', 'Qbs Support', '2024-01-03 12:56:09'),
(1609, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/88', '', 'Qbs Support', '2024-01-03 12:59:37'),
(1610, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/89', '', 'Qbs Support', '2024-01-03 13:04:02'),
(1611, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/90', '', 'Qbs Support', '2024-01-03 13:05:48'),
(1612, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-03 13:07:16'),
(1613, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/1', '', 'Qbs Support', '2024-01-03 13:08:39'),
(1614, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-03 13:09:12'),
(1615, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-03 13:10:01'),
(1616, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-03 13:10:12'),
(1617, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/15', '', 'Qbs Support', '2024-01-03 13:10:39'),
(1618, 'Order Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete4', '{\"order_id\":\"4\",\"code\":\"SO129\",\"order_date\":\"2022-04-09\",\"order_expiry\":\"2022-05-07\",\"cust_id\":\"6\",\"shippingaddr_id\":\"2\",\"transport_req\":\"1\",\"trans_charge\":\"2000.00\",\"discount\":\"500.00\",\"terms_condition\":\"hello world\",\"payment_terms\":\"30 days\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"1\",\"stock_pick\":\"0\",\"created_at\":\"1649490768\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-03 13:12:54'),
(1619, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp.warehouse.managestock.delete9', '{\"stock_id\":\"9\",\"related_to\":\"finished_good\",\"related_id\":\"4\",\"warehouse_id\":\"1\",\"quantity\":\"1\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-03 13:21:01'),
(1620, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp/warehouse/managestock', '{\"stock_id\":\"7\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"warehouse_id\":\"2\",\"quantity\":\"2\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-03 13:33:12'),
(1621, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp/warehouse/managestock', '{\"stock_id\":\"16\",\"related_to\":\"semi_finished\",\"related_id\":\"17\",\"warehouse_id\":\"4\",\"quantity\":\"1\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-03 13:34:03'),
(1622, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/15', '', 'Qbs Support', '2024-01-03 13:51:24'),
(1623, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 05:03:05'),
(1624, 'Order Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete1', '{\"order_id\":\"1\",\"code\":\"SO123\",\"order_date\":\"2022-04-07\",\"order_expiry\":\"2022-05-07\",\"cust_id\":\"6\",\"shippingaddr_id\":\"2\",\"transport_req\":\"1\",\"trans_charge\":\"2000.00\",\"discount\":\"1000.00\",\"terms_condition\":\"hello world\",\"payment_terms\":\"30 days\",\"status\":\"1\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"0\",\"stock_pick\":\"1\",\"created_at\":\"1649480917\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-04 05:07:54'),
(1625, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 05:07:57'),
(1626, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 05:19:08'),
(1627, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 05:19:29'),
(1628, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 05:24:38'),
(1629, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/1', '', 'Qbs Support', '2024-01-04 05:37:36'),
(1630, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/1', '', 'Qbs Support', '2024-01-04 05:38:18'),
(1631, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Support', '2024-01-04 05:38:54'),
(1632, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp/warehouse/managestock', '{\"stock_id\":\"11\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"warehouse_id\":\"4\",\"quantity\":\"1\",\"price_id\":\"1\"}', 'Qbs Support', '2024-01-04 05:58:29'),
(1633, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete1', '{\"invoice_id\":\"1\",\"code\":\"INV123\",\"cust_id\":\"6\",\"name\":\"jacob\",\"invoice_date\":\"2022-04-13\",\"invoice_expiry\":\"2022-05-07\",\"shippingaddr_id\":\"2\",\"transport_req\":\"1\",\"trans_charge\":\"2000.00\",\"payment_terms\":\"30 days\",\"terms_condition\":\"hello world\",\"discount\":\"1000.00\"}', 'Qbs Support', '2024-01-04 06:56:42'),
(1634, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete3', '{\"invoice_id\":\"3\",\"code\":\"INV125\",\"cust_id\":\"6\",\"name\":\"jacob\",\"invoice_date\":\"2022-04-13\",\"invoice_expiry\":\"2022-04-30\",\"shippingaddr_id\":\"0\",\"transport_req\":\"1\",\"trans_charge\":\"1000.00\",\"payment_terms\":\"30 days\",\"terms_condition\":\"hello\",\"discount\":\"4000.00\"}', 'Qbs Support', '2024-01-04 07:00:25'),
(1635, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete40', '{\"invoice_id\":\"40\",\"code\":\"INV5\",\"cust_id\":\"6\",\"name\":\"jacob\",\"invoice_date\":\"2023-12-28\",\"invoice_expiry\":\"2023-12-28\",\"shippingaddr_id\":\"2\",\"transport_req\":\"1\",\"trans_charge\":\"1300.00\",\"payment_terms\":\"20days\",\"terms_condition\":\"validity\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-04 07:01:16'),
(1636, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete41', '{\"invoice_id\":\"41\",\"code\":\"SO143\",\"cust_id\":\"6\",\"name\":\"jacob\",\"invoice_date\":\"2024-01-03\",\"invoice_expiry\":\"2024-01-03\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"20 days\",\"terms_condition\":\"wsarawer\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-04 07:01:24'),
(1637, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete39', '{\"invoice_id\":\"39\",\"code\":\"INV4\",\"cust_id\":\"6\",\"name\":\"jacob\",\"invoice_date\":\"2023-12-27\",\"invoice_expiry\":\"2023-12-27\",\"shippingaddr_id\":\"2\",\"transport_req\":\"1\",\"trans_charge\":\"1200.00\",\"payment_terms\":\"3 day\",\"terms_condition\":\"test\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-04 07:03:31'),
(1638, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/42', '', 'Qbs Support', '2024-01-04 07:10:28'),
(1639, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/3', '', 'Qbs Support', '2024-01-04 07:10:40'),
(1640, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/43', '', 'Qbs Support', '2024-01-04 07:14:07'),
(1641, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete43', '{\"invoice_id\":\"43\",\"code\":\"b6501\",\"cust_id\":\"6\",\"name\":\"jacob\",\"invoice_date\":\"2024-01-04\",\"invoice_expiry\":\"2024-01-04\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"20 days\",\"terms_condition\":\"sdgsea\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-04 07:14:42'),
(1642, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-04 07:20:39'),
(1643, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 07:29:18'),
(1644, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 07:35:48'),
(1645, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-04 07:38:11'),
(1646, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/45', '', 'Qbs Support', '2024-01-04 07:39:33'),
(1647, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-04 07:43:43'),
(1648, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-04 07:46:06'),
(1649, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 07:47:27'),
(1650, 'RFQ Update', '[ RFQ successfully updated ]', 'erp/procurement/rfqview/15', '', 'Qbs Support', '2024-01-04 07:50:27'),
(1651, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-04 07:50:31'),
(1652, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 08:43:37'),
(1653, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 08:44:52'),
(1654, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/22', '', 'Qbs Support', '2024-01-04 08:45:54'),
(1655, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 08:46:13'),
(1656, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 08:49:08'),
(1657, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 08:50:17'),
(1658, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-04 08:54:52'),
(1659, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-04 08:55:43'),
(1660, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/23', '', 'Qbs Support', '2024-01-04 08:56:13'),
(1661, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/24', '', 'Qbs Support', '2024-01-04 08:57:32'),
(1662, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-04 09:24:13'),
(1663, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-04 09:26:04'),
(1664, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/46', '', 'Qbs Support', '2024-01-04 09:31:54'),
(1665, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/26', '', 'Qbs Support', '2024-01-04 09:34:00'),
(1666, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/3', '', 'Qbs Support', '2024-01-04 09:44:21'),
(1667, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/3', '', 'Qbs Support', '2024-01-04 09:44:27'),
(1668, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/30', '', 'Qbs Support', '2024-01-04 09:44:50'),
(1669, 'RFQ Supplier Delete', '[ Supplier Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2024-01-04 09:45:53'),
(1670, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 09:55:22'),
(1671, 'Order Delete', '[ Order Deleted successfully ]', 'erp/procurement/orders/', '', 'Qbs Support', '2024-01-04 09:59:53'),
(1672, 'Purchase Order Update', '[ Purchase Order successfully updated ]', 'erp/procurement/orderview/26', '', 'Qbs Support', '2024-01-04 10:05:10'),
(1673, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 10:10:55'),
(1674, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 10:54:43'),
(1675, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-04 12:02:30'),
(1676, 'Task Update', '[ Task successfully updated ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-04 12:24:09'),
(1677, 'Task Update', '[ Task successfully updated ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-04 12:25:18'),
(1678, 'Task Update', '[ Task successfully updated ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-04 13:23:39'),
(1679, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/30', '', 'Qbs Support', '2024-01-04 13:44:58'),
(1680, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-05 06:24:42'),
(1681, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-05 06:25:18'),
(1682, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-05 06:47:48'),
(1683, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-05 06:50:30'),
(1684, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-05 07:16:02'),
(1685, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete12', '{\"lead_id\":\"12\",\"source_id\":\"7\",\"status\":\"4\",\"assigned_to\":\"2\",\"name\":\"SevenSanjay\",\"position\":\"Buyer\'s\",\"address\":\"Test Address\",\"city\":\"Dhrmapuri\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"phone\":\"09948261778\",\"email\":\"sevensanjay@qbrainstorm.com\",\"website\":\"www.test.com\",\"company\":\"qbrainstorm\",\"description\":\"leads\",\"remarks\":\"\",\"created_at\":\"1703050689\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 07:29:07'),
(1686, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete1', '{\"lead_id\":\"1\",\"source_id\":\"2\",\"status\":\"3\",\"assigned_to\":\"3\",\"name\":\"jacob\",\"position\":\"Purchase Manager\",\"address\":\"No.164, First Floor, Arcot Rd, Valasaravakkam\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"phone\":\"09080780700\",\"email\":\"simple@example.com\",\"website\":\"\",\"company\":\"john enterprise\",\"description\":\"Good Man\",\"remarks\":\"\",\"created_at\":\"\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 07:29:17'),
(1687, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/16', '', 'Qbs Support', '2024-01-05 07:31:09'),
(1688, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete16', '{\"lead_id\":\"16\",\"source_id\":\"1\",\"status\":\"0\",\"assigned_to\":\"2\",\"name\":\"siva\",\"position\":\"dfsdf\",\"address\":\"sdfsdf\",\"city\":\"sdfsdf\",\"state\":\"sdfsdf\",\"country\":\"sdfdsf\",\"zip\":\"sdf\",\"phone\":\"sdfsdfsdf\",\"email\":\"sivaKumar@gmail.com\",\"website\":\"sdfsdf\",\"company\":\"sdfsdf\",\"description\":\"sdfsdfdf\\r\\n\",\"remarks\":\"\",\"created_at\":\"1703062458\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 07:33:30'),
(1689, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/17', '', 'Qbs Support', '2024-01-05 07:34:07'),
(1690, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/2', '', 'Qbs Support', '2024-01-05 07:52:49'),
(1691, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/2', '', 'Qbs Support', '2024-01-05 07:56:44'),
(1692, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'Qbs Support', '2024-01-05 08:00:09'),
(1693, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/2', '', 'Qbs Support', '2024-01-05 08:00:37'),
(1694, 'Purchase Invoice Insert', '[ Purchase Invoice successfully created ]', 'erp/procurement/orderview/24', '', 'Qbs Support', '2024-01-05 08:01:10'),
(1695, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-05 08:47:09'),
(1696, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete2', '{\"lead_id\":\"2\",\"source_id\":\"4\",\"status\":\"2\",\"assigned_to\":\"2\",\"name\":\"john\",\"position\":\"Purchase Manager\",\"address\":\"No.164, First Floor, Arcot Rd, Valasaravakkam\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"phone\":\"09080780700\",\"email\":\"admin@example.com\",\"website\":\"\",\"company\":\"john enterprise\",\"description\":\"Good man\",\"remarks\":\"\",\"created_at\":\"\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 08:56:06'),
(1697, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/3', '', 'Qbs Support', '2024-01-05 08:56:27'),
(1698, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete6', '{\"cust_id\":\"6\",\"name\":\"jacob\",\"position\":\"Purchase Manager\",\"address\":\"test\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600078\",\"email\":\"admin1@example.com\",\"phone\":\"9876543210\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"john enterprise\",\"gst\":\"dgfdg\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644658242\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:15:28'),
(1699, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete41', '{\"cust_id\":\"41\",\"name\":\"sivakumar\",\"position\":\"dfsdf\",\"address\":\"sdfsdf\",\"city\":\"sdfsdf\",\"state\":\"sdfsdf\",\"country\":\"sdfdsf\",\"zip\":\"sdf\",\"email\":\"sivaKumar@gmail.com\",\"phone\":\"sdfsdfsdf\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"sdfsdf\",\"gst\":\"\",\"website\":\"sdfsdf\",\"description\":\"sdfsdfdf\\r\",\"remarks\":\"\",\"created_at\":\"1703062892\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:15:36'),
(1700, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete44', '{\"cust_id\":\"44\",\"name\":\"SevenSanjay\",\"position\":\"Purchase Managers\",\"address\":\"Test Address\",\"city\":\"Dhrmapuri\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"email\":\"sevensanjay@qbrainstorm.com\",\"phone\":\"9948261778\",\"fax_num\":\"4561237890\",\"office_num\":\"rwerr\",\"company\":\"qbrainstorm\",\"gst\":\"234324\",\"website\":\"www.seven.com\",\"description\":\"2121sasdad\",\"remarks\":\"\",\"created_at\":\"1703064664\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:25:48'),
(1701, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete8', '{\"cust_id\":\"8\",\"name\":\"Kevin\",\"position\":\"Purchase Manager\",\"address\":\"test\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600078\",\"email\":\"admin@example.com\",\"phone\":\"9876543200\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"john enterprise\",\"gst\":\"dgfdg\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644663999\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:25:57'),
(1702, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/7', '', 'Qbs Support', '2024-01-05 09:26:57'),
(1703, 'Customer Contact Update', '[ Customer Contact successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/7', '', 'Qbs Support', '2024-01-05 09:27:12'),
(1704, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/7', '', 'Qbs Support', '2024-01-05 09:31:40'),
(1705, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Support', '2024-01-05 09:32:44'),
(1706, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete7', '{\"cust_id\":\"7\",\"name\":\"Production Line\",\"position\":\"Purchase Manager\",\"address\":\"No.164, First Floor, Arcot Rd, Valasaravakkam\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"email\":\"admin2@example.com\",\"phone\":\"09080780700\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"john enterprise\",\"gst\":\"dgfdg\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644663941\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:45:26'),
(1707, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete3', '{\"lead_id\":\"3\",\"source_id\":\"2\",\"status\":\"0\",\"assigned_to\":\"2\",\"name\":\"john\",\"position\":\"Purchase Manager\",\"address\":\"No.164, First Floor, Arcot Rd, Valasaravakkam\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"phone\":\"09080780700\",\"email\":\"admin@example.com\",\"website\":\"\",\"company\":\"john enterprise\",\"description\":\"good Man\",\"remarks\":\"\",\"created_at\":\"\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:45:37'),
(1708, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete17', '{\"lead_id\":\"17\",\"source_id\":\"3\",\"status\":\"1\",\"assigned_to\":\"2\",\"name\":\"Thamizharasi\",\"position\":\"web developer\",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zip\":\"602024\",\"phone\":\"1234567890\",\"email\":\"support@qbrainstorm.com\",\"website\":\"\",\"company\":\"qbs\",\"description\":\"sgsg\",\"remarks\":\"fsseheazth\",\"created_at\":\"1703826890\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:45:44'),
(1709, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete43', '{\"cust_id\":\"43\",\"name\":\"SevenSanjay\",\"position\":\"Purchase Managers\",\"address\":\"Test Address\",\"city\":\"Dhrmapuri\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"email\":\"sevensanjay@qbrainstorm.com\",\"phone\":\"9948261778\",\"fax_num\":\"4561237890\",\"office_num\":\"rwerr\",\"company\":\"qbrainstorm\",\"gst\":\"234324\",\"website\":\"www.seven.com\",\"description\":\"2121sasdad\",\"remarks\":\"\",\"created_at\":\"1703064445\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:46:16');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(1710, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete9', '{\"cust_id\":\"9\",\"name\":\"Sam\",\"position\":\"Purchase Manager\",\"address\":\"No.164, First Floor, Arcot Rd, Valasaravakkam\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"email\":\"admin3@example.com\",\"phone\":\"0908078000\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"john enterprise\",\"gst\":\"dfdsf\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644664093\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:46:30'),
(1711, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete10', '{\"cust_id\":\"10\",\"name\":\"Raven\",\"position\":\"feer\",\"address\":\"ryrty\",\"city\":\"yrttu\",\"state\":\"Tamil Nadu\",\"country\":\"rytru\",\"zip\":\"tyrtu\",\"email\":\"admin5@example.com\",\"phone\":\"9876543210\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"john enterprise\",\"gst\":\"tgrt\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644664261\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 09:46:39'),
(1712, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/11', '', 'Qbs Support', '2024-01-05 09:47:25'),
(1713, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/47', '', 'Qbs Support', '2024-01-05 09:53:47'),
(1714, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/48', '', 'Qbs Support', '2024-01-05 09:55:27'),
(1715, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customercontactdelete11', '{\"contact_id\":\"8\",\"firstname\":\"Production\",\"lastname\":\"Thamizharasi\",\"email\":\"test@gmail.com\",\"phone\":\"1234567890\",\"active\":\"1\",\"position\":\"web developer\",\"cust_id\":\"11\",\"created_at\":\"1704448045\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 10:12:04'),
(1716, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/11', '', 'Qbs Support', '2024-01-05 10:14:05'),
(1717, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customercontactdelete11', '{\"contact_id\":\"9\",\"firstname\":\"Production\",\"lastname\":\"Thamizharasi\",\"email\":\"test@gmail.com\",\"phone\":\"1234567890\",\"active\":\"1\",\"position\":\"web developer\",\"cust_id\":\"11\",\"created_at\":\"1704449645\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 10:14:13'),
(1718, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/18', '', 'Qbs Support', '2024-01-05 10:18:40'),
(1719, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete11', '{\"cust_id\":\"11\",\"name\":\"George\",\"position\":\"dsafdsgf\",\"address\":\"testretertertertertretertertert\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600078\",\"email\":\"admin6@example.com\",\"phone\":\"9876543210\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"john enterprise\",\"gst\":\"sdfsd\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644664307\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 10:21:19'),
(1720, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete18', '{\"lead_id\":\"18\",\"source_id\":\"2\",\"status\":\"0\",\"assigned_to\":\"2\",\"name\":\"dfgdfg\",\"position\":\"dfgdfg\",\"address\":\"dfgdfg\",\"city\":\"dfgdfg\",\"state\":\"dfgdfg\",\"country\":\"v\",\"zip\":\"dfgdfg\",\"phone\":\"dfg\",\"email\":\"dfgdfg\",\"website\":\"dfgdfg\",\"company\":\"dfgdfg\",\"description\":\"dfgdfgdfg\\r\",\"remarks\":\"\",\"created_at\":\"1703828608\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 10:21:32'),
(1721, 'Customer Insert', '[ Customer successfully created ]', 'erp/crm/customerview/45', '', 'Qbs Support', '2024-01-05 10:58:27'),
(1722, 'Customer Insert', '[ Customer successfully created ]', 'erp/crm/customerview/46', '', 'Qbs Support', '2024-01-05 10:59:23'),
(1723, 'Customer Insert', '[ Customer successfully created ]', 'erp/crm/customerview/47', '', 'Qbs Support', '2024-01-05 11:00:30'),
(1724, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/45', '', 'Qbs Support', '2024-01-05 11:12:40'),
(1725, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/28', '', 'Qbs Support', '2024-01-05 11:15:41'),
(1726, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-05 11:39:03'),
(1727, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/32', '', 'Qbs Support', '2024-01-05 11:39:11'),
(1728, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/31', '', 'Qbs Support', '2024-01-05 11:41:35'),
(1729, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/49', '', 'Qbs Support', '2024-01-05 11:49:39'),
(1730, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete49', '{\"invoice_id\":\"49\",\"code\":\"b6501\",\"cust_id\":\"45\",\"name\":\"john\",\"invoice_date\":\"2024-01-05\",\"invoice_expiry\":\"2024-01-06\",\"shippingaddr_id\":\"13\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"20 days\",\"terms_condition\":\"dfhh\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-05 11:49:51'),
(1731, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/23', '{\"estimate_id\":\"23\",\"code\":\"d1234\",\"estimate_date\":\"2023-12-28\",\"terms_condition\":\"okay\",\"name\":\"shankar\",\"cust_id\":\"6\",\"shippingaddr_id\":\"3\"}', 'Qbs Support', '2024-01-05 11:58:48'),
(1732, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/24', '{\"estimate_id\":\"24\",\"code\":\"32\",\"estimate_date\":\"2023-12-30\",\"terms_condition\":\"test\",\"name\":\"shankar\",\"cust_id\":\"6\",\"shippingaddr_id\":\"3\"}', 'Qbs Support', '2024-01-05 11:58:53'),
(1733, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/33', '', 'Qbs Support', '2024-01-05 11:59:23'),
(1734, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-05 12:07:27'),
(1735, 'Quotation Deletion', '[ Quotation successfully deleted ]', 'erp.sale.quotation.delete1', '{\"quote_id\":\"1\",\"code\":\"QUO123\",\"quote_date\":\"2022-04-07\",\"cust_id\":\"6\",\"shippingaddr_id\":\"2\",\"transport_req\":\"1\",\"trans_charge\":\"2000.00\",\"discount\":\"1000.00\",\"terms_condition\":\"hello world\",\"payment_terms\":\"30 days\",\"status\":\"4\",\"created_at\":\"1649338913\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-05 13:03:07'),
(1736, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 04:34:18'),
(1737, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 04:39:40'),
(1738, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 04:47:48'),
(1739, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 04:48:34'),
(1740, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 04:48:49'),
(1741, 'Task Update', '[ Task successfully updated ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-06 04:55:22'),
(1742, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/3', '', 'Qbs Support', '2024-01-06 05:10:38'),
(1743, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 06:21:17'),
(1744, 'Task Delete', '[ Task successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/task', '', 'Qbs Support', '2024-01-06 06:42:51'),
(1745, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-06 06:59:05'),
(1746, 'Task Update', '[ Task successfully updated ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-06 06:59:39'),
(1747, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-06 07:00:28'),
(1748, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-06 07:43:09'),
(1749, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'erp/crm/leadview/4', '', 'Qbs Support', '2024-01-06 08:41:18'),
(1750, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 08:51:27'),
(1751, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 08:55:20'),
(1752, 'Lead Notification Delete', '[ Lead Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 09:12:43'),
(1753, 'Lead Notification Delete', '[ Lead Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 09:13:54'),
(1754, 'Lead Notification Update', '[ Lead Notification successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 09:14:50'),
(1755, 'Lead Notification Update', '[ Lead Notification successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 09:15:12'),
(1756, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 10:19:00'),
(1757, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 10:22:50'),
(1758, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 10:27:44'),
(1759, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 10:32:34'),
(1760, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 10:34:58'),
(1761, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-06 10:36:45'),
(1762, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 10:37:08'),
(1763, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 10:40:10'),
(1764, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:10:10'),
(1765, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:10:32'),
(1766, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:11:34'),
(1767, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:17:26'),
(1768, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:25:57'),
(1769, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:26:21'),
(1770, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:28:16'),
(1771, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:29:48'),
(1772, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:33:43'),
(1773, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:36:36'),
(1774, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:37:43'),
(1775, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:38:07'),
(1776, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:42:01'),
(1777, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:42:40'),
(1778, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:43:44'),
(1779, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:45:57'),
(1780, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:46:33'),
(1781, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:47:34'),
(1782, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:49:01'),
(1783, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:49:56'),
(1784, 'Employee Attendance Insert', 'Employee Attendance Insert; 0 rows inserted', 'http://192.168.29.166/ERP-CI4/public/erp/hr/attendance', '', 'Qbs Support', '2024-01-06 11:50:57'),
(1785, 'Marketing Update', '[ Marketing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Support', '2024-01-06 12:06:57'),
(1786, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/10', '', 'Qbs Support', '2024-01-06 12:12:51'),
(1787, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/10', '', 'Qbs Support', '2024-01-06 12:13:28'),
(1788, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/5', '', 'Qbs Support', '2024-01-06 12:14:22'),
(1789, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 12:24:11'),
(1790, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-06 12:28:35'),
(1791, 'Lead Update', '[ Lead failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/5', '', 'Qbs Support', '2024-01-06 12:29:18'),
(1792, 'Lead Update', '[ Lead failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/5', '', 'Qbs Support', '2024-01-06 12:29:26'),
(1793, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/5', '', 'Qbs Support', '2024-01-06 12:30:21'),
(1794, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-08 05:02:06'),
(1795, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-08 05:21:50'),
(1796, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-08 12:54:12'),
(1797, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Support', '2024-01-08 13:31:42'),
(1798, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 04:41:15'),
(1799, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 04:42:16'),
(1800, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/16', '', 'Qbs Support', '2024-01-09 04:48:30'),
(1801, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'e    rp/procurement/rfqview/16', '', 'Qbs Support', '2024-01-09 04:49:03'),
(1802, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 04:53:00'),
(1803, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/1', '', 'Qbs Support', '2024-01-09 05:13:30'),
(1804, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/1', '', 'Qbs Support', '2024-01-09 05:13:35'),
(1805, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/1', '', 'Qbs Support', '2024-01-09 05:13:44'),
(1806, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-09 05:14:52'),
(1807, 'RFQ Update', '[ RFQ successfully updated ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-09 05:15:04'),
(1808, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'e    rp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-09 05:16:14'),
(1809, 'RFQ Send Batch', '[ RFQ Sent without suppliers ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-09 05:19:19'),
(1810, 'RFQ Supplier Insert', '[ RFQ Supplier successfully updated ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-09 05:19:40'),
(1811, 'RFQ Resend', '[ RFQ Resend sucessfully created ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-09 05:19:50'),
(1812, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/1', '', 'Qbs Support', '2024-01-09 05:21:23'),
(1813, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'Qbs Support', '2024-01-09 05:31:02'),
(1814, 'GRN Insert', '[ GRN successfully created ]', 'erp/procurement/orderview/1', '', 'Qbs Support', '2024-01-09 05:31:32'),
(1815, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/55848', '', 'Qbs Support', '2024-01-09 05:36:08'),
(1816, 'Purchase Invoice Insert', '[ Purchase Invoice successfully created ]', 'erp/procurement/orderview/1', '', 'Qbs Support', '2024-01-09 05:39:10'),
(1817, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/55848', '', 'Qbs Support', '2024-01-09 05:46:51'),
(1818, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 05:56:15'),
(1819, 'Journal Entry Post', '[ Journal Entry successfully posted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-09 08:54:51'),
(1820, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 11:05:05'),
(1821, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-09 11:33:40'),
(1822, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-09 11:33:53'),
(1823, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 11:34:01'),
(1824, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 11:35:38'),
(1825, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 11:39:29'),
(1826, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/8', '', 'Qbs Support', '2024-01-09 11:40:53'),
(1827, 'Lead Notification Insert', '[ Lead Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-09 11:40:58'),
(1828, 'Lead Notification Delete', '[ Lead Notification successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-09 11:41:09'),
(1829, 'Lead Update', '[ Lead successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/4', '', 'Qbs Support', '2024-01-09 11:41:27'),
(1830, 'Journal Entry Insert', '[ Journal Entry successfully created ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-09 12:17:43'),
(1831, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 13:12:01'),
(1832, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-09 13:20:56'),
(1833, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-10 04:50:13'),
(1834, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-10 04:51:00'),
(1835, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-10 05:07:38'),
(1836, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-10 05:07:39'),
(1837, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-10 05:14:18'),
(1838, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-10 05:14:54'),
(1839, 'Semi Finished Insert', '[ Semi Finished successfully created ]', '', '', 'Qbs Support', '2024-01-10 05:15:27'),
(1840, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-10 05:16:23'),
(1841, 'Unit Insert', '[ Unit successfully created ]', 'erp/inventory/units', '', 'Qbs Support', '2024-01-10 05:23:51'),
(1842, ' Service Insert', '[ Service successfully created ]', '', '', 'Qbs Support', '2024-01-10 05:27:02'),
(1843, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-10 05:30:33'),
(1844, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-10 05:31:33'),
(1845, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-10 05:36:51'),
(1846, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-10 06:00:36'),
(1847, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/32', '', 'Qbs Support', '2024-01-10 06:08:37'),
(1848, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/32', '', 'Qbs Support', '2024-01-10 06:10:06'),
(1849, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/32', '', 'Qbs Support', '2024-01-10 06:10:35'),
(1850, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/31', '', 'Qbs Support', '2024-01-10 06:11:34'),
(1851, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-10 07:03:27'),
(1852, 'Sale Order Notification Delete', '[ Sale Order Notification successfully deleted ]', 'erp/sale/orderview/31', '', 'Qbs Support', '2024-01-10 07:40:59'),
(1853, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/32', '', 'Qbs Support', '2024-01-10 07:41:13'),
(1854, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-10 13:55:11'),
(1855, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-11 04:44:35'),
(1856, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-11 04:44:38'),
(1857, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-11 04:45:14'),
(1858, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:30:01'),
(1859, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:30:56'),
(1860, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2024-01-11 05:43:00'),
(1861, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:43:55'),
(1862, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:44:06'),
(1863, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:44:50'),
(1864, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:45:38'),
(1865, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:46:33'),
(1866, 'Project Testing Result Update', '[ Project Testing Result failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/11', '', 'Qbs Support', '2024-01-11 05:52:32'),
(1867, 'Project Testing Update', '[ Project Testing failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:57:48'),
(1868, 'Project Testing Update', '[ Project Testing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:57:54'),
(1869, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:58:53'),
(1870, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:59:04'),
(1871, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 05:59:22'),
(1872, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs Support', '2024-01-11 06:00:02'),
(1873, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/47', '', 'Qbs Support', '2024-01-11 07:38:47'),
(1874, 'Customer Shipping Address Insert', '[ Customer Shipping Address successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/47', '', 'Qbs Support', '2024-01-11 07:38:54'),
(1875, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/34', '', 'Qbs Support', '2024-01-11 07:40:53'),
(1876, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/4', '', 'Qbs Support', '2024-01-11 07:47:59'),
(1877, 'Quotation Accepted', '[ Quotation Accepted successfully ]', 'erp/sale/quotationview/4', '', 'Qbs Support', '2024-01-11 07:48:21'),
(1878, 'Order Conversion', '[ Order Conversion successfully ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/order_view/36', '', 'Qbs Support', '2024-01-11 09:22:56'),
(1879, 'Quotation Accepted', '[ Quotation Accepted successfully ]', 'erp/sale/quotationview/3', '', 'Qbs Support', '2024-01-11 09:37:13'),
(1880, 'Order Conversion', '[ Order Conversion successfully ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/order_view/37', '', 'Qbs Support', '2024-01-11 09:37:47'),
(1881, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-11 09:44:49'),
(1882, 'Credit Note Insert', '[ Credit Note successfully created ]', 'erp/sale/creditview/6', '', 'Qbs Support', '2024-01-11 09:58:55'),
(1883, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/31', '', 'Qbs Support', '2024-01-11 10:18:54'),
(1884, 'Quotation Deletion', '[ Quotation successfully deleted ]', 'erp.sale.quotation.delete4', '{\"quote_id\":\"4\",\"code\":\"PASU256\",\"quote_date\":\"2024-01-11\",\"cust_id\":\"47\",\"shippingaddr_id\":\"14\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"discount\":\"0.00\",\"terms_condition\":\"test\",\"payment_terms\":\"test\",\"status\":\"4\",\"created_at\":\"1704959279\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-11 10:19:34'),
(1885, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/5', '', 'Qbs Support', '2024-01-11 10:20:23'),
(1886, 'Quotation Accepted', '[ Quotation Accepted successfully ]', 'erp/sale/quotationview/5', '', 'Qbs Support', '2024-01-11 10:20:51'),
(1887, 'Order Conversion', '[ Order Conversion successfully ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/order_view/38', '', 'Qbs Support', '2024-01-11 10:21:26'),
(1888, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/6', '', 'Qbs Support', '2024-01-11 10:32:55'),
(1889, 'Quotation Declined', '[ Quotation Declined successfully ]', 'erp/sale/quotationview/6', '', 'Qbs Support', '2024-01-11 10:33:45'),
(1890, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/7', '', 'Qbs Support', '2024-01-11 10:43:59'),
(1891, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/3', '', 'Qbs Support', '2024-01-11 10:51:17'),
(1892, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/3', '', 'Qbs Support', '2024-01-11 10:51:21'),
(1893, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/4', '[{\"invent_req_id\":\"5\",\"req_id\":\"4\",\"related_to\":\"raw_material\",\"related_id\":\"53\",\"qty\":\"1\"},{\"req_id\":\"4\",\"req_code\":\"USAP1234\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"3\",\"mail_sent\":\"1\",\"description\":\"test\",\"remarks\":\"\",\"created_at\":\"1704970248\",\"created_by\":\"1\"}]', 'Qbs Support', '2024-01-11 10:51:27'),
(1894, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/3', '[{\"invent_req_id\":\"4\",\"req_id\":\"3\",\"related_to\":\"raw_material\",\"related_id\":\"53\",\"qty\":\"1\"},{\"req_id\":\"3\",\"req_code\":\"USAP1234\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"3\",\"mail_sent\":\"1\",\"description\":\"test\",\"remarks\":\"\",\"created_at\":\"1704970246\",\"created_by\":\"1\"}]', 'Qbs Support', '2024-01-11 10:51:34'),
(1895, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:51:39'),
(1896, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:51:40'),
(1897, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:51:51'),
(1898, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:51:53'),
(1899, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:52:06'),
(1900, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:52:09'),
(1901, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/2', '', 'Qbs Support', '2024-01-11 10:58:04'),
(1902, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-11 10:58:40'),
(1903, 'Quotation Accepted', '[ Quotation Accepted successfully ]', 'erp/sale/quotationview/7', '', 'Qbs Support', '2024-01-11 11:18:10'),
(1904, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/8', '', 'Qbs Support', '2024-01-11 11:19:35'),
(1905, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-11 12:18:10'),
(1906, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-11 12:20:16'),
(1907, 'Sale Payment Update', '[ Sale Payment successfully updated ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-11 12:20:39'),
(1908, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/45', '', 'Qbs Support', '2024-01-11 12:22:55'),
(1909, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/46', '', 'Qbs Support', '2024-01-11 12:26:19'),
(1910, 'Quotation Accepted', '[ Quotation Accepted successfully ]', 'erp/sale/quotationview/8', '', 'Qbs Support', '2024-01-11 13:35:26'),
(1911, 'Order Conversion', '[ Order Conversion successfully ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/order_view/39', '', 'Qbs Support', '2024-01-11 13:35:42'),
(1912, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/52', '', 'Qbs Support', '2024-01-11 13:39:47'),
(1913, 'Credit Note Insert', '[ Credit Note successfully created ]', 'erp/sale/creditview/7', '', 'Qbs Support', '2024-01-11 13:49:44'),
(1914, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-12 04:54:53'),
(1915, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-12 05:00:00'),
(1916, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-12 05:09:24'),
(1917, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-12 05:13:34'),
(1918, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete52', '{\"invoice_id\":\"52\",\"code\":\"ytt\",\"cust_id\":\"45\",\"name\":\"john\",\"invoice_date\":\"2024-01-11\",\"invoice_expiry\":\"2024-01-19\",\"shippingaddr_id\":\"13\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"6sdfgdfg\",\"terms_condition\":\"tert\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-12 05:19:52'),
(1919, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/8', '', 'Qbs Support', '2024-01-12 05:55:33'),
(1920, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/53', '', 'Qbs Support', '2024-01-12 06:08:50'),
(1921, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/9', '', 'Qbs Support', '2024-01-12 06:10:02'),
(1922, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-12 06:21:20'),
(1923, 'Sale Order Update', '[ Sale Order successfully updated ]', 'erp/sale/orderview/32', '', 'Qbs Support', '2024-01-12 07:43:42'),
(1924, 'Order Conversion', '[ Order Conversion successfully ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/order_view/40', '', 'Qbs Support', '2024-01-12 07:45:14'),
(1925, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/54', '', 'Qbs Support', '2024-01-12 09:15:43'),
(1926, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/10', '', 'Qbs Support', '2024-01-12 09:16:07'),
(1927, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/54', '', 'Qbs Support', '2024-01-12 09:17:34'),
(1928, 'Purchase Payment Insert', '[ Purchase Payment successfully created ]', 'erp/procurement/invoiceview/1', '', 'Qbs Support', '2024-01-12 09:49:25'),
(1929, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/5', '', 'Qbs Support', '2024-01-12 09:54:11'),
(1930, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/5', '', 'Qbs Support', '2024-01-12 09:54:20'),
(1931, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/5', '', 'Qbs Support', '2024-01-12 09:55:13'),
(1932, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/2', '', 'Qbs Support', '2024-01-12 09:58:47'),
(1933, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'Qbs Support', '2024-01-12 09:59:03'),
(1934, 'Purchase Invoice Insert', '[ Purchase Invoice successfully created ]', 'erp/procurement/orderview/2', '', 'Qbs Support', '2024-01-12 09:59:11'),
(1935, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:18:11'),
(1936, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:18:22'),
(1937, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:18:26'),
(1938, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:19:14'),
(1939, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:19:23'),
(1940, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:19:37'),
(1941, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:20:51'),
(1942, 'Requisition Status Update', '[ Requisition Status failed to update ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:21:06'),
(1943, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:26:14'),
(1944, 'Requisition Update', '[ Requisition successfully updated ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:28:07'),
(1945, 'Requisition Status Update', '[ Requisition Status successfully updated ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:28:18'),
(1946, 'Requisition Action Update', '[ Requisition Action successfully updated ]', 'erp/procurement/requisitionview/6', '', 'Qbs Support', '2024-01-12 10:28:27'),
(1947, 'Purchase Order Insert', '[ Purchase Order successfully created ]', 'erp/procurement/orderview/3', '', 'Qbs Support', '2024-01-12 10:43:55'),
(1948, 'Order Status Update', '[ Order Status successfully updated ]', '', '', 'Qbs Support', '2024-01-12 10:44:27'),
(1949, 'GRN Insert', '[ GRN successfully created ]', 'erp/procurement/orderview/3', '', 'Qbs Support', '2024-01-12 10:44:40'),
(1950, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/55849', '', 'Qbs Support', '2024-01-12 10:46:41'),
(1951, 'GRN Update', '[ GRN successfully updated ]', 'erp/warehouse/grnview/55849', '', 'Qbs Support', '2024-01-12 10:47:08'),
(1952, 'Purchase Invoice Insert', '[ Purchase Invoice successfully created ]', 'erp/procurement/orderview/3', '', 'Qbs Support', '2024-01-12 10:47:47'),
(1953, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-12 10:53:08'),
(1954, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-12 10:58:01'),
(1955, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-13 05:02:10'),
(1956, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-13 05:02:11'),
(1957, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-13 05:02:11'),
(1958, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-13 05:02:51'),
(1959, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/44', '', 'Qbs Support', '2024-01-13 05:04:30'),
(1960, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-13 05:05:29'),
(1961, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-13 05:34:04'),
(1962, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-13 05:41:12'),
(1963, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-13 06:38:19'),
(1964, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/55', '', 'Qbs Support', '2024-01-13 06:40:27'),
(1965, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:40:45'),
(1966, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:47:29'),
(1967, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:51:06'),
(1968, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:58:08'),
(1969, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:58:09'),
(1970, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:58:09'),
(1971, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 06:58:10'),
(1972, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 07:15:49'),
(1973, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 07:15:49'),
(1974, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 07:15:49'),
(1975, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 07:15:49'),
(1976, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 07:16:53'),
(1977, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-13 07:23:47'),
(1978, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/56', '', 'Qbs Support', '2024-01-13 07:27:26'),
(1979, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-13 07:29:05'),
(1980, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 07:50:07'),
(1981, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete8', '{\"dispatch_id\":\"8\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"sdgafsd\",\"created_at\":\"1705130097\",\"updated_at\":\"1705130097\"}', 'Qbs Support', '2024-01-13 09:48:56'),
(1982, 'Payroll Insert', '[ Payroll successfully created ]', 'erp/hr/payrolls', '', 'Qbs Support', '2024-01-13 09:56:49'),
(1983, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete10', '{\"dispatch_id\":\"10\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"0\",\"pick_list_id\":\"0\",\"description\":\"okay \",\"created_at\":\"1705130149\",\"updated_at\":\"1705130149\"}', 'Qbs Support', '2024-01-13 09:57:28'),
(1984, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete3', '{\"dispatch_id\":\"3\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"0\",\"pick_list_id\":\"0\",\"description\":\"okay lets start\",\"created_at\":\"1705128666\",\"updated_at\":\"1705128666\"}', 'Qbs Support', '2024-01-13 09:57:36'),
(1985, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete13', '{\"dispatch_id\":\"13\",\"order_code\":\"15163\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-11 00:00:00\",\"customer\":\"shankar\",\"suppiler_id\":\"0\",\"order_id\":\"39\",\"cust_id\":\"6\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"hi helo morning\",\"created_at\":\"1705130213\",\"updated_at\":\"1705130213\"}', 'Qbs Support', '2024-01-13 09:58:01'),
(1986, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete1', '{\"dispatch_id\":\"1\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-13 16:10:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"0\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"sas\",\"created_at\":\"1705128045\",\"updated_at\":\"1705128045\"}', 'Qbs Support', '2024-01-13 09:58:24'),
(1987, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete2', '{\"dispatch_id\":\"2\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-02-01 12:17:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"asd\",\"created_at\":\"1705128449\",\"updated_at\":\"1705128449\"}', 'Qbs Support', '2024-01-13 09:58:33'),
(1988, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete14', '{\"dispatch_id\":\"14\",\"order_code\":\"fghdf4565\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-18 00:00:00\",\"customer\":\"john\",\"suppiler_id\":\"0\",\"order_id\":\"32\",\"cust_id\":\"45\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"dgsarg\",\"created_at\":\"1705132207\",\"updated_at\":\"1705132207\"}', 'Qbs Support', '2024-01-13 10:01:09'),
(1989, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete11', '{\"dispatch_id\":\"11\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"0\",\"pick_list_id\":\"0\",\"description\":\"okay \",\"created_at\":\"1705130149\",\"updated_at\":\"1705130149\"}', 'Qbs Support', '2024-01-13 10:01:58'),
(1990, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete6', '{\"dispatch_id\":\"6\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"\",\"created_at\":\"1705129089\",\"updated_at\":\"1705129089\"}', 'Qbs Support', '2024-01-13 10:03:03'),
(1991, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete9', '{\"dispatch_id\":\"9\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"0\",\"pick_list_id\":\"0\",\"description\":\"okay \",\"created_at\":\"1705130149\",\"updated_at\":\"1705130149\"}', 'Qbs Support', '2024-01-13 10:05:53'),
(1992, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete12', '{\"dispatch_id\":\"12\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"0\",\"pick_list_id\":\"0\",\"description\":\"okay \",\"created_at\":\"1705130149\",\"updated_at\":\"1705130149\"}', 'Qbs Support', '2024-01-13 10:07:36'),
(1993, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete4', '{\"dispatch_id\":\"4\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"\",\"created_at\":\"1705129088\",\"updated_at\":\"1705129088\"}', 'Qbs Support', '2024-01-13 10:08:11'),
(1994, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 10:11:19'),
(1995, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 10:13:17'),
(1996, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete15', '{\"dispatch_id\":\"15\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"gfss\",\"created_at\":\"1705140679\",\"updated_at\":\"1705140679\"}', 'Qbs Support', '2024-01-13 10:19:18'),
(1997, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 10:26:17'),
(1998, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 10:37:25');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(1999, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete18', '{\"dispatch_id\":\"18\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-13 18:09:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"3\",\"pick_list_id\":\"0\",\"description\":\"Hi Erp\",\"created_at\":\"1705142245\",\"updated_at\":\"1705142245\"}', 'Qbs Support', '2024-01-13 10:37:54'),
(2000, 'Service Insert', '[ Service successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-13 10:45:41'),
(2001, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete5', '{\"dispatch_id\":\"5\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"\",\"created_at\":\"1705129089\",\"updated_at\":\"1705129089\"}', 'Qbs Support', '2024-01-13 11:15:26'),
(2002, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete7', '{\"dispatch_id\":\"7\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-06 00:00:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"\",\"created_at\":\"1705129090\",\"updated_at\":\"1705129090\"}', 'Qbs Support', '2024-01-13 11:46:00'),
(2003, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 11:50:17'),
(2004, 'Dispatch Update', '[ Dispatch successfully updated ]', 'erp.dispatch.edit16', '', 'Qbs Support', '2024-01-13 12:28:01'),
(2005, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-13 12:28:22'),
(2006, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-13 12:48:34'),
(2007, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-13 12:48:53'),
(2008, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-17 05:16:50'),
(2009, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-17 05:23:29'),
(2010, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-17 05:28:29'),
(2011, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/11', '', 'Qbs Support', '2024-01-17 05:33:55'),
(2012, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/12', '', 'Qbs Support', '2024-01-17 05:46:15'),
(2013, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/57', '', 'Qbs Support', '2024-01-17 06:17:22'),
(2014, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/13', '', 'Qbs Support', '2024-01-17 06:17:49'),
(2015, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/58', '', 'Qbs Support', '2024-01-17 06:29:30'),
(2016, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete58', '{\"invoice_id\":\"58\",\"code\":\"gfhfg542\",\"cust_id\":\"45\",\"name\":\"john\",\"invoice_date\":\"2024-01-17\",\"invoice_expiry\":\"2024-01-17\",\"shippingaddr_id\":\"13\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"20 days\",\"terms_condition\":\"fzhfch\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-17 06:30:52'),
(2017, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete55', '{\"invoice_id\":\"55\",\"code\":\"INV25\",\"cust_id\":\"38\",\"name\":\"admin2\",\"invoice_date\":\"2024-01-13\",\"invoice_expiry\":\"2024-01-11\",\"shippingaddr_id\":\"0\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"fd\",\"terms_condition\":\"fds\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-17 06:36:31'),
(2018, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete44', '{\"invoice_id\":\"44\",\"code\":\"SO128\",\"cust_id\":\"6\",\"name\":\"shankar\",\"invoice_date\":\"2024-01-04\",\"invoice_expiry\":\"2024-01-04\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"20 days\",\"terms_condition\":\"esdhsth\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-17 06:38:23'),
(2019, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete45', '{\"invoice_id\":\"45\",\"code\":\"INV11\",\"cust_id\":\"6\",\"name\":\"shankar\",\"invoice_date\":\"2024-01-04\",\"invoice_expiry\":\"2024-01-05\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"3 day\",\"terms_condition\":\"fsd\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-17 06:38:29'),
(2020, 'Sale Payment Delete', '[ Sale Payment successfully deleted ]', 'erp/sale/invoiceview/54', '', 'Qbs Support', '2024-01-17 07:34:01'),
(2021, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/54', '', 'Qbs Support', '2024-01-17 07:34:48'),
(2022, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/54', '', 'Qbs Support', '2024-01-17 07:57:48'),
(2023, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete7', '{\"credit_id\":\"7\",\"code\":\"sdadf08\",\"invoice_id\":\"48\",\"applied\":\"1\",\"issued_date\":\"2024-01-12\",\"other_charge\":\"0.00\",\"payment_terms\":\"test\",\"terms_condition\":\"456456fdhdgdhg\",\"remarks\":\"dfhgfhgdfv\"}', 'Qbs Support', '2024-01-17 08:55:13'),
(2024, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/14', '', 'Qbs Support', '2024-01-17 08:57:46'),
(2025, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/15', '', 'Qbs Support', '2024-01-17 09:01:41'),
(2026, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/16', '', 'Qbs Support', '2024-01-17 09:03:39'),
(2027, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/17', '', 'Qbs Support', '2024-01-17 09:06:58'),
(2028, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete17', '{\"credit_id\":\"17\",\"code\":\"GT1234\",\"invoice_id\":\"53\",\"applied\":\"0\",\"issued_date\":\"2024-01-17\",\"other_charge\":\"200.00\",\"payment_terms\":\"Google pay\",\"terms_condition\":\"okay\",\"remarks\":\"Nothing\"}', 'Qbs Support', '2024-01-17 09:08:07'),
(2029, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-17 09:25:14'),
(2030, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/57', '', 'Qbs Support', '2024-01-17 09:39:05'),
(2031, 'Managestock Deletion', '[ Managestock failed to delete ]', 'erp.warehouse.managestock9', '', 'Qbs Support', '2024-01-17 09:48:47'),
(2032, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp.warehouse.managestock', '{\"pack_unit_id\":\"9\",\"sku\":\"9\",\"related_to\":\"raw_material\",\"related_id\":\"16\",\"bin_name\":\"\",\"mfg_date\":\"2022-02-11\",\"batch_no\":\"\",\"lot_no\":\"\\r\\n\"}', 'Qbs Support', '2024-01-17 09:49:56'),
(2033, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp.warehouse.managestock', '{\"pack_unit_id\":\"1\",\"sku\":\"54\",\"related_to\":\"raw_material\",\"related_id\":\"2\",\"bin_name\":\"10\",\"mfg_date\":\"2023-12-15\",\"batch_no\":\"\",\"lot_no\":\"\"}', 'Qbs Support', '2024-01-17 09:50:09'),
(2034, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Support', '2024-01-17 09:50:39'),
(2035, 'Logout', '[ User successfully logout ]', '', '', 'Qbs Support', '2024-01-17 10:03:44'),
(2036, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-17 10:03:49'),
(2037, 'Payment Mode Update', '[ Payment Mode successfully updated ]', 'erp/finance/paymentmode/', '', 'Qbs Support', '2024-01-17 10:40:32'),
(2038, 'Payment Mode Update', '[ Payment Mode successfully updated ]', 'erp/finance/paymentmode/', '', 'Qbs Support', '2024-01-17 10:41:29'),
(2039, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete46', '{\"invoice_id\":\"46\",\"code\":\"INV13\",\"cust_id\":\"6\",\"name\":\"shankar\",\"invoice_date\":\"2024-01-04\",\"invoice_expiry\":\"2024-01-04\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"20 days\",\"terms_condition\":\"dfghsrth\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-17 10:55:52'),
(2040, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/59', '', 'Qbs Support', '2024-01-17 11:04:24'),
(2041, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/18', '', 'Qbs Support', '2024-01-17 11:04:57'),
(2042, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs Support', '2024-01-17 11:29:52'),
(2043, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/9', '', 'Qbs Support', '2024-01-17 11:49:30'),
(2044, 'Quotation Accepted', '[ Quotation Accepted successfully ]', 'erp/sale/quotationview/9', '', 'Qbs Support', '2024-01-17 11:51:27'),
(2045, 'Order Conversion', '[ Order Conversion successfully ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/order_view/41', '', 'Qbs Support', '2024-01-17 11:58:18'),
(2046, 'Order Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete41', '{\"order_id\":\"41\",\"code\":\"q1\",\"order_date\":\"2024-01-17\",\"order_expiry\":\"2024-01-19\",\"cust_id\":\"37\",\"shippingaddr_id\":\"0\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"discount\":\"0.00\",\"terms_condition\":\"test\",\"payment_terms\":\"fds\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"0\",\"stock_pick\":\"0\",\"created_at\":\"1705492698\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-17 12:03:52'),
(2047, 'Quotation Deletion', '[ Quotation successfully deleted ]', 'erp.sale.quotation.delete9', '{\"quote_id\":\"9\",\"code\":\"qu-1\",\"quote_date\":\"2024-01-17\",\"cust_id\":\"37\",\"shippingaddr_id\":\"0\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"discount\":\"0.00\",\"terms_condition\":\"test\",\"payment_terms\":\"fds\",\"status\":\"4\",\"created_at\":\"1705492170\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-17 12:04:28'),
(2048, 'Order Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete40', '{\"order_id\":\"40\",\"code\":\"TODAY12\",\"order_date\":\"2024-01-11\",\"order_expiry\":\"2024-01-12\",\"cust_id\":\"45\",\"shippingaddr_id\":\"13\",\"transport_req\":\"0\",\"trans_charge\":\"20.00\",\"discount\":\"0.00\",\"terms_condition\":\"dfgdfs345\",\"payment_terms\":\"test\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"0\",\"stock_pick\":\"0\",\"created_at\":\"1705045514\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-17 12:04:59'),
(2049, 'Order Deletion', '[ Order successfully deleted ]', 'erp.sale.orderdelete39', '{\"order_id\":\"39\",\"code\":\"15163\",\"order_date\":\"2024-01-11\",\"order_expiry\":\"2024-01-11\",\"cust_id\":\"6\",\"shippingaddr_id\":\"3\",\"transport_req\":\"1\",\"trans_charge\":\"20.00\",\"discount\":\"0.00\",\"terms_condition\":\"sdfsdf\",\"payment_terms\":\"dsfsdf\",\"status\":\"0\",\"remarks\":\"\",\"type\":\"1\",\"can_edit\":\"0\",\"stock_pick\":\"0\",\"created_at\":\"1704980141\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-17 12:06:38'),
(2050, 'Quotation Insert', '[ Quotation successfully created ]', 'erp/sale/quotationview/10', '', 'Qbs Support', '2024-01-17 12:08:10'),
(2051, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-17 12:30:34'),
(2052, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-18 04:45:29'),
(2053, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-18 04:48:21'),
(2054, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-18 04:48:33'),
(2055, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 04:49:39'),
(2056, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-18 04:50:45'),
(2057, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 04:52:13'),
(2058, 'Credit Notes Notification Insert', '[ Credit Notes Notification successfully created ]', 'erp/sale/creditview/14', '', 'Qbs Support', '2024-01-18 04:58:14'),
(2059, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:00:39'),
(2060, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:01:06'),
(2061, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:01:21'),
(2062, 'Quotation Update', '[ Quotation successfully updated ]', 'erp/sale/quotationview/10', '', 'Qbs Support', '2024-01-18 05:22:41'),
(2063, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:24:26'),
(2064, 'Service Insert', '[ Service successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:38:05'),
(2065, 'Service Insert', '[ Service successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:38:53'),
(2066, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 05:39:08'),
(2067, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/60', '', 'Qbs Support', '2024-01-18 05:50:56'),
(2068, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/60', '', 'Qbs Support', '2024-01-18 05:51:33'),
(2069, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 06:09:12'),
(2070, 'Service Update', '[ Service failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 06:09:25'),
(2071, 'Service Update', '[ Service failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 06:09:34'),
(2072, 'Service Update', '[ Service failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 06:09:55'),
(2073, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 06:10:13'),
(2074, 'Quotation Update', '[ Quotation successfully updated ]', 'erp/sale/quotationview/10', '', 'Qbs Support', '2024-01-18 06:17:28'),
(2075, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 07:11:33'),
(2076, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 07:11:53'),
(2077, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 07:12:06'),
(2078, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 07:12:37'),
(2079, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-18 09:14:40'),
(2080, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete59', '{\"invoice_id\":\"59\",\"code\":\"INV90\",\"cust_id\":\"6\",\"name\":\"shankar\",\"invoice_date\":\"2024-01-17\",\"invoice_expiry\":\"2024-01-18\",\"shippingaddr_id\":\"10\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"fds\",\"terms_condition\":\"test\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-18 09:15:12'),
(2081, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete53', '{\"invoice_id\":\"53\",\"code\":\"QWE02\",\"cust_id\":\"45\",\"name\":\"john\",\"invoice_date\":\"2024-01-12\",\"invoice_expiry\":\"2024-01-12\",\"shippingaddr_id\":\"13\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"fdsgfdg\",\"terms_condition\":\"sdfgbcbb\",\"discount\":\"0.00\"}', 'Qbs Support', '2024-01-18 09:17:40'),
(2082, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete15', '{\"credit_id\":\"15\",\"code\":\"s1014\",\"invoice_id\":\"57\",\"applied\":\"0\",\"issued_date\":\"2024-01-17\",\"other_charge\":\"100.00\",\"payment_terms\":\"cheque\",\"terms_condition\":\"fine\",\"remarks\":\"okay\"}', 'Qbs Support', '2024-01-18 09:49:44'),
(2083, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete19', '{\"credit_id\":\"19\",\"code\":\"srgeas856\",\"invoice_id\":\"60\",\"applied\":\"0\",\"issued_date\":\"2024-01-18\",\"other_charge\":\"100.00\",\"payment_terms\":\"google pay\",\"terms_condition\":\"safgasg\",\"remarks\":\"asdgag\"}', 'Qbs Support', '2024-01-18 09:51:12'),
(2084, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes_view/60', '', 'Qbs Support', '2024-01-18 10:21:01'),
(2085, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/34', '{\"estimate_id\":\"34\",\"code\":\"PASU25\",\"estimate_date\":\"2024-01-11\",\"terms_condition\":\"test\",\"name\":\"geroge\",\"cust_id\":\"47\",\"shippingaddr_id\":\"14\"}', 'Qbs Support', '2024-01-18 10:47:22'),
(2086, 'Quotation Deletion', '[ Quotation successfully deleted ]', 'erp.sale.quotation.delete3', '{\"quote_id\":\"3\",\"code\":\"54\",\"quote_date\":\"2024-01-13\",\"cust_id\":\"6\",\"shippingaddr_id\":\"3\",\"transport_req\":\"0\",\"trans_charge\":\"50.41\",\"discount\":\"0.00\",\"terms_condition\":\"asd\",\"payment_terms\":\"ssad\",\"status\":\"4\",\"created_at\":\"1604517838\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-18 10:54:48'),
(2087, 'Sale Order Insert', '[ Sale Order failed to create ]', '', '', 'Qbs Support', '2024-01-18 11:24:27'),
(2088, 'Sale Order Insert', '[ Sale Order failed to create ]', '', '', 'Qbs Support', '2024-01-18 11:26:53'),
(2089, 'Sale Order Insert', '[ Sale Order failed to create ]', '', '', 'Qbs Support', '2024-01-18 11:29:20'),
(2090, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/46', '', 'Qbs Support', '2024-01-18 11:31:37'),
(2091, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-18 12:57:55'),
(2092, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-18 12:58:16'),
(2093, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-19 04:51:03'),
(2094, 'Customer Deletion', '[ Customer successfully deleted ]', 'erp.crm.customerdelete6', '{\"cust_id\":\"6\",\"name\":\"shankar\",\"position\":\"manager\",\"address\":\"test\",\"city\":\"chennai\",\"state\":\"tamilnadu\",\"country\":\"india\",\"zip\":\"6000125\",\"email\":\"shankar@qqq.com\",\"phone\":\"9876543210\",\"fax_num\":\"\",\"office_num\":\"\",\"company\":\"Shankar Company\",\"gst\":\"dfdgdfh\",\"website\":\"\",\"description\":\"\",\"remarks\":\"\",\"created_at\":\"1644925530\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-19 04:51:37'),
(2095, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-19 04:52:22'),
(2096, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-19 04:52:24'),
(2097, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-19 04:52:39'),
(2098, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/2', '', 'Qbs Support', '2024-01-19 05:13:14'),
(2099, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/2', '', 'Qbs Support', '2024-01-19 05:13:58'),
(2100, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-19 05:36:48'),
(2101, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-19 05:40:47'),
(2102, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-19 05:41:25'),
(2103, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-19 05:44:40'),
(2104, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-19 05:44:56'),
(2105, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-19 05:45:25'),
(2106, 'Currency Insert', '[ Currency successfully created ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-19 06:11:56'),
(2107, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-19 06:12:21'),
(2108, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-19 06:49:12'),
(2109, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 07:23:14'),
(2110, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/4', '', 'Qbs Support', '2024-01-19 08:01:45'),
(2111, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 09:15:33'),
(2112, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 09:16:47'),
(2113, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/4', '', 'Qbs Support', '2024-01-19 09:34:20'),
(2114, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 09:35:25'),
(2115, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/5', '', 'Qbs Support', '2024-01-19 09:42:58'),
(2116, 'Scheduling Update', '[ Scheduling failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 10:06:09'),
(2117, 'Scheduling Update', '[ Scheduling successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 10:06:23'),
(2118, 'Scheduling Update', '[ Scheduling successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 10:06:40'),
(2119, 'Scheduling Update', '[ Scheduling successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-19 10:06:50'),
(2120, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/46', '', 'Qbs Support', '2024-01-19 10:42:44'),
(2121, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/47', '', 'Qbs Support', '2024-01-19 10:42:59'),
(2122, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-19 11:03:05'),
(2123, 'Service Update', '[ Service failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-19 11:03:12'),
(2124, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-19 11:16:40'),
(2125, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-19 11:40:11'),
(2126, 'Service Insert', '[ Service successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-19 11:49:00'),
(2127, 'Leads Deletion', '[ Leads successfully deleted ]', 'erp.crm.leaddelete4', '{\"lead_id\":\"4\",\"source_id\":\"4\",\"status\":\"1\",\"assigned_to\":\"2\",\"name\":\"john\",\"position\":\"Purchase Manager\",\"address\":\"No.164, First Floor, Arcot Rd, Valasaravakkam\",\"city\":\"Chennai\",\"state\":\"Tamil Nadu\",\"country\":\"India\",\"zip\":\"600087\",\"phone\":\"09080780700\",\"email\":\"admin@example.com\",\"website\":\"\",\"company\":\"john enterprise\",\"description\":\"fgg\",\"remarks\":\"\",\"created_at\":\"\",\"created_by\":\"1\"}', 'Qbs Support', '2024-01-19 11:53:47'),
(2128, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Support', '2024-01-19 11:55:39'),
(2129, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-19 12:03:55'),
(2130, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 04:38:04'),
(2131, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 04:38:46'),
(2132, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-20 04:48:18'),
(2133, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 05:00:01'),
(2134, 'Scheduling Delete', '[ Scheduling successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-20 05:00:50'),
(2135, 'Scheduling Delete', '[ Scheduling successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-20 05:01:05'),
(2136, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/1', '', 'Qbs Support', '2024-01-20 05:18:06'),
(2137, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 05:18:27'),
(2138, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 05:18:59'),
(2139, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 05:21:29'),
(2140, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 05:48:11'),
(2141, 'Payroll Process', '[ Payroll successfully processed ]', 'erp/hr/payrolls', '', 'Qbs Support', '2024-01-20 05:57:59'),
(2142, 'Delivery Record Update', '[ Delivery Record successfully updated ]', '', '', 'Qbs Support', '2024-01-20 06:05:30'),
(2143, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 06:40:56'),
(2144, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 06:46:34'),
(2145, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 09:18:03'),
(2146, 'Delivery Record Update', '[ Delivery Record successfully updated ]', '', '', 'Qbs Support', '2024-01-20 09:31:44'),
(2147, 'Transport Insert', '[ Transport successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:32:06'),
(2148, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:33:15'),
(2149, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'Qbs Support', '2024-01-20 09:33:21'),
(2150, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'Qbs Support', '2024-01-20 09:33:26'),
(2151, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:33:42'),
(2152, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:33:53'),
(2153, 'Transport Type Insert', '[ Transport Type successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:34:04'),
(2154, 'Transport Insert', '[ Transport successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:34:29'),
(2155, 'Transport Insert', '[ Transport successfully created ]', '', '', 'Qbs Support', '2024-01-20 09:35:52'),
(2156, 'Transport Update', '[ Transport successfully updated ]', '', '', 'Qbs Support', '2024-01-20 09:36:09'),
(2157, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 09:37:46'),
(2158, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 09:38:49'),
(2159, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Support', '2024-01-20 09:38:54'),
(2160, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Support', '2024-01-20 09:39:01'),
(2161, 'RFQ Resend', '[ RFQ Resend sucessfully created ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-20 09:39:25'),
(2162, 'RFQ Send Batch', '[ RFQ Send Batch sucessfully created ]', 'erp/procurement/rfqview/1', '', 'Qbs Support', '2024-01-20 09:39:37'),
(2163, 'Planning Update', '[ Planning failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 09:47:26'),
(2164, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 09:47:34'),
(2165, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 09:52:27'),
(2166, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 09:53:58'),
(2167, 'Planning Update', '[ Planning failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 10:00:26'),
(2168, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 10:00:31'),
(2169, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 10:04:03'),
(2170, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-20 10:28:28'),
(2171, 'Lead Insert', '[ Lead successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-view/19', '', 'Qbs Support', '2024-01-20 10:33:19'),
(2172, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Support', '2024-01-20 10:38:20'),
(2173, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Support', '2024-01-20 10:50:27'),
(2174, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Support', '2024-01-20 10:52:37'),
(2175, 'Lead Import', '[ Lead partially imported ]', '', '', 'Qbs Support', '2024-01-20 10:55:39'),
(2176, 'Task Insert', '[ Task successfully created ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-20 11:00:06'),
(2177, 'Task Update', '[ Task successfully updated ]', 'erp/crm/task', '', 'Qbs Support', '2024-01-20 11:00:32'),
(2178, 'Task Delete', '[ Task successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/task', '', 'Qbs Support', '2024-01-20 11:00:37'),
(2179, 'Customer Insert', '[ Customer successfully created ]', 'erp/crm/customerview/48', '', 'Qbs Support', '2024-01-20 11:02:12'),
(2180, 'Marketing Insert', '[ Marketing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Support', '2024-01-20 11:04:16'),
(2181, 'Marketing Update', '[ Marketing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Support', '2024-01-20 11:04:32'),
(2182, 'Marketing Update', '[ Marketing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Support', '2024-01-20 11:04:42'),
(2183, 'Marketing Delete', '[ Marketing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Support', '2024-01-20 11:04:53'),
(2184, 'Ticket Insert', '[ Ticket successfully created ]', 'erp/crm/tickets', '', 'Qbs Support', '2024-01-20 11:05:18'),
(2185, 'Tickets Delete', '[ Tickets successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/marketing', '', 'Qbs Support', '2024-01-20 11:05:52'),
(2186, 'Ticket Update', '[ Ticket successfully updated ]', 'erp/crm/tickets', '', 'Qbs Support', '2024-01-20 11:06:02'),
(2187, 'Login', '[ User successfully logged in ]', '', '', 'Qbs Support', '2024-01-20 11:06:14'),
(2188, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/35', '', 'Qbs Support', '2024-01-20 11:06:46'),
(2189, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/35', '', 'Qbs Support', '2024-01-20 11:07:19'),
(2190, 'Estimate Notification Update', '[ Estimate Notification successfully updated ]', 'erp/sale/estimateview/35', '', 'Qbs Support', '2024-01-20 11:07:35'),
(2191, 'Estimate Notification Delete', '[ Estimate Notification successfully deleted ]', 'erp/sale/estimateview/35', '', 'Qbs Support', '2024-01-20 11:07:41'),
(2192, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/35', '', 'Qbs Support', '2024-01-20 11:08:02'),
(2193, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/35', '{\"estimate_id\":\"35\",\"code\":\"dima\",\"estimate_date\":\"2024-01-20\",\"terms_condition\":\"szfgsrge\",\"name\":\"john\",\"cust_id\":\"45\",\"shippingaddr_id\":\"13\"}', 'Qbs Support', '2024-01-20 11:08:07'),
(2194, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 11:08:45'),
(2195, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 11:09:14'),
(2196, 'Quotation Notification Insert', '[ Quotation Notification successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/quotations_view/5', '', 'Qbs Support', '2024-01-20 11:09:14'),
(2197, 'Quotation Notification Update', '[ Quotation Notification successfully updated ]', 'erp/sale/quotationview/5', '', 'Qbs Support', '2024-01-20 11:09:23'),
(2198, 'Quotation Notification Delete', '[ Quotation Notification successfully deleted ]', 'erp/sale/quotationview/5', '', 'Qbs Support', '2024-01-20 11:09:28'),
(2199, 'Sale Order Notification Insert', '[ Sale Order Notification successfully created ]', 'erp/sale/orderview/31', '', 'Qbs Support', '2024-01-20 11:10:23'),
(2200, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 11:10:46'),
(2201, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-20 11:11:10'),
(2202, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs Support', '2024-01-20 11:11:28'),
(2203, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/65', '', 'Qbs Support', '2024-01-20 11:13:16'),
(2204, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 11:15:47'),
(2205, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 11:16:49'),
(2206, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 11:23:26'),
(2207, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete27', '{\"credit_id\":\"27\",\"code\":\"SO128srg\",\"invoice_id\":\"0\",\"applied\":\"0\",\"issued_date\":\"2024-01-20\",\"other_charge\":\"100.00\",\"payment_terms\":\"shsrh\",\"terms_condition\":\"ahsh\",\"remarks\":\"ahsrh\"}', 'Qbs Support', '2024-01-20 11:23:41'),
(2208, 'Account Group Insert', '[ Account Group successfully created ]', 'erp/finance/accountgroup/', '', 'Qbs Support', '2024-01-20 11:24:18'),
(2209, 'Account Group Update', '[ Account Group successfully updated ]', 'erp/finance/accountgroups/', '', 'Qbs Support', '2024-01-20 11:24:28'),
(2210, 'Account Group Delete', '[ Account Group successfully deleted ]', 'erp/finance/accountgroups/', '', 'Qbs Support', '2024-01-20 11:24:34'),
(2211, 'GL Account Import', '[ GL Account successfully imported ]', '', '', 'Qbs Support', '2024-01-20 11:25:34'),
(2212, 'GL Account Delete', '[ GL Account successfully deleted ]', 'erp/finance/glaccounts/', '', 'Qbs Support', '2024-01-20 11:26:18'),
(2213, 'GL Account Insert', '[ GL Account successfully created ]', 'erp/finance/glaccounts/', '', 'Qbs Support', '2024-01-20 11:26:56'),
(2214, 'GL Account Insert', '[ GL Account successfully created ]', 'erp/finance/glaccounts/', '', 'Qbs Support', '2024-01-20 11:27:28'),
(2215, 'GL Account Delete', '[ GL Account successfully deleted ]', 'erp/finance/glaccounts/', '', 'Qbs Support', '2024-01-20 11:27:33'),
(2216, 'Bank Account Insert', '[ Bank Account successfully created ]', 'erp/finance/bankaccounts/', '', 'Qbs Support', '2024-01-20 11:28:00'),
(2217, 'Journal Entry Insert', '[ Journal Entry successfully created ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-20 11:30:47'),
(2218, 'Journal Entry Delete', '[ Journal Entry successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-20 11:31:22'),
(2219, 'Automation Delete', '[ Automation successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Support', '2024-01-20 11:33:16'),
(2220, 'Automation Insert', '[ Automation successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/finance/automation', '', 'Qbs Support', '2024-01-20 11:33:46'),
(2221, 'Payment Mode Update', '[ Payment Mode successfully updated ]', 'erp/finance/paymentmode/', '', 'Qbs Support', '2024-01-20 11:34:03'),
(2222, 'Payment Mode Insert', '[ Payment Mode successfully created ]', 'erp/finance/paymentmode/', '', 'Qbs Support', '2024-01-20 11:34:12'),
(2223, 'Payment Mode Update', '[ Payment Mode successfully updated ]', 'erp/finance/paymentmode/', '', 'Qbs Support', '2024-01-20 11:34:20'),
(2224, 'Payment Mode Delete', '[ Payment Mode successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-20 11:34:24'),
(2225, 'Tax Insert', '[ Tax successfully created ]', 'erp/finance/tax/', '', 'Qbs Support', '2024-01-20 11:34:44'),
(2226, 'Tax Update', '[ Tax successfully updated ]', 'erp/finance/tax/', '', 'Qbs Support', '2024-01-20 11:34:51'),
(2227, 'Tax Delete', '[ Tax successfully deleted ]', 'erp/finance/tax/', '', 'Qbs Support', '2024-01-20 11:34:56'),
(2228, 'Currency Update', '[ Currency successfully updated ]', 'erp/finance/currency/', '', 'Qbs Support', '2024-01-20 11:35:27'),
(2229, 'Currency Delete', '[ Currency successfully deleted ]', 'erp/finance/journalentry/', '', 'Qbs Support', '2024-01-20 11:35:34'),
(2230, 'Raw Material Insert', '[ Raw Material successfully created ]', '', '', 'Qbs Support', '2024-01-20 11:40:14'),
(2231, 'Stock Alert Insert', '[ Stock Alert successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/inventory/rawmaterials-view/69', '', 'Qbs Support', '2024-01-20 11:40:37'),
(2233, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-20 11:41:51'),
(2235, ' Finished Good Insert', '[ Finished Good successfully created ]', '', '', 'Qbs Support', '2024-01-20 11:43:24'),
(2236, ' Service Insert', '[ Service successfully created ]', '', '', 'Qbs Support', '2024-01-20 11:44:26'),
(2237, ' Service Update', '[ Service successfully updated ]', '', '', 'Qbs Support', '2024-01-20 11:44:52'),
(2238, 'Property Type Insert', '[ Property Type successfully created ]', 'erp/inventory/propertytype', '', 'Qbs Support', '2024-01-20 11:45:09'),
(2239, 'Property Type Update', '[ Property Type successfully updated ]', 'erp/inventory/propertytype', '', 'Qbs Support', '2024-01-20 11:45:15'),
(2240, 'Amenity Insert', '[ Amenity successfully created ]', 'erp/inventory/amenity', '', 'Qbs Support', '2024-01-20 11:45:58'),
(2241, 'Amenity Update', '[ Amenity successfully updated ]', 'erp/inventory/amenity', '', 'Qbs Support', '2024-01-20 11:46:11'),
(2242, 'Property Insert', '[ Property successfully created ]', 'erp/inventory/property-view/13', '', 'Qbs Support', '2024-01-20 11:46:41'),
(2243, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/13', '', 'Qbs Support', '2024-01-20 11:46:49'),
(2244, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete25', '{\"credit_id\":\"25\",\"code\":\"fhegahg\",\"invoice_id\":\"0\",\"applied\":\"0\",\"issued_date\":\"2024-01-20\",\"other_charge\":\"100.00\",\"payment_terms\":\"cheque\",\"terms_condition\":\"eadgserh\",\"remarks\":\"aefhseh\"}', 'Qbs Support', '2024-01-20 11:47:15'),
(2245, 'Property Update', '[ Property successfully updated ]', 'erp/inventory/property-view/13', '', 'Qbs Support', '2024-01-20 11:47:15'),
(2246, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete24', '{\"credit_id\":\"24\",\"code\":\"cn7\",\"invoice_id\":\"0\",\"applied\":\"0\",\"issued_date\":\"2024-01-20\",\"other_charge\":\"6000.00\",\"payment_terms\":\"12 day\",\"terms_condition\":\"dfsdf\",\"remarks\":\"sdf\"}', 'Qbs Support', '2024-01-20 11:47:23'),
(2247, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete23', '{\"credit_id\":\"23\",\"code\":\"cn6\",\"invoice_id\":\"0\",\"applied\":\"0\",\"issued_date\":\"2024-01-20\",\"other_charge\":\"5000.00\",\"payment_terms\":\"12 day\",\"terms_condition\":\"tet\",\"remarks\":\"fsf\"}', 'Qbs Support', '2024-01-20 11:47:28'),
(2248, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-20 11:47:39'),
(2249, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-20 11:47:47'),
(2250, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-20 11:47:51'),
(2251, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-20 11:48:22'),
(2252, 'Price List Update', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs Support', '2024-01-20 11:48:27'),
(2253, 'Unit Insert', '[ Unit successfully created ]', 'erp/inventory/units', '', 'Qbs Support', '2024-01-20 11:49:06'),
(2254, 'Unit Update', '[ Unit successfully updated ]', 'erp/inventory/units', '', 'Qbs Support', '2024-01-20 11:49:14'),
(2255, 'Unit Delete', '[ Unit successfully deleted ]', 'erp/inventory/units', '', 'Qbs Support', '2024-01-20 11:49:19'),
(2256, 'Brand Insert', '[ Brand successfully created ]', 'erp/inventory/brands', '', 'Qbs Support', '2024-01-20 11:49:41'),
(2257, 'Brand Update', '[ Brand successfully updated ]', 'erp/inventory/brands', '', 'Qbs Support', '2024-01-20 11:49:46'),
(2258, 'Brand Delete', '[ Brand successfully deleted ]', 'erp/inventory/brands', '', 'Qbs Support', '2024-01-20 11:49:51'),
(2259, 'Warehouse Insert', '[ Warehouse successfully created]', 'erp/warehouse/warehouses', '', 'Qbs Support', '2024-01-20 11:52:03'),
(2260, 'Warehouse Update', '[ Warehouse successfully updated ]', 'erp/warehouse/warehouses', '', 'Qbs Support', '2024-01-20 11:52:12'),
(2261, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.warehouse.delete16', '{\"warehouse_id\":\"16\",\"name\":\"Production \",\"address\":\"chennai\",\"city\":\"Thiruvallur\",\"state\":\"tamilnadu\",\"country\":\"India\",\"zipcode\":\"602024\",\"has_bins\":\"0\",\"description\":\"adsgarg\",\"aisle_count\":\"0\",\"racks_per_aisle\":\"0\",\"shelf_per_rack\":\"0\",\"bins_per_shelf\":\"0\"}', 'Qbs Support', '2024-01-20 11:52:17'),
(2262, 'Raw Material Update', '[ Raw Material successfully updated ]', '', '', 'Qbs Support', '2024-01-20 11:52:37'),
(2263, 'Stock Transfer', '[ Stock Transfer failed ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-20 11:54:21'),
(2264, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-20 11:54:34'),
(2265, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-20 11:54:44'),
(2266, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-20 11:55:00'),
(2267, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-20 11:55:24'),
(2268, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-20 11:56:09'),
(2269, 'Stock Update', '[ Stock successfully updated ]', 'erp/warehouse/managestock', '', 'Qbs Support', '2024-01-20 11:56:22'),
(2270, 'Managestock Deletion', '[ Managestock successfully deleted ]', 'erp.warehouse.managestock', '{\"pack_unit_id\":\"30\",\"sku\":\"801\",\"related_to\":\"finished_good\",\"related_id\":\"21\",\"bin_name\":\"10\",\"mfg_date\":\"2024-01-18\",\"batch_no\":\"2\",\"lot_no\":\"801\"}', 'Qbs Support', '2024-01-20 11:56:29'),
(2271, 'Dispatch Update', '[ Dispatch successfully updated ]', 'erp.dispatch.edit16', '', 'Qbs Support', '2024-01-20 11:57:20'),
(2272, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete17', '{\"dispatch_id\":\"17\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-13 17:58:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"2\",\"pick_list_id\":\"0\",\"description\":\"sdgwadhaeth\",\"created_at\":\"1705141577\",\"updated_at\":\"1705141577\"}', 'Qbs Support', '2024-01-20 11:57:25'),
(2273, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs Support', '2024-01-20 11:58:34'),
(2274, 'Supplier Contact Insert', '[ Supplier Contact successfully created ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 11:59:10'),
(2275, 'Supplier Contact Update', '[ Supplier Contact successfully updated ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 11:59:59'),
(2276, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:00:17'),
(2277, 'Supplier Location Update', '[ Supplier Location successfully updated ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:00:33'),
(2278, 'Supplier Supply List Insert', '[ Supplier Supply List successfully created ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:01:05'),
(2279, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:01:17'),
(2280, 'Supplier Supply List Update', '[ Supplier Supply List successfully updated ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:01:35'),
(2281, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:01:56'),
(2282, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/5', '', 'Qbs Support', '2024-01-20 12:02:07'),
(2283, 'Supplier Source Insert', '[ Supplier Source successfully created ]', 'erp/supplier/sources', '', 'Qbs Support', '2024-01-20 12:02:32'),
(2284, 'Supplier Source Update', '[ Supplier Source successfully updated ]', 'erp/supplier/sources', '', 'Qbs Support', '2024-01-20 12:02:41'),
(2285, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-20 12:04:54'),
(2286, 'Supplier Source Update', '[ Supplier Source failed to update ]', 'erp/supplier/sources', '', 'Qbs Support', '2024-01-20 12:05:08'),
(2287, 'Segments For Supplier Update', '[ Segments For Supplier successfully updated ]', 'erp/supplier/supplier-view/4', '', 'Qbs Support', '2024-01-20 12:05:29'),
(2288, 'Selection Rule Insert', '[ Selection Rule successfully created ]', '', '', 'Qbs Support', '2024-01-20 12:06:23'),
(2289, 'Selection Rule Update', '[ Selection Rule successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:06:30'),
(2290, 'Requisition Insert', '[ Requisition successfully created ]', 'erp/procurement/requisitionview/7', '', 'Qbs Support', '2024-01-20 12:07:10'),
(2291, 'Stock Transfer', '[ Stock Tranfer successfully done ]', 'erp/warehouse/currentstock', '', 'Qbs Support', '2024-01-20 12:07:11');
INSERT INTO `erp_log` (`log_id`, `title`, `log_text`, `ref_link`, `additional_info`, `done_by`, `created_at`) VALUES
(2292, 'Requisition Delete', '[ Requisition Deleted successfully ]', 'erp/procurement/requisitionview/7', '[{\"invent_req_id\":\"8\",\"req_id\":\"7\",\"related_to\":\"semi_finished\",\"related_id\":\"17\",\"qty\":\"1\"},{\"req_id\":\"7\",\"req_code\":\"55454\",\"assigned_to\":\"2\",\"status\":\"0\",\"priority\":\"0\",\"mail_sent\":\"0\",\"description\":\"csagdasg\",\"remarks\":\"\",\"created_at\":\"1705752430\",\"created_by\":\"1\"}]', 'Qbs Support', '2024-01-20 12:07:29'),
(2293, 'RFQ Insert', '[ RFQ successfully created ]', 'erp/procurement/rfqview/2', '', 'Qbs Support', '2024-01-20 12:07:47'),
(2294, 'RFQ Delete', '[ RFQ Deleted successfully ]', 'erp/procurement/rfqview/1', '[{\"rfq_id\":\"1\",\"rfq_code\":\"RFQ- 1\",\"req_id\":\"1\",\"expiry_date\":\"2024-01-09\",\"terms_condition\":\"Request for proposal\",\"created_at\":\"1704777292\",\"created_by\":\"1\",\"status\":\"1\"},{\"supp_rfq_id\":\"1\",\"rfq_id\":\"1\",\"supplier_id\":\"4\",\"selection_rule\":\"3\",\"mail_status\":\"0\",\"send_contacts\":\"0\",\"include_attach\":\"1\",\"responded\":\"0\",\"responded_at\":\"\"}]', 'Qbs Support', '2024-01-20 12:07:58'),
(2295, 'Transport Type Update', '[ Transport Type successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:09:59'),
(2296, 'Transport Type Delete', '[ Transport Type successfully deleted ]', '', '', 'Qbs Support', '2024-01-20 12:10:06'),
(2297, 'Transport Insert', '[ Transport successfully created ]', '', '', 'Qbs Support', '2024-01-20 12:10:27'),
(2298, 'Transport Update', '[ Transport successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:10:34'),
(2299, 'Transport Delete', '[ Transport successfully deleted ]', '', '', 'Qbs Support', '2024-01-20 12:10:39'),
(2300, 'Team Insert', '[ Team successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/16', '', 'Qbs Support', '2024-01-20 12:11:43'),
(2301, 'Team Member Insert', '[ Team Member successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams-view/15', '', 'Qbs Support', '2024-01-20 12:12:12'),
(2302, 'Team Member Delete', '[ Team Member successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/teams', '', 'Qbs Support', '2024-01-20 12:12:22'),
(2303, 'Workgroup Insert', '[ Workgroup successfully created ]', 'erp/project/workgroups/', '', 'Qbs Support', '2024-01-20 12:12:56'),
(2304, 'Workgroup Update', '[ Workgroup successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2024-01-20 12:13:04'),
(2305, 'Workgroup Delete', '[ Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/workgroups', '', 'Qbs Support', '2024-01-20 12:13:08'),
(2306, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:13:33'),
(2307, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:13:48'),
(2308, 'Project Phase Update', '[ Project Phase successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:14:12'),
(2309, 'Project Expense Insert', '[ Project Expense successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:15:03'),
(2310, 'Project Rawmaterials Insert', '[ Project Rawmaterials successfully inserted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:15:30'),
(2311, 'Project Rawmaterials Update', '[ Project Rawmaterials successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:15:48'),
(2312, 'Project Rawmaterials Delete', '[ Project Rawmaterials successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:15:53'),
(2313, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs Support', '2024-01-20 12:16:06'),
(2314, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 12:17:40'),
(2315, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete28', '{\"credit_id\":\"28\",\"code\":\"c11\",\"invoice_id\":\"0\",\"applied\":\"0\",\"issued_date\":\"2024-01-20\",\"other_charge\":\"1000.00\",\"payment_terms\":\"sdf\",\"terms_condition\":\"sfd\",\"remarks\":\"sdf\"}', 'Qbs Support', '2024-01-20 12:18:39'),
(2316, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 12:19:37'),
(2317, 'Service Insert', '[ Service successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-20 12:25:27'),
(2318, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs Support', '2024-01-20 12:25:27'),
(2319, 'Scheduling Insert', '[ Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/7', '', 'Qbs Support', '2024-01-20 12:25:48'),
(2320, 'Scheduling Update', '[ Scheduling successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/7', '', 'Qbs Support', '2024-01-20 12:25:56'),
(2321, 'Scheduling Delete', '[ Scheduling successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service-view/7', '', 'Qbs Support', '2024-01-20 12:26:01'),
(2322, 'Service Update', '[ Service successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/service/service', '', 'Qbs Support', '2024-01-20 12:26:19'),
(2323, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 12:28:21'),
(2324, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs Support', '2024-01-20 12:30:55'),
(2325, 'Equipment Insert', '[ Equipment successfully created ]', 'erp/assets/add_equipment/6', '', 'Qbs Support', '2024-01-20 12:33:12'),
(2326, 'Equipment Update', '[ Equipment successfully updated ]', 'erp/asset/edit_equipment/6', '', 'Qbs Support', '2024-01-20 12:33:51'),
(2327, 'Equipment Deletion', '[ Equipment successfully deleted ]', 'erp/assets/delete_equipment/6', '{\"equip_id\":\"6\",\"name\":\"Tha\",\"code\":\"ghf8787\",\"model\":\"esrah\",\"maker\":\"aerah\",\"bought_date\":\"2024-01-26\",\"age\":\"20\",\"work_type\":\"Manual\",\"consump_type\":\"Electric\",\"consumption\":\"fdhbfgh\",\"status\":\"1\",\"description\":\"dfhdszfhsf\",\"created_at\":\"2024-01-20 12:33:12\",\"created_by\":\"1\",\"updated_at\":\"2024-01-20 12:33:12\"}', 'Qbs Support', '2024-01-20 12:33:55'),
(2328, 'Department Insert', '[ Department successfully created ]', 'erp/hr/departments/', '', 'Qbs Support', '2024-01-20 12:34:10'),
(2329, 'Department Update', '[ Department successfully updated ]', 'erp/hr/departments/', '', 'Qbs Support', '2024-01-20 12:34:17'),
(2330, 'Department Delete', '[ Department successfully deleted ]', 'erp/hr/departments/', '', 'Qbs Support', '2024-01-20 12:34:21'),
(2331, 'Designation Insert', '[ Designation successfully created ]', 'erp/hr/designation/', '', 'Qbs Support', '2024-01-20 12:34:35'),
(2332, 'Designation Update', '[ Designation successfully updated ]', 'erp/hr/designation/', '', 'Qbs Support', '2024-01-20 12:34:44'),
(2333, 'Designation Delete', '[ Designation successfully deleted ]', 'erp/hr/designation/', '', 'Qbs Support', '2024-01-20 12:34:48'),
(2334, 'Employee Insert', '[ Employee successfully created ]', 'erp/hr/employees', '', 'Qbs Support', '2024-01-20 12:36:24'),
(2335, 'Employee Update', '[ Employee successfully updated ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-20 12:36:58'),
(2336, 'Employee Delete', '[ Employee and related data deleted successfully ]', 'erp/hr/employees/', '', 'Qbs Support', '2024-01-20 12:37:03'),
(2337, 'Employee Import', '[ Employee successfully imported ]', '', '', 'Qbs Support', '2024-01-20 12:37:43'),
(2338, 'Contractor Insert', '[ Contractor successfully created ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-20 12:38:26'),
(2339, 'Contractor Update', '[ Contractor successfully updated ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-20 12:38:53'),
(2340, 'Contractor Delete', '[ Contractor and related data deleted successfully ]', 'erp/hr/contractors/', '', 'Qbs Support', '2024-01-20 12:38:57'),
(2341, 'Deduction Insert', '[ Deduction successfully created ]', 'erp/hr/deductions/', '', 'Qbs Support', '2024-01-20 12:39:52'),
(2342, 'Credit Note Deletion', '[ Credit Note successfully deleted ]', 'erp.sale.creditnotesdelete29', '{\"credit_id\":\"29\",\"code\":\"c11\",\"invoice_id\":\"0\",\"applied\":\"0\",\"issued_date\":\"2024-01-20\",\"other_charge\":\"1000.00\",\"payment_terms\":\"dsa\",\"terms_condition\":\"dsad\",\"remarks\":\"dasd\"}', 'Qbs Support', '2024-01-20 12:39:55'),
(2343, 'Deduction Delete', '[ Deduction successfully deleted ]', 'erp/hr/deductions/', '', 'Qbs Support', '2024-01-20 12:39:58'),
(2344, 'Addition Insert', '[ Addition successfully created ]', 'erp/hr/additions/', '', 'Qbs Support', '2024-01-20 12:40:26'),
(2345, 'Addition Update', '[ Addition successfully updated ]', 'erp/hr/additions/', '', 'Qbs Support', '2024-01-20 12:40:32'),
(2346, 'Addition Delete', '[ Addition successfully deleted ]', 'erp/hr/additions/', '', 'Qbs Support', '2024-01-20 12:40:36'),
(2347, 'Payroll Insert', '[ Payroll successfully created ]', 'erp/hr/payrolls', '', 'Qbs Support', '2024-01-20 12:40:57'),
(2348, 'Payroll Update', '[ Payroll successfully updated ]', 'erp/hr/payrolls', '', 'Qbs Support', '2024-01-20 12:41:05'),
(2349, 'Payroll Process', '[ Payroll successfully processed ]', 'erp/hr/payrolls', '', 'Qbs Support', '2024-01-20 12:41:08'),
(2350, 'Payroll Delete', '[ Payroll successfully deleted ]', 'erp/hr/payrolls', '', 'Qbs Support', '2024-01-20 12:41:13'),
(2351, 'User Update', '[ User successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/user-edit/1', '', 'Qbs Support', '2024-01-20 12:41:28'),
(2352, 'Role Insert', '[ Role successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/setting/role-view/23', '', 'Qbs Support', '2024-01-20 12:41:56'),
(2353, 'Role Delete', '[ Role successfully deleted ; ID=23 ]', '', '', 'Qbs Support', '2024-01-20 12:42:12'),
(2354, 'Mail Settings Update', '[ Mail Settings successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:42:25'),
(2355, 'Group Insert', '[ Group successfully inserted ]', '', '', 'Qbs Support', '2024-01-20 12:42:42'),
(2356, 'Group Update', '[ Group successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:42:55'),
(2357, 'Group Delete', '[ Group successfully deleted ]', '', '', 'Qbs Support', '2024-01-20 12:43:01'),
(2358, 'Finance Settings Update', '[ Finance Settings successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:43:19'),
(2359, 'Finance Settings Update', '[ Finance Settings successfully updated ]', '', '', 'Qbs Support', '2024-01-20 12:43:32'),
(2360, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-20 12:48:24'),
(2361, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs Support', '2024-01-20 12:50:23'),
(2362, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 04:53:28'),
(2363, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 04:59:51'),
(2364, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 05:01:14'),
(2365, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 05:04:02'),
(2366, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 05:08:53'),
(2367, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 05:20:48'),
(2368, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs ', '2024-01-22 05:25:45'),
(2369, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs ', '2024-01-22 05:31:31'),
(2370, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 05:47:28'),
(2371, 'Property Type Insert', '[ Property Type successfully created ]', 'erp/inventory/propertytype', '', 'Qbs ', '2024-01-22 05:54:34'),
(2372, 'Property Type Insert', '[ Property Type successfully created ]', 'erp/inventory/propertytype', '', 'Qbs ', '2024-01-22 06:17:02'),
(2373, 'Price List Insert', '[ Price List successfully created ]', 'erp/inventory/pricelist', '', 'Qbs ', '2024-01-22 06:17:50'),
(2374, 'Price List Delete', '[ Price List successfully updated ]', 'erp/inventory/pricelist', '', 'Qbs ', '2024-01-22 06:20:02'),
(2375, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete22', '{\"dispatch_id\":\"22\",\"order_code\":\"ghdrfg5868796\",\"warehouse\":\"\",\"delivery_date\":\"2024-02-01 20:45:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"31\",\"cust_id\":\"47\",\"status\":\"1\",\"pick_list_id\":\"0\",\"description\":\"sdgags\",\"created_at\":\"1705749088\",\"updated_at\":\"1705749088\"}', 'Qbs ', '2024-01-22 06:33:32'),
(2376, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs ', '2024-01-22 07:07:43'),
(2377, 'Dispatch Insert', '[ Dispatch successfully created ]', 'sale/order_add_dispatch/', '', 'Qbs ', '2024-01-22 07:07:45'),
(2378, 'Dispatch Deletion', '[ Dispatch successfully deleted ]', 'erp.dispatch.delete24', '{\"dispatch_id\":\"24\",\"order_code\":\"USAP234\",\"warehouse\":\"\",\"delivery_date\":\"2024-01-22 16:41:00\",\"customer\":\"geroge\",\"suppiler_id\":\"0\",\"order_id\":\"36\",\"cust_id\":\"47\",\"status\":\"0\",\"pick_list_id\":\"0\",\"description\":\"gdfgdf\",\"created_at\":\"1705907265\",\"updated_at\":\"1705907265\"}', 'Qbs ', '2024-01-22 07:07:58'),
(2379, 'Dispatch Update', '[ Dispatch successfully updated ]', 'erp.dispatch.edit23', '', 'Qbs ', '2024-01-22 07:08:19'),
(2380, 'Dispatch Update', '[ Dispatch successfully updated ]', 'erp.dispatch.edit19', '', 'Qbs ', '2024-01-22 07:09:33'),
(2381, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/4', '', 'Qbs ', '2024-01-22 07:19:40'),
(2382, 'Supplier Location Insert', '[ Supplier Location successfully created ]', 'erp/supplier/supplier-view/4', '', 'Qbs ', '2024-01-22 07:19:47'),
(2383, 'Supplier Source Delete', '[ Supplier Source failed to delete ]', '', '', 'Qbs ', '2024-01-22 07:31:25'),
(2384, 'Supplier Source Insert', '[ Supplier Source successfully created ]', 'erp/supplier/sources', '', 'Qbs ', '2024-01-22 07:31:34'),
(2385, 'Supplier Source Delete', '[ Supplier Source successfully deleted ]', '', '', 'Qbs ', '2024-01-22 07:31:39'),
(2386, 'Supplier Source Insert', '[ Supplier Source successfully created ]', 'erp/supplier/sources', '', 'Qbs ', '2024-01-22 07:31:46'),
(2387, 'Selection Rule Insert', '[ Selection Rule successfully created ]', '', '', 'Qbs ', '2024-01-22 07:39:35'),
(2388, 'Supplier Insert', '[ Supplier successfully created ]', '', '', 'Qbs ', '2024-01-22 07:40:17'),
(2389, 'Project Phase Update', '[ Project Phase successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs ', '2024-01-22 07:43:45'),
(2390, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/32', '', 'Qbs ', '2024-01-22 07:51:26'),
(2391, 'Add to Stock Manual', '[ Add to Stock Manual successfully done ]', 'erp/warehouse/managestock/', '', 'Qbs ', '2024-01-22 07:51:43'),
(2392, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/32', '', 'Qbs ', '2024-01-22 07:52:13'),
(2393, 'Project Phase Insert', '[ Project Phase successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs ', '2024-01-22 07:54:05'),
(2394, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/36', '', 'Qbs ', '2024-01-22 07:54:13'),
(2395, 'Project Phase Update', '[ Project Phase successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs ', '2024-01-22 07:54:15'),
(2396, 'Project Workgroup Insert', '[ Project Workgroup successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs ', '2024-01-22 07:54:32'),
(2397, 'Project Workgroup Delete', '[ Project Workgroup successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/22', '', 'Qbs ', '2024-01-22 07:56:35'),
(2398, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/37', '', 'Qbs ', '2024-01-22 07:56:47'),
(2399, 'Estimate Deletion', '[ Estimate successfully deleted ]', 'erp/sale/delete_estimate/37', '{\"estimate_id\":\"37\",\"code\":\"e-4\",\"estimate_date\":\"2024-01-22\",\"terms_condition\":\"test\",\"name\":\"jacob\",\"cust_id\":\"46\",\"shippingaddr_id\":\"0\"}', 'Qbs ', '2024-01-22 07:57:16'),
(2400, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 07:58:24'),
(2401, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 07:58:32'),
(2402, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 07:58:46'),
(2403, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 07:59:09'),
(2404, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs ', '2024-01-22 07:59:23'),
(2405, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:00:29'),
(2406, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:36:29'),
(2407, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:36:43'),
(2408, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:36:53'),
(2409, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:40:46'),
(2410, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:40:51'),
(2411, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:42:24'),
(2412, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/40', '', 'Qbs ', '2024-01-22 08:43:10'),
(2413, 'Estimate Update', '[ Estimate successfully updated ]', 'erp/sale/estimateview/33', '', 'Qbs ', '2024-01-22 08:45:19'),
(2414, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/41', '', 'Qbs ', '2024-01-22 08:46:29'),
(2415, 'Estimate Insert', '[ Estimate successfully created ]', 'erp/sale/estimateview/42', '', 'Qbs ', '2024-01-22 08:56:25'),
(2416, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:56:49'),
(2417, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/24', '', 'Qbs ', '2024-01-22 08:57:13'),
(2418, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:57:26'),
(2419, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:57:50'),
(2420, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 08:58:10'),
(2421, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:04:40'),
(2422, 'Project Testing Update', '[ Project Testing successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:05:03'),
(2423, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:13:21'),
(2424, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:22:25'),
(2425, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:24:09'),
(2426, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:26:43'),
(2427, 'Project Testing Delete', '[ Project Testing failed to delete ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/15', '', 'Qbs ', '2024-01-22 09:33:47'),
(2428, 'Project Insert', '[ Project successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/25', '', 'Qbs ', '2024-01-22 09:34:45'),
(2429, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:35:32'),
(2430, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/65', '', 'Qbs ', '2024-01-22 09:36:14'),
(2431, 'Project Testing Delete', '[ Project Testing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/16', '', 'Qbs ', '2024-01-22 09:40:53'),
(2432, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:44:20'),
(2433, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:44:24'),
(2434, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:44:26'),
(2435, 'Project Testing Delete', '[ Project Testing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/18', '', 'Qbs ', '2024-01-22 09:44:59'),
(2436, 'Project Testing Delete', '[ Project Testing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/17', '', 'Qbs ', '2024-01-22 09:46:00'),
(2437, 'Project Testing Delete', '[ Project Testing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/19', '', 'Qbs ', '2024-01-22 09:46:49'),
(2438, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-22 09:46:52'),
(2439, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:50:08'),
(2440, 'Project Testing Delete', '[ Project Testing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/20', '', 'Qbs ', '2024-01-22 09:50:19'),
(2441, 'Project Testing Insert', '[ Project Testing successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/23', '', 'Qbs ', '2024-01-22 09:50:57'),
(2442, 'Project Testing Delete', '[ Project Testing successfully deleted ]', 'http://192.168.29.166/ERP-CI4/public/erp/project/projects-view/21', '', 'Qbs ', '2024-01-22 10:01:21'),
(2443, 'MRP Scheduling Insert', '[ MRP Scheduling failed to create ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 10:09:21'),
(2444, 'MRP Scheduling Insert', '[ MRP Scheduling failed to create ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 10:09:40'),
(2445, 'MRP Scheduling Insert', '[ MRP Scheduling failed to create ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 10:11:31'),
(2446, 'MRP Scheduling Insert', '[ MRP Scheduling failed to create ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 10:19:15'),
(2447, 'MRP Scheduling Insert', '[ MRP Scheduling failed to create ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 10:19:16'),
(2448, 'MRP Scheduling Insert', '[ MRP Scheduling failed to create ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-22 10:21:03'),
(2449, 'MRP Scheduling Insert', '[ MRP Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-view/1', '', 'Qbs ', '2024-01-22 10:26:54'),
(2450, 'MRP Scheduling Insert', '[ MRP Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-view/1', '', 'Qbs ', '2024-01-22 10:30:44'),
(2451, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 04:49:16'),
(2452, 'Logout', '[ User successfully logout ]', '', '', 'Qbs ', '2024-01-23 04:50:01'),
(2453, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 04:55:05'),
(2454, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 05:18:16'),
(2455, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 06:50:10'),
(2456, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 06:52:52'),
(2457, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 07:02:16'),
(2458, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 07:08:13'),
(2459, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/66', '', 'Qbs ', '2024-01-23 07:12:41'),
(2460, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/67', '', 'Qbs ', '2024-01-23 07:15:41'),
(2461, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete67', '{\"invoice_id\":\"67\",\"code\":\"GT12341\",\"cust_id\":\"45\",\"name\":\"john\",\"invoice_date\":\"2024-01-23\",\"invoice_expiry\":\"2024-01-24\",\"shippingaddr_id\":\"13\",\"transport_req\":\"1\",\"trans_charge\":\"50.25\",\"payment_terms\":\"cheque\",\"terms_condition\":\"rfjhsyfjh\",\"discount\":\"0.00\"}', 'Qbs ', '2024-01-23 07:16:08'),
(2462, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/66', '', 'Qbs ', '2024-01-23 07:16:34'),
(2463, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 07:37:49'),
(2464, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 07:39:25'),
(2465, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/68', '', 'Qbs ', '2024-01-23 07:42:11'),
(2466, 'warehouse Deletion', '[ Warehouse successfully deleted ]', 'erp.sale.invoice.delete68', '{\"invoice_id\":\"68\",\"code\":\"GT1234hj\",\"cust_id\":\"46\",\"name\":\"jacob\",\"invoice_date\":\"2024-01-23\",\"invoice_expiry\":\"2024-01-24\",\"shippingaddr_id\":\"0\",\"transport_req\":\"0\",\"trans_charge\":\"0.00\",\"payment_terms\":\"google pay\",\"terms_condition\":\"fgjfs\",\"discount\":\"0.00\"}', 'Qbs ', '2024-01-23 07:50:28'),
(2467, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/69', '', 'Qbs ', '2024-01-23 07:52:20'),
(2468, 'Sale Order Insert', '[ Sale Order successfully created ]', 'erp/sale/orderview/47', '', 'Qbs ', '2024-01-23 07:57:44'),
(2469, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 08:35:17'),
(2470, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 08:38:59'),
(2471, 'Sale Invoice Notification Insert', '[ Sale Invoice Notification successfully created ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 08:39:27'),
(2472, 'Sale Invoice Update', '[ Sale Invoice successfully updated ]', 'erp/sale/invoiceview/48', '', 'Qbs ', '2024-01-23 08:45:56'),
(2473, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/37', '', 'Qbs ', '2024-01-23 11:03:42'),
(2474, 'Customer Update', '[ Customer successfully updated ]', 'erp/crm/customerview/45', '', 'Qbs ', '2024-01-23 11:04:28'),
(2475, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 13:25:17'),
(2476, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 13:29:24'),
(2477, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-23 13:31:39'),
(2478, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-23 13:35:26'),
(2479, 'MRP Scheduling Insert', '[ MRP Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-view/5', '', 'Qbs ', '2024-01-23 13:36:19'),
(2480, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-24 04:41:22'),
(2481, 'Login', '[ User successfully logged in ]', '', '', 'Qbs ', '2024-01-24 04:41:54'),
(2482, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/70', '', 'Qbs ', '2024-01-24 04:50:23'),
(2483, 'MRP Scheduling Insert', '[ MRP Scheduling successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-view/2', '', 'Qbs ', '2024-01-24 06:18:46'),
(2484, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:29:32'),
(2485, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:30:03'),
(2486, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:32:23'),
(2487, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:33:36'),
(2488, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:34:58'),
(2489, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:35:10'),
(2490, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:35:17'),
(2491, 'Planning Insert', '[ Planning successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:45:28'),
(2492, 'Planning Update', '[ Planning successfully updated ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:47:15'),
(2493, 'Planning Update', '[ Planning failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:48:01'),
(2494, 'Planning Update', '[ Planning failed to update ]', 'http://192.168.29.166/ERP-CI4/public/erp/mrp/planning-schedule', '', 'Qbs ', '2024-01-24 06:48:08'),
(2495, 'Credit Note Insert', '[ Credit Note successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/sales/credit_notes', '', 'Qbs ', '2024-01-24 11:33:10'),
(2496, 'Sale Invoice Insert', '[ Sale Invoice successfully created ]', 'erp/sale/invoiceview/71', '', 'Qbs ', '2024-01-24 11:35:25'),
(2497, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/71', '', 'Qbs ', '2024-01-24 11:41:47'),
(2498, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/71', '', 'Qbs ', '2024-01-24 11:46:23'),
(2499, 'Sale Payment Insert', '[ Sale Payment successfully created ]', 'erp/sale/invoiceview/71', '', 'Qbs ', '2024-01-24 11:47:16'),
(2500, 'Customer Contact Insert', '[ Customer Contact successfully created ]', 'http://192.168.29.166/ERP-CI4/public/erp/crm/lead-customer-view/45', '', 'Qbs ', '2024-01-24 12:22:10'),
(2501, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/41', '', 'Qbs ', '2024-01-24 12:27:21'),
(2502, 'Estimate Notification Insert', '[ Estimate Notification successfully created ]', 'erp/sale/estimateview/41', '', 'Qbs ', '2024-01-24 12:34:06'),
(2503, 'Estimate Notification Update', '[ Estimate Notification successfully updated ]', 'erp/sale/estimateview/41', '', 'Qbs ', '2024-01-24 12:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `erp_roles`
--

CREATE TABLE `erp_roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(60) NOT NULL,
  `role_desc` varchar(1000) NOT NULL,
  `permissions` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `referrer_role` int(11) NOT NULL,
  `can_be_purged` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_roles`
--

INSERT INTO `erp_roles` (`role_id`, `role_name`, `role_desc`, `permissions`, `created_at`, `referrer_role`, `can_be_purged`) VALUES
(11, 'Manager', 'Manages all work', '[\"crm_lead_view_global\",\"crm_lead_create\",\"crm_lead_update\",\"crm_lead_delete\",\"crm_customer_view_global\",\"crm_customer_create\",\"crm_customer_update\",\"crm_customer_delete\"]', '1643965958', 0, 1),
(15, 'Sales Rep', 'sales representative', '[\"crm_lead_view_own\",\"crm_lead_create\",\"crm_lead_update\",\"crm_lead_delete\",\"crm_customer_view_own\",\"crm_customer_create\",\"crm_customer_update\",\"crm_customer_delete\"]', '1643966205', 0, 1),
(16, 'test', 'sss', '[\"crm_lead_create\",\"crm_lead_update\",\"crm_customer_view_own\"]', '1643967631', 0, 1),
(17, 'test', 'test', '[\"do_reflect\",\"crm_lead_view_own\",\"crm_lead_create\",\"crm_lead_update\",\"crm_customer_view_own\",\"crm_customer_update\",\"crm_customer_delete\"]', '1643967665', 0, 1),
(18, 'test', 'sss', '[\"crm_lead_create\",\"crm_lead_update\",\"crm_customer_view_global\"]', '1643969374', 16, 1),
(19, 'Manager', 'Manages all work', '[]', '1703230264', 11, 0),
(20, 'Test Role', 'Test', '[\"crm_lead_view_global\",\"crm_lead_delete\",\"crm_customer_view_own\",\"crm_customer_update\",\"notify_create\"]', '1703230341', 0, 1),
(21, 'Sales Rep', 'sales representative', '[\"crm_lead_view_global\",\"crm_lead_create\",\"crm_lead_update\",\"crm_lead_delete\",\"crm_customer_view_own\",\"crm_customer_create\",\"crm_customer_update\",\"crm_customer_delete\"]', '1703834978', 15, 1),
(22, 'Sales Rep', 'sales representative', '[\"crm_lead_view_own\",\"crm_lead_create\",\"crm_lead_update\",\"crm_lead_delete\",\"crm_customer_view_own\",\"crm_customer_create\",\"crm_customer_update\",\"crm_customer_delete\"]', '1703835014', 21, 0),
(23, 'employee', 'tamil', '[\"crm_lead_view_global\",\"crm_customer_delete\"]', '1705754516', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `erp_settings`
--

CREATE TABLE `erp_settings` (
  `setting_id` int(11) NOT NULL,
  `s_name` varchar(255) NOT NULL,
  `s_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_settings`
--

INSERT INTO `erp_settings` (`setting_id`, `s_name`, `s_value`) VALUES
(1, 'company_logo', 'logo.png'),
(2, 'favicon', 'favicon.png'),
(3, 'company_name', 'Q Brainstorm Software'),
(4, 'address', 'No.164, First Floor, Arcot Rd, Valasaravakkam'),
(5, 'city', 'Chennai'),
(6, 'state', 'Tamil Nadu'),
(7, 'country', 'India'),
(8, 'zip', '600087'),
(9, 'phone', '9080780700'),
(10, 'gst', ''),
(11, 'mail_engine', 'CodeIgniter'),
(12, 'email_encryption', 'none'),
(13, 'smtp_host', 'smtp.gmail.com'),
(14, 'smtp_port', '587'),
(15, 'smtp_username', 'support@qbrainstorm.com'),
(16, 'smtp_password', 'Support4cus@Qbs'),
(17, 'bcc_list', ''),
(18, 'cc_list', ''),
(19, 'track_quota', '0'),
(20, 'close_account_book', '2024-01-26'),
(21, 'finance_capital', '10000.00'),
(22, 'finance_capital_vary', '0.00'),
(23, 'system_type', 'manufacturing');

-- --------------------------------------------------------

--
-- Table structure for table `erp_users`
--

CREATE TABLE `erp_users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `last_name` varchar(120) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `position` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `expired` tinyint(4) NOT NULL DEFAULT 0,
  `is_admin` tinyint(4) NOT NULL DEFAULT 0,
  `last_login` varchar(20) NOT NULL,
  `role_id` int(11) NOT NULL,
  `remember` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `erp_users`
--

INSERT INTO `erp_users` (`user_id`, `name`, `last_name`, `email`, `phone`, `position`, `password`, `active`, `expired`, `is_admin`, `last_login`, `role_id`, `remember`, `description`, `created_at`) VALUES
(1, 'Qbs ', 'Team', 'support@qbrainstorm.com', '9080780700', 'admin1', '$2y$10$JcJTUdh3pp9H7h317ZzfpegXKpbQowDyHcWauUV7d0uQiLVZrnjWm', 1, 0, 1, '1657538814', 19, 'fcc923a6de504c37932e619e44128a4e3aedc51b', 'no descriptions', '1643791190'),
(2, 'John', 'J', 'john@qbrainstorm.com', '1234567890', 'test', '$2y$10$rZ1Uu51LjTwSb1tIGJ4l7eWEMi83eAg6hQrJI2TS.bnNVqaWLAN.i', 1, 0, 1, '1646822983', 22, '', '0', '1643791190'),
(3, 'Jacob', 'K', 'jacob@qbrainstorm.com', '9080780700', 'Purchase Manager', '$2y$10$Sv15lDTaSUefO7JPYo4VQehQB6pD7lXTwZH3Q8SGPLeQVWFG4WyjW', 1, 0, 0, '1648889292', 11, '92bdd0f09edabdde89c2a3e5a5bdfc3b5e580245', '0', '1643791243');

-- --------------------------------------------------------

--
-- Table structure for table `estimates`
--

CREATE TABLE `estimates` (
  `estimate_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `estimate_date` date NOT NULL,
  `terms_condition` text NOT NULL,
  `shippingaddr_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `updated_at` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `estimates`
--

INSERT INTO `estimates` (`estimate_id`, `code`, `cust_id`, `estimate_date`, `terms_condition`, `shippingaddr_id`, `created_at`, `updated_at`, `created_by`) VALUES
(41, 'e-1', 46, '2024-01-22', 'afdsf', 0, '1698878592', '1705913189', 1),
(42, 'e-2', 46, '2024-01-22', 'fsf', 0, '1705913785', '1705913785', 1);

-- --------------------------------------------------------

--
-- Table structure for table `estimate_items`
--

CREATE TABLE `estimate_items` (
  `est_item_id` int(11) NOT NULL,
  `estimate_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `price_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(14,2) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `estimate_items`
--

INSERT INTO `estimate_items` (`est_item_id`, `estimate_id`, `related_to`, `related_id`, `price_id`, `quantity`, `unit_price`, `amount`, `tax1`, `tax2`) VALUES
(7, 32, 'finished_good', 22, 2, 1, 3000.00, 3000.00, 18, 9),
(8, 33, 'finished_good', 21, 1, 1, 2000.00, 2000.00, 9, 18),
(12, 36, 'finished_good', 25, 8, 1, 120.00, 120.00, 9, 18),
(14, 40, 'finished_good', 22, 2, 1, 3000.00, 3000.00, 18, 9),
(15, 41, 'finished_good', 25, 8, 1, 120.00, 120.00, 9, 18),
(16, 42, 'finished_good', 22, 2, 1, 3000.00, 3000.00, 18, 9);

-- --------------------------------------------------------

--
-- Table structure for table `finished_goods`
--

CREATE TABLE `finished_goods` (
  `finished_good_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `short_desc` varchar(1000) NOT NULL,
  `long_desc` text NOT NULL,
  `group_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `finished_goods`
--

INSERT INTO `finished_goods` (`finished_good_id`, `name`, `short_desc`, `long_desc`, `group_id`, `code`, `unit_id`, `brand_id`, `created_at`, `created_by`) VALUES
(21, 'test', 'rgawerh', 'wearghetdh', 13, 'dgedh465465', 2, 1, '1704177598', 1),
(22, 'a', 'adfgf', 'dfsgf', 13, 'SO128', 2, 1, '1704177621', 1),
(23, 'product1', 'fsda', 'agffsd', 14, 'dsfg4565', 2, 1, '1704863783', 1),
(24, 'oil', 'hyfty', 'ytf', 14, '23', 2, 2, '1704864633', 1),
(25, 'hairOil', 'test', 'test', 13, 'PD10', 2, 1, '1704865011', 1);

-- --------------------------------------------------------

--
-- Table structure for table `general_ledger`
--

CREATE TABLE `general_ledger` (
  `ledger_id` int(11) NOT NULL,
  `gl_acc_id` int(11) NOT NULL,
  `period` date NOT NULL,
  `actual_amt` decimal(16,2) NOT NULL,
  `balance_fwd` decimal(16,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `general_ledger`
--

INSERT INTO `general_ledger` (`ledger_id`, `gl_acc_id`, `period`, `actual_amt`, `balance_fwd`) VALUES
(1, 2, '2022-02-01', 0.00, 0.00),
(2, 2, '2022-01-01', 0.00, 0.00),
(9, 1, '2022-03-01', 4000.00, 4000.00),
(10, 2, '2022-03-01', -4000.00, -4000.00),
(17, 1, '2023-12-01', -10000.00, -10000.00),
(18, 15, '2023-12-01', 0.00, 15.00),
(21, 18, '2024-01-01', 0.00, 12254.00);

-- --------------------------------------------------------

--
-- Table structure for table `gl_accounts`
--

CREATE TABLE `gl_accounts` (
  `gl_acc_id` int(11) NOT NULL,
  `acc_group_id` int(11) NOT NULL,
  `account_code` smallint(6) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `cash_flow` tinyint(4) NOT NULL,
  `order_num` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gl_accounts`
--

INSERT INTO `gl_accounts` (`gl_acc_id`, `acc_group_id`, `account_code`, `account_name`, `cash_flow`, `order_num`, `created_at`, `created_by`) VALUES
(1, 3, 1010, 'petty cash', 4, 1, '1645248842', 1),
(2, 4, 1011, 'Advertise', 2, 1, '1645248923', 1),
(15, 8, 9999, 'test', 1, 3, '1703760391', 1),
(18, 4, 32767, '78767778', 2, 0, '1705750016', 1);

-- --------------------------------------------------------

--
-- Table structure for table `grn`
--

CREATE TABLE `grn` (
  `grn_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `delivered_on` varchar(20) NOT NULL,
  `updated_on` varchar(20) NOT NULL,
  `updated_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grn`
--

INSERT INTO `grn` (`grn_id`, `order_id`, `status`, `remarks`, `delivered_on`, `updated_on`, `updated_by`) VALUES
(1, 1, 1, '', '2023-12-28', '2023-12-12 08:52:55', 1),
(2, 2, 1, 'okay', '2023-12-15', '2023-12-27 10:33:28', 1),
(55846, 3, 1, 'rdyidrs', '2023-12-30', '2023-12-29 06:34:51', 1),
(55847, 9, 1, 'xdcfgxj', '2024-01-03', '2024-01-02 07:37:05', 1),
(55848, 1, 1, 'Test', '2024-01-09', '2024-01-09 05:46:51', 1),
(55849, 3, 1, 'test', '2024-01-14', '2024-01-12 10:47:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventory_requisition`
--

CREATE TABLE `inventory_requisition` (
  `invent_req_id` int(11) NOT NULL,
  `req_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_requisition`
--

INSERT INTO `inventory_requisition` (`invent_req_id`, `req_id`, `related_to`, `related_id`, `qty`) VALUES
(1, 1, 'raw_material', 43, 5),
(2, 1, 'raw_material', 53, 5),
(3, 2, 'raw_material', 53, 1),
(6, 5, 'raw_material', 47, 12),
(7, 6, 'semi_finished', 17, 12);

-- --------------------------------------------------------

--
-- Table structure for table `inventory_services`
--

CREATE TABLE `inventory_services` (
  `invent_service_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `short_desc` varchar(1000) NOT NULL,
  `long_desc` text NOT NULL,
  `group_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `price` decimal(14,2) NOT NULL,
  `tax1` int(11) NOT NULL,
  `tax2` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_services`
--

INSERT INTO `inventory_services` (`invent_service_id`, `name`, `short_desc`, `long_desc`, `group_id`, `code`, `price`, `tax1`, `tax2`, `created_at`, `created_by`) VALUES
(10, 'test', 'sdfharth', 'esrhryjhry', 19, 'SO128', 156532.00, 1, 1, '1704178086', 1),
(11, 'bottle', 'rexs', 'rse', 19, '12', 120.00, 1, 2, '1704864422', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventory_warehouse`
--

CREATE TABLE `inventory_warehouse` (
  `invent_house_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_warehouse`
--

INSERT INTO `inventory_warehouse` (`invent_house_id`, `warehouse_id`, `related_to`, `related_id`) VALUES
(41, 2, 'semi_finished', 42),
(42, 2, 'semi_finished', 7),
(43, 2, 'semi_finished', 8),
(46, 1, 'finished_good', 3),
(49, 2, 'finished_good', 4),
(50, 1, 'finished_good', 4),
(51, 2, 'finished_good', 5),
(52, 1, 'finished_good', 5),
(55, 0, 'raw_material', 18),
(56, 0, 'raw_material', 16),
(57, 0, 'raw_material', 25),
(58, 9, 'raw_material', 26),
(59, 8, 'raw_material', 26),
(60, 6, 'raw_material', 26),
(61, 9, 'raw_material', 27),
(62, 8, 'raw_material', 27),
(63, 6, 'raw_material', 27),
(64, 9, 'raw_material', 28),
(65, 8, 'raw_material', 28),
(66, 6, 'raw_material', 28),
(67, 9, 'raw_material', 29),
(68, 8, 'raw_material', 29),
(69, 6, 'raw_material', 29),
(70, 9, 'raw_material', 30),
(71, 8, 'raw_material', 30),
(72, 6, 'raw_material', 30),
(73, 9, 'raw_material', 31),
(74, 8, 'raw_material', 31),
(75, 6, 'raw_material', 31),
(76, 9, 'raw_material', 32),
(77, 8, 'raw_material', 32),
(78, 6, 'raw_material', 32),
(79, 9, 'raw_material', 33),
(80, 8, 'raw_material', 33),
(81, 6, 'raw_material', 33),
(82, 9, 'raw_material', 34),
(83, 8, 'raw_material', 34),
(84, 6, 'raw_material', 34),
(85, 9, 'raw_material', 35),
(86, 8, 'raw_material', 35),
(87, 6, 'raw_material', 35),
(88, 9, 'raw_material', 36),
(89, 8, 'raw_material', 36),
(90, 6, 'raw_material', 36),
(91, 9, 'raw_material', 37),
(92, 8, 'raw_material', 37),
(93, 6, 'raw_material', 37),
(94, 9, 'raw_material', 38),
(95, 8, 'raw_material', 38),
(96, 6, 'raw_material', 38),
(97, 9, 'raw_material', 39),
(98, 8, 'raw_material', 39),
(99, 6, 'raw_material', 39),
(100, 9, 'raw_material', 40),
(101, 8, 'raw_material', 40),
(102, 6, 'raw_material', 40),
(103, 9, 'raw_material', 41),
(104, 8, 'raw_material', 41),
(105, 6, 'raw_material', 41),
(112, 11, 'semi_finished', 9),
(118, 11, 'semi_finished', 10),
(119, 11, 'semi_finished', 11),
(120, 9, 'semi_finished', 11),
(121, 8, 'semi_finished', 11),
(122, 7, 'semi_finished', 11),
(123, 6, 'semi_finished', 11),
(124, 4, 'semi_finished', 11),
(125, 3, 'semi_finished', 11),
(126, 11, 'finished_good', 6),
(128, 11, 'finished_good', 7),
(135, 11, 'finished_good', 15),
(136, 9, 'finished_good', 15),
(137, 8, 'finished_good', 15),
(138, 6, 'finished_good', 15),
(139, 4, 'finished_good', 15),
(140, 0, 'raw_material', 2),
(141, 0, 'raw_material', 3),
(142, 0, 'raw_material', 17),
(143, 0, 'raw_material', 20),
(144, 0, 'raw_material', 21),
(145, 0, 'raw_material', 24),
(146, 0, 'raw_material', 42),
(147, 0, 'raw_material', 43),
(148, 9, 'raw_material', 44),
(149, 8, 'raw_material', 44),
(152, 0, 'raw_material', 45),
(154, 0, 'raw_material', 47),
(155, 0, 'raw_material', 46),
(157, 11, 'raw_material', 49),
(160, 0, 'raw_material', 48),
(161, 2, 'semi_finished', 2),
(162, 1, 'semi_finished', 2),
(163, 2, 'finished_good', 2),
(164, 13, 'finished_good', 16),
(165, 13, 'finished_good', 17),
(166, 13, 'finished_good', 18),
(167, 0, 'raw_material', 50),
(168, 13, 'semi_finished', 12),
(170, 6, 'semi_finished', 13),
(171, 1, 'semi_finished', 14),
(172, 2, 'semi_finished', 14),
(173, 8, 'semi_finished', 14),
(174, 0, 'raw_material', 51),
(175, 0, 'raw_material', 52),
(177, 0, 'raw_material', 53),
(178, 8, 'semi_finished', 15),
(179, 4, 'semi_finished', 16),
(180, 6, 'semi_finished', 17),
(181, 11, 'finished_good', 19),
(182, 8, 'finished_good', 20),
(183, 9, 'finished_good', 21),
(184, 2, 'finished_good', 22),
(185, 9, 'raw_material', 54),
(186, 9, 'raw_material', 55),
(188, 0, 'raw_material', 56),
(189, 9, 'raw_material', 57),
(191, 0, 'raw_material', 58),
(193, 0, 'raw_material', 59),
(197, 0, 'raw_material', 61),
(199, 0, 'raw_material', 62),
(202, 0, 'raw_material', 63),
(203, 13, 'raw_material', 64),
(204, 11, 'raw_material', 64),
(205, 9, 'raw_material', 64),
(206, 8, 'raw_material', 64),
(207, 6, 'raw_material', 64),
(208, 4, 'raw_material', 64),
(209, 2, 'raw_material', 64),
(210, 1, 'raw_material', 64),
(211, 4, 'raw_material', 65),
(212, 0, 'raw_material', 60),
(214, 0, 'raw_material', 66),
(215, 2, 'raw_material', 67),
(216, 4, 'semi_finished', 18),
(217, 11, 'finished_good', 23),
(218, 9, 'finished_good', 24),
(219, 11, 'finished_good', 25),
(221, 11, 'raw_material', 69),
(223, 0, 'raw_material', 70),
(224, 9, 'finished_good', 26),
(225, 0, 'raw_material', 68);

-- --------------------------------------------------------

--
-- Table structure for table `journal_entry`
--

CREATE TABLE `journal_entry` (
  `journal_id` int(11) NOT NULL,
  `gl_acc_id` int(11) NOT NULL,
  `credit` tinyint(1) NOT NULL,
  `debit` tinyint(1) NOT NULL,
  `narration` text NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `transaction_date` date NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `posted` tinyint(1) NOT NULL DEFAULT 0,
  `posted_date` varchar(20) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `prev_amount` decimal(14,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `journal_entry`
--

INSERT INTO `journal_entry` (`journal_id`, `gl_acc_id`, `credit`, `debit`, `narration`, `amount`, `transaction_date`, `type`, `posted`, `posted_date`, `created_at`, `created_by`, `related_to`, `related_id`, `prev_amount`) VALUES
(21, 1, 0, 1, '[ Finance Automation added Marketing Entry ]', 2000.00, '2022-03-02', 0, 1, '2022-03-02 18:05:11', '1646224511', 1, 'marketing', 1, 2000.00),
(22, 2, 1, 0, '[ Finance Automation added Marketing Entry ]', 2000.00, '2022-03-02', 0, 1, '2022-03-02 18:05:11', '1646224511', 1, 'marketing', 1, 2000.00),
(23, 1, 0, 1, '[ Finance Automation added Marketing Entry ]', 2000.00, '2022-03-02', 0, 1, '2022-03-02 18:08:51', '1646224731', 1, 'marketing', 1, 2000.00),
(24, 2, 1, 0, '[ Finance Automation added Marketing Entry ]', 2000.00, '2022-03-02', 0, 1, '2022-03-02 18:08:51', '1646224731', 1, 'marketing', 1, 2000.00),
(25, 1, 1, 0, '', 5000.00, '2023-12-24', 0, 1, '2023-12-23', '1703311285', 1, '', 0, 0.00),
(26, 1, 0, 1, '', 5000.00, '2023-12-24', 0, 1, '2023-12-23', '1703311285', 1, '', 0, 0.00),
(27, 1, 1, 0, '', 5000.00, '2023-12-24', 0, 1, '2024-01-09', '1703311401', 1, '', 0, 0.00),
(28, 1, 0, 1, '', 5000.00, '2023-12-24', 0, 0, '', '1703311401', 1, '', 0, 0.00),
(29, 1, 1, 0, '', 5000.00, '2023-12-24', 0, 0, '', '1703311809', 1, '', 0, 0.00),
(30, 1, 0, 1, '', 5000.00, '2023-12-24', 0, 0, '', '1703311809', 1, '', 0, 0.00),
(31, 1, 1, 0, '', 5000.00, '2023-12-24', 0, 1, '2023-12-26', '1703311839', 1, '', 0, 0.00),
(33, 1, 1, 0, 'edsgatz', 1000.00, '2023-12-28', 1, 0, '', '1703843930', 1, '', 0, 0.00),
(34, 2, 0, 1, 'sdzfvwgatf', 1000.00, '2023-12-28', 1, 0, '', '1703843930', 1, '', 0, 0.00),
(35, 2, 0, 1, '', 500.00, '2024-01-09', 0, 0, '', '1704802663', 1, '', 0, 0.00),
(36, 1, 0, 1, '', 500.00, '2024-01-09', 0, 0, '', '1704802663', 1, '', 0, 0.00),
(37, 1, 0, 1, '', 100.00, '2024-01-09', 0, 0, '', '1704802663', 1, '', 0, 0.00),
(38, 1, 1, 0, '', 1100.00, '2024-01-09', 0, 0, '', '1704802663', 1, '', 0, 0.00),
(39, 1, 1, 0, 'fhsfh', 100.00, '2024-01-19', 0, 0, '', '1705750247', 1, '', 0, 0.00),
(40, 2, 0, 1, 'vdhsdf', 100.00, '2024-01-19', 0, 0, '', '1705750247', 1, '', 0, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `lead_id` int(11) NOT NULL,
  `source_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `assigned_to` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `position` varchar(140) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `company` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `remarks` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`lead_id`, `source_id`, `status`, `assigned_to`, `name`, `position`, `address`, `city`, `state`, `country`, `zip`, `phone`, `email`, `website`, `company`, `description`, `remarks`, `created_at`, `created_by`) VALUES
(5, 1, 2, 2, 'john', 'Purchase Manager', 'No.164, First Floor, Arcot Rd, Valasaravakkam', 'Chennai', 'Tamil Nadu', 'India', '600087', '09080780700', 'support@example.com', 'www.qbrainstorm.com', 'john enterprise', 'gh', '', '', 1),
(8, 3, 0, 3, 'admin', 'test', 'test', 'test', 'test', 'test', 'test', 'test', '9876543210', 'support@gmail.com', 'test', 'test', '', '', 0),
(9, 2, 4, 2, 'shankar', 'manager', 'test', 'chennai', 'tamilnadu', 'india', '6000125', '9876543210', 'shankar@qqq.com', '', 'Shankar Company', '\r', '', '', 0),
(10, 1, 3, 3, 'Saran', 'Sales', 'test', 'chennai', 'tamilnadu', 'india', '6000125', '9876543210', 'saran@qqq.com', '', 'Shankar Company', 'test', '', '', 0),
(11, 1, 0, 3, 'Raj', 'Driver', 'test', 'chennai', 'tamilnadu', 'india', '6000125', '9876543210', 'raj@qqq.com', '', 'Shankar Company', 'demo', '', '', 0),
(15, 1, 1, 3, 'kumar', '63680954', 'No Position', '-', 'Dhrmapuri', 'TN', 'INDIA', '636809', '9874561230', '57665', '78', 'kumar@gmail.com', '', '1703061296', 1),
(19, 3, 1, 2, 'Thamizharasi', 'web developer', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', '01234567890', 'test@gmail.com', '', 'qbs', 'sdgagdsfgs', 'gfdsheshsdh', '1705746799', 1),
(20, 4, 0, 3, 'sgh', 'gfsgff', '35', 'chennai', 'tamilnadu', 'india', '600087', '8556654', 'tamil@gmail.com', '', 'qbs', 'cdbsdhsdh\r', '', '1705747957', 1),
(21, 2, 1, 2, 'name', 'devl', 'test', 'chennai', 'TN', 'india', '636809', '1234567890', 'pasupthi@gamil.com', 'www.test.com', 'test', 'tesst\r', '', '1705748139', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lead_source`
--

CREATE TABLE `lead_source` (
  `source_id` int(11) NOT NULL,
  `source_name` varchar(40) NOT NULL,
  `marketing_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lead_source`
--

INSERT INTO `lead_source` (`source_id`, `source_name`, `marketing_id`) VALUES
(1, 'Ads', 0),
(2, 'Google', 0),
(3, 'Facebook', 0),
(4, 'Email Marketing', 0),
(5, 'joyal', 1),
(6, 'Kemar', 2),
(7, 'gear ad', 3),
(32, 'QBS Support', 28),
(33, 'Kumar', 29),
(34, 'na oru don Thamizharasi', 30),
(35, 'Production Thamiz', 31);

-- --------------------------------------------------------

--
-- Table structure for table `marketing`
--

CREATE TABLE `marketing` (
  `marketing_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `done_by` varchar(140) NOT NULL,
  `company` varchar(140) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `email` varchar(255) NOT NULL,
  `phone1` varchar(13) NOT NULL,
  `phone2` varchar(13) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marketing`
--

INSERT INTO `marketing` (`marketing_id`, `name`, `related_to`, `related_id`, `amount`, `done_by`, `company`, `address`, `active`, `email`, `phone1`, `phone2`, `description`, `created_at`, `created_by`) VALUES
(2, 'Kemar', 'finished_good', 21, 3000.00, 'kevin', 'test company', '', 1, 'kumar@gmail.com', '09845612304', '8428054262', 'test', '1645790766', 1),
(3, 'gear ad', 'semi_finished', 1, 2000.00, 'joe', '', 'test', 0, '', '+919876543210', '', 'test', '1645792193', 1),
(29, 'Kumar', 'semi_finished', 1, 34.35, 'ghhth', 'qbrainstorm', 'Test Address\r\ntest address', 0, 'support@qbrainstorm.com', '09080780700', '09080780708', '4343434343', '1703078657', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master`
--

CREATE TABLE `master` (
  `master_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `master`
--

INSERT INTO `master` (`master_id`, `name`, `email`, `password`) VALUES
(1, 'Master', 'support@qbrainstorm.com', '$2y$10$FCznQZaoK.VRnpkl3YmbYu8gRm.z5fsRRPHZq.r3.0vnZAl6RVgt6');

-- --------------------------------------------------------

--
-- Table structure for table `mrp_bom`
--

CREATE TABLE `mrp_bom` (
  `bom_id` int(200) NOT NULL,
  `product_id` int(200) NOT NULL,
  `related_to` varchar(200) NOT NULL,
  `mrp_scheduling_id` int(255) NOT NULL,
  `warhouse_id` int(11) NOT NULL,
  `quantity` int(200) NOT NULL,
  `material_id` int(200) NOT NULL,
  `material_related_to` varchar(200) NOT NULL,
  `material_consumption` int(200) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mrp_dataset_forecast`
--

CREATE TABLE `mrp_dataset_forecast` (
  `id` int(200) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `related_to` varchar(200) NOT NULL,
  `related_id` int(200) NOT NULL,
  `quantity` int(200) NOT NULL,
  `current_stocks_on_inventory` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mrp_dataset_forecast`
--

INSERT INTO `mrp_dataset_forecast` (`id`, `timestamp`, `related_to`, `related_id`, `quantity`, `current_stocks_on_inventory`) VALUES
(1, '2023-01-18 11:31:37', 'finished_good', 22, 1, 1),
(2, '2023-11-20 04:15:30', 'finished_good', 21, 114, 88),
(3, '2023-06-21 14:56:41', 'finished_good', 21, 94, 97),
(4, '2023-08-30 00:23:36', 'finished_good', 22, 112, 110),
(5, '2023-12-23 23:14:30', 'finished_good', 22, 108, 109),
(6, '2023-06-28 08:07:40', 'finished_good', 23, 81, 84),
(7, '2023-12-17 19:51:53', 'finished_good', 23, 85, 97),
(8, '2023-01-16 22:11:53', 'finished_good', 24, 107, 112),
(9, '2023-02-20 07:35:36', 'finished_good', 24, 91, 72),
(10, '2023-01-10 12:22:04', 'finished_good', 25, 85, 79),
(11, '2023-04-04 08:42:28', 'finished_good', 25, 98, 85),
(12, '2023-04-09 18:05:19', 'finished_good', 21, 90, 85),
(13, '2023-11-18 07:27:45', 'finished_good', 21, 89, 100),
(14, '2023-12-26 02:14:30', 'finished_good', 22, 111, 111),
(15, '2023-07-28 01:27:45', 'finished_good', 22, 98, 82),
(16, '2023-11-05 21:42:05', 'finished_good', 23, 104, 96),
(17, '2023-11-10 05:46:29', 'finished_good', 23, 113, 81),
(18, '2023-07-06 10:51:12', 'finished_good', 24, 108, 81),
(19, '2023-10-26 15:37:19', 'finished_good', 24, 84, 108),
(20, '2023-12-24 07:41:45', 'finished_good', 25, 87, 99),
(21, '2023-08-31 01:02:31', 'finished_good', 25, 109, 93),
(22, '2023-03-03 17:33:17', 'finished_good', 21, 120, 88),
(23, '2023-07-06 19:58:05', 'finished_good', 21, 96, 82),
(24, '2023-11-02 03:48:48', 'finished_good', 22, 80, 108),
(25, '2023-05-18 13:49:24', 'finished_good', 22, 101, 120),
(26, '2023-05-04 07:20:35', 'finished_good', 23, 94, 78),
(27, '2023-05-16 16:29:05', 'finished_good', 23, 105, 96),
(28, '2023-04-10 04:39:32', 'finished_good', 24, 83, 98),
(29, '2023-08-01 17:41:37', 'finished_good', 24, 112, 104),
(30, '2023-01-12 07:06:14', 'finished_good', 25, 120, 116),
(31, '2023-09-12 05:48:40', 'finished_good', 25, 99, 118),
(32, '2023-05-07 17:00:34', 'finished_good', 21, 117, 103),
(33, '2023-07-21 22:00:38', 'finished_good', 21, 83, 99),
(34, '2023-08-06 05:18:27', 'finished_good', 22, 118, 106),
(35, '2023-01-19 16:44:14', 'finished_good', 22, 98, 83),
(36, '2023-08-12 04:29:52', 'finished_good', 23, 117, 106),
(37, '2023-06-26 09:55:19', 'finished_good', 23, 97, 91),
(38, '2023-02-25 21:33:51', 'finished_good', 24, 80, 99),
(39, '2023-11-27 04:35:23', 'finished_good', 24, 116, 118),
(40, '2023-01-09 03:47:44', 'finished_good', 25, 82, 87),
(41, '2023-07-04 15:52:53', 'finished_good', 25, 118, 110),
(42, '2023-08-23 00:54:01', 'finished_good', 21, 89, 98),
(43, '2023-11-01 05:31:20', 'finished_good', 21, 86, 101),
(44, '2023-09-23 19:30:50', 'finished_good', 22, 106, 101),
(45, '2023-04-21 02:27:00', 'finished_good', 22, 119, 93),
(46, '2023-02-11 15:26:15', 'finished_good', 23, 116, 79),
(47, '2023-09-21 11:59:11', 'finished_good', 23, 97, 89),
(48, '2023-06-17 02:21:57', 'finished_good', 24, 118, 78),
(49, '2023-02-21 13:11:00', 'finished_good', 24, 86, 114),
(50, '2023-07-06 10:05:14', 'finished_good', 25, 88, 117),
(51, '2023-03-26 10:02:29', 'finished_good', 25, 86, 103),
(52, '2024-01-23 07:57:44', 'finished_good', 21, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `mrp_scheduling`
--

CREATE TABLE `mrp_scheduling` (
  `mrp_scheduling_id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `price_id` int(11) NOT NULL,
  `bin_name` varchar(140) NOT NULL,
  `mfg_date` date NOT NULL,
  `batch_no` varchar(140) NOT NULL,
  `lot_no` varchar(140) NOT NULL,
  `stock` int(11) NOT NULL,
  `planning_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mrp_scheduling`
--

INSERT INTO `mrp_scheduling` (`mrp_scheduling_id`, `sku`, `related_to`, `related_id`, `warehouse_id`, `price_id`, `bin_name`, `mfg_date`, `batch_no`, `lot_no`, `stock`, `planning_id`) VALUES
(6, 'SKU62', 'finished_good', 23, 2, 1, 'BIN34', '2024-01-23', '45', '16', 6, 1),
(7, '#12345', 'finished_good', 23, 2, 1, 'A5', '2024-01-25', '10', '55', 6, 1),
(8, 'SKU63', 'finished_good', 23, 2, 1, 'BIN34', '2024-01-23', '45', '16', 6, 1),
(9, 'SKU65', 'finished_good', 23, 4, 2, 'BIN34', '2024-01-24', '45', '16', 6, 1),
(10, 'SKU66', 'finished_good', 23, 1, 1, 'BIN34', '2024-01-24', '45', '16', 100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notify_id` int(11) NOT NULL,
  `title` varchar(140) NOT NULL,
  `notify_text` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `notify_email` tinyint(1) NOT NULL DEFAULT 0,
  `notify_at` varchar(20) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `related_to` varchar(100) NOT NULL,
  `related_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notify_id`, `title`, `notify_text`, `status`, `user_id`, `notify_email`, `notify_at`, `created_at`, `updated_at`, `created_by`, `related_to`, `related_id`, `job_id`) VALUES
(5, 'Urgent  check', 'hello', 0, 3, 1, '1649420220', '1644919840', 0, 1, 'lead', 1, 32),
(7, 'Urgent  checking', 'hello world', 0, 2, 1, '1649316300', '1649316337', 0, 1, 'estimate', 3, 27),
(8, 'Urgent  check 2', 'hello', 0, 3, 1, '1649330160', '1649330176', 0, 1, 'estimate', 3, 28),
(9, 'Urgent  check 2', 'hello', 0, 3, 1, '1649330160', '1649330177', 0, 1, 'estimate', 3, 29),
(10, 'Urgent  check 3', 'hello', 0, 2, 1, '1649330160', '1649330205', 0, 1, 'estimate', 3, 30),
(11, 'Urgent  check', 'hello', 0, 3, 1, '1649396040', '1649396048', 0, 1, 'lead', 1, 31),
(12, 'Urgent  check', 'hello', 0, 2, 1, '1649398740', '1649398750', 0, 1, 'customer', 6, 34),
(15, 'Urgent  check', 'box', 0, 3, 1, '1651931400', '1649685029', 0, 1, 'sale_order', 1, 40),
(16, 'Urgent  checking', 'ckh', 0, 3, 1, '1650635580', '1649685224', 0, 1, 'sale_order', 8, 40),
(18, 'Urgent  check', 'g', 0, 2, 0, '1650015780', '1650015785', 0, 1, 'sale_invoice', 2, 43),
(19, 'test messgsae', 'credits', 0, 3, 1, '1651901160', '1650086767', 0, 1, 'credit_note', 2, 22),
(40, 'testmessage', 'hi', 0, 2, 1, '1703714040', '1703589613', 0, 1, 'credit_note', 2, 23),
(45, 'last message', 'sample message', 0, 3, 1, '1701724080', '1703594144', 0, 1, 'sale_invoice', 1, 28),
(46, 'sample', 'Test message', 0, 3, 1, '1703195460', '1703594776', 0, 1, 'sale_invoice', 1, 29),
(49, 'sample', 'dummy', 0, 2, 1, '1703782500', '1703748163', 0, 1, 'sale_order', 1, 41),
(52, 'testmessage', 'test', 0, 2, 1, '1703782740', '1703748511', 0, 1, 'sale_order', 1, 38),
(53, 'notify add', 'message', 0, 2, 1, '1703782920', '1703748546', 0, 1, 'sale_order', 1, 39),
(54, 'test', 'test', 0, 2, 1, '1703871840', '1703765657', 0, 1, 'quotation', 1, 42),
(56, 'sample', 'okay', 0, 3, 1, '1703891220', '1703766782', 0, 1, 'estimate', 4, 44),
(57, 'testmessage', 'message', 0, 2, 1, '1702501560', '1703766810', 0, 1, 'estimate', 4, 45),
(58, 'Urgent  check', 'box', 0, 2, 1, '1702328760', '1703766834', 0, 1, 'estimate', 4, 46),
(59, 'sample', 'test message..', 0, 2, 1, '1703891580', '1703767091', 0, 1, 'estimate', 22, 49),
(60, 'test', 'test message', 0, 2, 1, '1703200800', '1703767543', 0, 1, 'quotation', 1, 50),
(61, 'test', 'test message', 0, 2, 1, '1703719740', '1703768089', 0, 1, 'quotation', 1, 51),
(63, 'last message', 'sfjkgtsnj', 0, 2, 1, '1703547120', '1703768236', 0, 1, 'estimate', 22, 53),
(64, 'dsz', 'szdf', 0, 2, 1, '1703111520', '1703768269', 0, 1, 'estimate', 22, 54),
(65, 'test', 'sample', 0, 2, 1, '1703759940', '1703826602', 0, 1, 'lead', 1, 56),
(66, 'test', 'sample', 0, 2, 1, '1703846400', '1703826632', 0, 1, 'lead', 1, 57),
(68, 'test', 'wer', 0, 1, 1, '1703934480', '1703828345', 0, 1, 'lead', 11, 61),
(69, 'test', 'ewe', 0, 1, 1, '1703934600', '1703828445', 0, 1, 'customer', 41, 62),
(70, 'test', '234234', 0, 1, 1, '1704021360', '1703828779', 0, 1, 'lead', 1, 63),
(71, 'test estimate', 'test description', 0, 3, 1, '1703848800', '1703829014', 0, 1, 'estimate', 24, 65),
(73, 'Urgent  check', 'dffgdfg', 0, 1, 1, '1703935380', '1703829240', 0, 1, 'lead', 1, 67),
(74, 'Urgent  check', 'dftt', 0, 2, 1, '1703936160', '1703829970', 0, 1, 'lead', 1, 69),
(75, 'fg', 'fdgfd', 0, 3, 1, '1703849760', '1703830015', 0, 1, 'quotation', 1, 70),
(76, 'test estimate', 'sdf fsdfdss', 0, 2, 1, '1703849880', '1703830138', 0, 1, 'quotation', 2, 72),
(77, 'Urgent  check', 'ewrwer', 0, 2, 1, '1703997600', '1703830261', 0, 1, 'lead', 1, 73),
(80, 'last message for notify', 'sample message', 0, 3, 1, '1701724080', '1703831189', 0, 1, 'sale_invoice', 1, 77),
(81, 'test', 'hhj,.', 0, 1, 0, '1703851500', '1703831723', 0, 1, 'credit_note', 3, 80),
(89, 'test', '577', 0, 2, 1, '1703948040', '1703841871', 0, 1, 'lead', 1, 88),
(90, 'test', '34234', 0, 2, 1, '1703948460', '1703842295', 0, 1, 'lead', 1, 89),
(91, 'test', '345345', 0, 2, 1, '1703948460', '1703842309', 0, 1, 'lead', 1, 90),
(92, 'Urgent  check', 'ertert', 0, 2, 1, '1703948520', '1703842352', 0, 1, 'lead', 1, 91),
(93, 'test', '345', 0, 2, 1, '1703948580', '1703842425', 0, 1, 'lead', 1, 92),
(94, 'test', 'yui', 0, 2, 1, '1703948640', '1703842474', 0, 1, 'lead', 1, 93),
(95, 'Urgent  check', 'ert', 0, 2, 1, '1703950320', '1703844147', 0, 1, 'lead', 1, 94),
(96, 'jkhj', 'fdgh', 0, 1, 1, '1703869680', '1703849934', 0, 1, 'estimate', 24, 95),
(97, 'sample', 'gkhgbl', 0, 2, 1, '1704196260', '1704176469', 0, 1, 'lead', 1, 99),
(99, 'test23', 'sdvgesh', 0, 2, 1, '1704265140', '1704284940', 0, 1, 'sale_invoice', 39, 102),
(100, 'sample', 'hgvfgk', 0, 2, 1, '1704378240', '1704358492', 0, 1, 'sale_invoice', 44, 103),
(101, 'test', 'dsfhsdj', 0, 2, 1, '1704470760', '1704440047', 0, 1, 'lead', 17, 104),
(102, 'sample one', 'aserg', 0, 2, 1, '1704986580', '1704441169', 0, 1, 'lead', 2, 105),
(103, 'sample one', 'aserg', 0, 2, 1, '1704986580', '1704441404', 0, 1, 'lead', 2, 106),
(104, 'test', 'dshs', 0, 2, 1, '1704904380', '1704441637', 0, 1, 'lead', 2, 107),
(105, 'last message', 'fdshh', 0, 2, 1, '1705166940', '1704444987', 0, 1, 'lead', 3, 108),
(106, 'last message', 'cfdbf', 0, 2, 1, '1704477000', '1704449920', 0, 1, 'lead', 18, 109),
(107, 'Just Notify', '5345', 0, 1, 1, '1704550260', '1704530478', 0, 1, 'lead', 4, 113),
(111, 'test', 'hgdjdgh', 0, 2, 1, '1704847200', '1704867006', 0, 1, 'sale_order', 32, 116),
(112, 'test', 'hgdsgf', 0, 2, 1, '1704937380', '1704867035', 0, 1, 'sale_order', 32, 117),
(114, 'test', 'test', 0, 2, 1, '1705583460', '1704872473', 0, 1, 'estimate', 32, 119),
(115, 'test', 'sdagasdgg', 0, 2, 1, '1705573680', '1705553894', 0, 1, 'credit_note', 14, 122),
(118, 'samplefsd', 'sdfsdfgfsag', 0, 2, 1, '1706129040', '1705749022', 0, 1, 'sale_order', 31, 129),
(119, 'last message', 'dgshgh', 0, 2, 1, '1706028540', '1705994194', 0, 1, 'sale_invoice', 66, 130),
(120, 'last message', 'fghsh', 0, 2, 1, '1706119920', '1705999139', 0, 1, 'sale_invoice', 48, 131),
(121, 'sample one', 'gdhshg', 0, 2, 1, '1706206380', '1705999167', 0, 1, 'sale_invoice', 48, 132),
(122, 'te', 'test', 0, 3, 0, '1706205420', '1706099241', 0, 1, 'estimate', 41, 135),
(123, 'last message', 'dgfdhsgd', 0, 2, 1, '1706119440', '1706099646', 0, 1, 'estimate', 41, 134);

-- --------------------------------------------------------

--
-- Table structure for table `packs`
--

CREATE TABLE `packs` (
  `pack_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `capacity` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `packs`
--

INSERT INTO `packs` (`pack_id`, `name`, `capacity`, `related_to`, `related_id`, `height`, `width`, `description`, `created_at`, `created_by`) VALUES
(1, 'test', 25, 'finished_good', 4, 0, 0, 'good', '1647931364', 1),
(2, 'Pack1', 25, 'raw_material', 2, 0, 0, '', '1647931411', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pack_records`
--

CREATE TABLE `pack_records` (
  `pack_rec_id` int(11) NOT NULL,
  `pack_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `grn_id` int(11) NOT NULL,
  `mfg_date` varchar(20) NOT NULL,
  `batch_no` varchar(140) NOT NULL,
  `lot_no` varchar(140) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pack_unit`
--

CREATE TABLE `pack_unit` (
  `pack_unit_id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `bin_name` varchar(140) NOT NULL,
  `mfg_date` date NOT NULL,
  `batch_no` varchar(140) NOT NULL,
  `lot_no` varchar(140) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pack_unit`
--

INSERT INTO `pack_unit` (`pack_unit_id`, `sku`, `related_to`, `related_id`, `bin_name`, `mfg_date`, `batch_no`, `lot_no`) VALUES
(2, '54', 'raw_material', 2, '', '2022-02-04', '', ''),
(3, '4', 'raw_material', 2, '', '2022-02-01', '', ''),
(4, '4', 'raw_material', 2, '', '2022-02-06', '', '\r\n'),
(5, '5', 'raw_material', 2, '', '2022-02-07', '', '\r\n'),
(6, '6', 'raw_material', 2, '', '2022-02-08', '', '\r\n'),
(7, '7', 'raw_material', 2, '', '2022-02-09', '', '\r\n'),
(8, '8', 'raw_material', 2, '', '2022-02-10', '', '\r\n'),
(10, '13', 'raw_material', 16, '', '2022-02-15', '', '\r\n'),
(11, '14', 'raw_material', 16, '', '2022-02-16', '', '\r\n'),
(12, '15', 'raw_material', 16, '', '2022-02-17', '', '\r\n'),
(13, '16', 'raw_material', 16, '', '2022-02-18', '', '\r\n'),
(14, '17', 'raw_material', 16, '', '2022-02-19', '', '\r\n'),
(15, '18', 'raw_material', 16, '', '2022-02-20', '', '\r\n'),
(16, 'ABC12', 'finished_good', 4, '123', '2022-04-04', '', ''),
(17, 'ABC13', 'finished_good', 4, '', '2022-04-04', '', ''),
(18, 'ABC135', 'finished_good', 4, '1235', '2022-04-29', '', ''),
(21, '85', 'finished_good', 21, 'tamil', '2024-01-03', '10', '55'),
(22, '12', 'semi_finished', 17, '3', '2024-01-04', '2', '3'),
(23, '26', 'semi_finished', 17, '8', '2024-01-03', '2', '7'),
(24, '123', 'finished_good', 22, 'tt', '2024-01-19', 'tts', 'sf'),
(25, 'dsh868', 'finished_good', 25, '9', '2024-01-10', '2', '3'),
(26, 'TEST1234', 'finished_good', 21, 'B44', '2024-01-10', '5', '801'),
(27, '32', 'semi_finished', 18, 'e', '2024-01-13', 'fd', 'fsdf'),
(28, 'sk1', 'finished_good', 25, '23', '2024-01-26', '432', 'dsf'),
(29, '#12345', 'finished_good', 21, 'A5', '2024-01-28', '10', '12'),
(31, 'SKU56', 'raw_material', 50, 'BIN34', '2024-01-27', '45', '16'),
(32, 'SKU57', 'finished_good', 21, 'BIN34', '2024-01-20', '45', '16'),
(33, 'SKU58', 'semi_finished', 17, 'BIN34', '2024-01-20', '45', '16'),
(34, 'SKU59', 'raw_material', 50, 'BIN34', '2024-01-23', '45', '16'),
(35, 'SKU60', 'finished_good', 23, 'BIN34', '2024-01-22', '45', '16'),
(36, 'SKU61', 'raw_material', 47, 'BIN34', '2024-01-24', '45', '16');

-- --------------------------------------------------------

--
-- Table structure for table `payment_modes`
--

CREATE TABLE `payment_modes` (
  `payment_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_modes`
--

INSERT INTO `payment_modes` (`payment_id`, `name`, `description`, `active`, `created_at`, `created_by`) VALUES
(1, 'CASH', 'Money in raw form', 1, '1647351646', 1),
(2, 'Bank Transfer', 'test', 1, '1647351681', 1),
(3, 'RTGS', '', 1, '1647351724', 1),
(6, 'cheque', 'dghgjgdj', 0, '1703828966', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_additions`
--

CREATE TABLE `payroll_additions` (
  `pay_add_id` int(11) NOT NULL,
  `pay_entry_id` int(11) NOT NULL,
  `add_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payroll_additions`
--

INSERT INTO `payroll_additions` (`pay_add_id`, `pay_entry_id`, `add_id`) VALUES
(1, 2, 2),
(2, 3, 1),
(3, 2, 1),
(4, 8, 3),
(5, 8, 2),
(6, 9, 3),
(7, 9, 2),
(8, 10, 3),
(9, 11, 3),
(10, 12, 2),
(11, 13, 2);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_deductions`
--

CREATE TABLE `payroll_deductions` (
  `pay_deduct_id` int(11) NOT NULL,
  `pay_entry_id` int(11) NOT NULL,
  `deduct_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payroll_deductions`
--

INSERT INTO `payroll_deductions` (`pay_deduct_id`, `pay_entry_id`, `deduct_id`) VALUES
(1, 2, 2),
(3, 3, 2),
(6, 8, 2),
(7, 9, 2),
(8, 10, 3),
(9, 10, 2),
(10, 10, 1),
(11, 11, 2),
(12, 12, 3),
(13, 13, 3),
(14, 13, 2);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_entry`
--

CREATE TABLE `payroll_entry` (
  `pay_entry_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_from` date NOT NULL,
  `payment_to` date NOT NULL,
  `processed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payroll_entry`
--

INSERT INTO `payroll_entry` (`pay_entry_id`, `name`, `payment_date`, `payment_from`, `payment_to`, `processed`) VALUES
(2, 'Jan salary', '2022-04-28', '2022-01-01', '2022-01-31', 1),
(3, 'Feb salary', '2022-04-28', '2022-02-01', '2022-02-28', 1),
(8, 'QBS Support', '2023-12-21', '2023-12-22', '2023-12-31', 1),
(12, 'QBS Support', '2024-01-13', '2024-01-12', '2024-01-14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_process`
--

CREATE TABLE `payroll_process` (
  `pay_proc_id` int(11) NOT NULL,
  `pay_entry_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `total_w_hours` mediumint(9) NOT NULL,
  `total_ot_hours` mediumint(9) NOT NULL,
  `w_hr_salary` decimal(14,2) NOT NULL,
  `ot_hr_salary` decimal(14,2) NOT NULL,
  `gross_pay` decimal(14,2) NOT NULL,
  `total_deductions` decimal(14,2) NOT NULL,
  `total_additions` decimal(14,2) NOT NULL,
  `net_pay` decimal(14,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payroll_process`
--

INSERT INTO `payroll_process` (`pay_proc_id`, `pay_entry_id`, `employee_id`, `total_w_hours`, `total_ot_hours`, `w_hr_salary`, `ot_hr_salary`, `gross_pay`, `total_deductions`, `total_additions`, `net_pay`) VALUES
(1, 2, 1, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(2, 2, 2, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(3, 2, 3, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(4, 3, 1, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(5, 3, 2, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(6, 3, 3, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(7, 3, 4, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(8, 3, 5, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(9, 3, 8, 0, 0, 0.00, 0.00, 0.00, 1000.00, 2000.00, 1000.00),
(10, 8, 1, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(11, 8, 2, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(12, 8, 3, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(13, 8, 4, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(14, 8, 5, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(15, 8, 8, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(16, 11, 1, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(17, 11, 2, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(18, 11, 3, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(19, 11, 4, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(20, 11, 9, 0, 0, 0.00, 0.00, 0.00, 1000.00, 5.00, -995.00),
(21, 12, 13, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(22, 12, 14, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(23, 12, 15, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(24, 12, 16, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(25, 13, 13, 8, 2, 41680000.00, 110880.00, 41790880.00, 142963400.00, 4168000.00, -97004520.00),
(26, 13, 14, 0, 0, 0.00, 0.00, 0.00, 1000.00, 0.00, -1000.00),
(27, 13, 15, 0, 0, 0.00, 0.00, 0.00, 1000.00, 0.00, -1000.00),
(28, 13, 16, 0, 0, 0.00, 0.00, 0.00, 1000.00, 0.00, -1000.00);

-- --------------------------------------------------------

--
-- Table structure for table `planning`
--

CREATE TABLE `planning` (
  `planning_id` int(11) NOT NULL,
  `finished_good_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `finished_date` date NOT NULL,
  `stock` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `planning`
--

INSERT INTO `planning` (`planning_id`, `finished_good_id`, `start_date`, `end_date`, `finished_date`, `stock`, `status`, `created_by`) VALUES
(2, 23, '2024-01-27', '2024-01-27', '0000-00-00', 1, 1, 1),
(3, 24, '2024-01-20', '2024-01-24', '0000-00-00', 2, 1, 1),
(4, 23, '2024-01-22', '2024-01-23', '0000-00-00', 100, 0, 1),
(5, 21, '2024-01-23', '2024-01-31', '0000-00-00', 5, 0, 1),
(6, 23, '2024-01-25', '2024-01-31', '0000-00-00', 2, 0, 1),
(7, 23, '2024-01-24', '2024-01-31', '0000-00-00', 1, 0, 1),
(8, 25, '2024-01-24', '2024-01-31', '0000-00-00', 1, 0, 1),
(9, 21, '2024-01-24', '2024-02-01', '0000-00-00', 1, 0, 1),
(10, 23, '2024-01-24', '2024-01-25', '0000-00-00', 10, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `price_list`
--

CREATE TABLE `price_list` (
  `price_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `price_list`
--

INSERT INTO `price_list` (`price_id`, `name`, `amount`, `tax1`, `tax2`, `description`, `active`, `created_at`, `created_by`) VALUES
(1, 'Amount 1', 2000.00, 1, 3, '', 1, '1645602972', 1),
(2, 'Amount 2', 3000.00, 3, 1, '', 1, '1645603028', 1),
(6, 'amount 3', 8000.00, 1, 1, 'hi', 1, '1703658950', 1),
(8, 'Amount 4', 120.00, 1, 3, 'dsghsdh', 1, '1704864693', 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `project_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `budget` decimal(14,2) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `units` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `name`, `cust_id`, `related_to`, `related_id`, `start_date`, `end_date`, `budget`, `description`, `status`, `type`, `units`, `type_id`, `address`, `city`, `state`, `country`, `zipcode`, `created_at`, `created_by`) VALUES
(2, 'project 2', 0, 'finished_good', 4, '2022-04-20', '2022-04-30', 10000.00, 'hello world', 0, 1, 0, 0, '', '', '', '', '', '1650436903', 1),
(3, 'C Project 1', 8, '', 0, '2022-04-20', '2022-08-19', 40000000.00, 'hello ', 0, 0, 25, 1, 'No.164, First Floor, Arcot Rd, Valasaravakkam', 'Chennai', 'Tamil Nadu', 'India', '600087', '1650453923', 1),
(5, 'SevenSanjay', 6, '', 0, '2023-12-15', '2023-12-16', 1234343.78, 'project test', 0, 0, 54, 1, 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', '1702627269', 1),
(6, 'Seven', 8, '', 0, '2023-12-15', '2023-12-16', 1234343.78, 'test', 0, 0, 54, 1, 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', '1702627562', 1),
(7, 'kumar', 38, '', 0, '2023-12-21', '2023-12-29', 1234343.78, 'test company', 0, 0, 54, 1, 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', '1702629066', 1),
(13, '', 0, '', 0, '0000-00-00', '0000-00-00', 0.00, '', 1, 0, 0, 0, '', '', '', '', '', '', 0),
(14, '', 0, '', 0, '0000-00-00', '0000-00-00', 0.00, '', 1, 0, 0, 0, '', '', '', '', '', '', 0),
(15, '', 0, '', 0, '0000-00-00', '0000-00-00', 0.00, '', 1, 0, 0, 0, '', '', '', '', '', '', 0),
(16, '', 0, '', 0, '0000-00-00', '0000-00-00', 0.00, '', 1, 0, 0, 0, '', '', '', '', '', '', 0),
(17, '', 0, '', 0, '0000-00-00', '0000-00-00', 0.00, '', 4, 0, 0, 0, '', '', '', '', '', '', 0),
(18, '', 0, '', 0, '0000-00-00', '0000-00-00', 0.00, '', 3, 0, 0, 0, '', '', '', '', '', '', 0),
(23, 'TEst', 37, 'finished_good', 21, '2024-01-18', '2024-02-10', 10000.00, 'asdf', 0, 1, 0, 0, '', '', '', '', '', '1705490992', 1),
(24, 'Thamizharasi', 45, 'finished_good', 21, '2024-01-18', '2024-01-19', 11221401.00, 'eafgeghef', 0, 1, 0, 0, '', '', '', '', '', '1705752813', 1),
(25, 'Production ', 45, 'finished_good', 21, '2024-01-23', '2024-01-30', 11221401.00, 'sdgdfhdddgfsfdahgm', 0, 1, 0, 0, '', '', '', '', '', '1705916085', 1);

-- --------------------------------------------------------

--
-- Table structure for table `project_amenity`
--

CREATE TABLE `project_amenity` (
  `project_amen_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `amenity_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_amenity`
--

INSERT INTO `project_amenity` (`project_amen_id`, `project_id`, `amenity_id`) VALUES
(1, 3, 3),
(2, 3, 2),
(3, 3, 1),
(4, 5, 3),
(5, 6, 2),
(6, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `project_expense`
--

CREATE TABLE `project_expense` (
  `expense_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `expense_date` date NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `receipt` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_expense`
--

INSERT INTO `project_expense` (`expense_id`, `project_id`, `name`, `expense_date`, `amount`, `payment_id`, `receipt`, `description`) VALUES
(3, 3, 'test', '2022-05-03', 2000.00, 1, '', ''),
(4, 3, 'kumar', '2023-12-16', 34.35, 1, 'export(1)_4.xlsx', 'test'),
(5, 3, 'kumar', '2023-12-16', 34.35, 1, 'export(1)_5.xlsx', 'test'),
(6, 3, 'kumar', '2023-12-16', 34.35, 1, 'export(1)_6.xlsx', 'test'),
(14, 24, 'Thamizharasi', '2024-01-19', 8000.00, 2, 'export(49)_7.csv', 'eshtg');

-- --------------------------------------------------------

--
-- Table structure for table `project_members`
--

CREATE TABLE `project_members` (
  `project_mem_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_members`
--

INSERT INTO `project_members` (`project_mem_id`, `project_id`, `member_id`) VALUES
(1, 1, 3),
(2, 1, 2),
(3, 1, 1),
(4, 2, 3),
(5, 2, 2),
(6, 2, 1),
(7, 3, 3),
(8, 3, 2),
(9, 3, 1),
(10, 5, 2),
(11, 6, 2),
(12, 7, 1),
(13, 8, 2),
(14, 9, 3),
(15, 9, 2),
(16, 9, 1),
(17, 10, 3),
(18, 10, 2),
(19, 10, 1),
(20, 11, 1),
(21, 12, 2),
(22, 19, 2),
(23, 20, 3),
(24, 21, 2),
(25, 22, 3),
(26, 23, 1),
(27, 24, 2),
(28, 25, 2);

-- --------------------------------------------------------

--
-- Table structure for table `project_phase`
--

CREATE TABLE `project_phase` (
  `phase_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `started` tinyint(4) NOT NULL DEFAULT 0,
  `project_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_phase`
--

INSERT INTO `project_phase` (`phase_id`, `name`, `started`, `project_id`) VALUES
(3, 'Phase1', 1, 3),
(15, 'test', 1, 2),
(16, 'Domain', 1, 2),
(17, 'QBS Support', 1, 2),
(18, 'test', 1, 2),
(22, 'test', 1, 24);

-- --------------------------------------------------------

--
-- Table structure for table `project_rawmaterials`
--

CREATE TABLE `project_rawmaterials` (
  `project_raw_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `req_qty` int(11) NOT NULL,
  `req_for_dispatch` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_rawmaterials`
--

INSERT INTO `project_rawmaterials` (`project_raw_id`, `related_to`, `related_id`, `project_id`, `req_qty`, `req_for_dispatch`) VALUES
(6, 'raw_material', 2, 3, 5, 0),
(7, 'raw_material', 16, 3, 20, 0),
(17, 'raw_material', 47, 2, 2, 0),
(18, 'raw_material', 21, 2, 20, 0),
(19, 'raw_material', 3, 2, 78, 0);

-- --------------------------------------------------------

--
-- Table structure for table `project_testing`
--

CREATE TABLE `project_testing` (
  `project_test_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `complete_before` date NOT NULL,
  `result` tinyint(1) NOT NULL DEFAULT 0,
  `completed_at` date NOT NULL,
  `description` text NOT NULL,
  `remarks` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_workgroup`
--

CREATE TABLE `project_workgroup` (
  `project_wgrp_id` int(11) NOT NULL,
  `phase_id` int(11) NOT NULL,
  `wgroup_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `started_at` varchar(40) NOT NULL,
  `completed_at` varchar(40) NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `fetched` tinyint(1) NOT NULL DEFAULT 0,
  `worker_type` varchar(60) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_till` decimal(14,2) NOT NULL,
  `pay_before` varchar(10) NOT NULL,
  `c_status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_workgroup`
--

INSERT INTO `project_workgroup` (`project_wgrp_id`, `phase_id`, `wgroup_id`, `team_id`, `project_id`, `started_at`, `completed_at`, `completed`, `fetched`, `worker_type`, `contractor_id`, `amount`, `paid_till`, `pay_before`, `c_status`) VALUES
(1, 1, 1, 1, 1, '2022-05-02', '2022-05-03', 1, 1, '', 0, 0.00, 0.00, '', 0),
(2, 1, 2, 2, 1, '2022-05-03', '2023-12-27', 1, 1, '', 0, 0.00, 0.00, '', 0),
(3, 1, 3, 2, 1, '2023-12-27', '2023-12-27', 1, 0, '', 0, 0.00, 0.00, '', 0),
(4, 2, 1, 1, 1, '2022-05-02', '2023-12-27', 1, 1, '', 0, 0.00, 0.00, '', 0),
(7, 3, 1, 0, 3, '2022-05-04', '2022-05-04', 1, 1, 'Contractor', 3, 30000.00, 3000.00, '2022-06-11', 1),
(12, 6, 1, 1, 8, '2023-12-16', '2023-12-16', 1, 0, 'Team', 0, 0.00, 0.00, '', 0),
(13, 7, 2, 2, 9, '', '', 0, 0, 'Team', 0, 0.00, 0.00, '', 0),
(14, 7, 10, 2, 9, '', '', 0, 0, 'Team', 0, 0.00, 0.00, '', 0),
(15, 9, 2, 2, 10, '', '', 0, 0, 'Team', 0, 0.00, 0.00, '', 0),
(16, 10, 1, 1, 11, '2023-12-26', '2023-12-26', 1, 1, 'Team', 0, 0.00, 0.00, '', 0),
(17, 11, 1, 1, 11, '2023-12-26', '', 0, 1, 'Team', 0, 0.00, 0.00, '', 0),
(18, 12, 1, 1, 12, '', '', 0, 0, 'Team', 0, 0.00, 0.00, '', 0),
(20, 16, 3, 15, 2, '2024-01-02', '', 0, 1, 'Team', 0, 0.00, 0.00, '', 0),
(21, 17, 3, 15, 2, '2024-01-02', '', 0, 1, 'Team', 0, 0.00, 0.00, '', 0),
(22, 18, 10, 15, 2, '2024-01-02', '', 0, 1, 'Team', 0, 0.00, 0.00, '', 0),
(24, 19, 2, 15, 22, '2024-01-11', '2024-01-11', 1, 1, 'Team', 0, 0.00, 0.00, '', 0),
(25, 20, 2, 15, 22, '2024-01-11', '2024-01-11', 1, 1, 'Team', 0, 0.00, 0.00, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `property_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `units` smallint(6) NOT NULL,
  `type_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `construct_start` varchar(20) NOT NULL,
  `construct_end` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`property_id`, `name`, `units`, `type_id`, `address`, `city`, `state`, `country`, `zipcode`, `construct_start`, `construct_end`, `status`, `description`, `created_at`, `created_by`) VALUES
(4, 'Rainbow', 1, 2, 'No.164, First Floor, Arcot Rd, Valasaravakkam', 'Chennai', 'Tamil Nadu', 'India', '600087', '', '', 1, '', '1648643990', 1),
(7, 'QBS Support', 0, 1, 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', '2023-12-13', '2023-12-30', 1, '', '1702386459', 1);

-- --------------------------------------------------------

--
-- Table structure for table `propertytype`
--

CREATE TABLE `propertytype` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(140) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `propertytype`
--

INSERT INTO `propertytype` (`type_id`, `type_name`, `created_at`, `created_by`) VALUES
(1, 'Flat', '1648623239', 1),
(2, 'Villa', '1648623248', 1),
(6, 'shop', '1705904222', 1);

-- --------------------------------------------------------

--
-- Table structure for table `property_amenity`
--

CREATE TABLE `property_amenity` (
  `prop_ament_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `amenity_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_amenity`
--

INSERT INTO `property_amenity` (`prop_ament_id`, `property_id`, `amenity_id`) VALUES
(4, 4, 3),
(5, 4, 2),
(6, 4, 1),
(7, 3, 3),
(8, 3, 2),
(9, 3, 1),
(10, 7, 3),
(11, 8, 1),
(12, 9, 3),
(13, 10, 2),
(14, 11, 2),
(15, 12, 2),
(16, 13, 2);

-- --------------------------------------------------------

--
-- Table structure for table `property_unit`
--

CREATE TABLE `property_unit` (
  `prop_unit_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `unit_name` varchar(140) NOT NULL,
  `floor_no` varchar(80) NOT NULL,
  `area_sqft` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `price` decimal(14,2) NOT NULL,
  `tax1` int(11) NOT NULL,
  `tax2` int(11) NOT NULL,
  `direction` varchar(140) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_unit`
--

INSERT INTO `property_unit` (`prop_unit_id`, `property_id`, `unit_name`, `floor_no`, `area_sqft`, `status`, `price`, `tax1`, `tax2`, `direction`, `description`) VALUES
(1, 1, 'FLAT123454545', '1', '2500', 1, 3200000.00, 1, 2, '', ''),
(2, 2, 'FLAT124234234234234234234234', '2', '2500', 1, 3000000.00, 3, 0, '', ''),
(3, 4, 'FLAT125', '1', '2500', 1, 4500000.00, 1, 2, 'South', 'hello'),
(4, 4, 'QBS Support', '76', '454', 0, 12.23, 1, 2, 'h', ''),
(5, 5, 'siva', '76', '454', 0, 12.23, 1, 2, 'h', ''),
(6, 4, 'Sevensanja', '12', '212122', 0, 545.55, 3, 2, '87', ''),
(7, 7, 'sevens', '76', '2121.22', 0, 545.55, 1, 1, 'h', '');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_invoice`
--

CREATE TABLE `purchase_invoice` (
  `invoice_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `amount` decimal(14,2) NOT NULL,
  `paid_till` decimal(14,2) NOT NULL,
  `grn_updated` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_invoice`
--

INSERT INTO `purchase_invoice` (`invoice_id`, `order_id`, `status`, `amount`, `paid_till`, `grn_updated`) VALUES
(1, 1, 3, 20000.00, 20000.00, 0),
(2, 2, 0, 24000.00, 0.00, 0),
(3, 3, 0, 96000.00, 0.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE `purchase_order` (
  `order_id` int(11) NOT NULL,
  `order_code` varchar(140) NOT NULL,
  `req_id` int(11) NOT NULL,
  `selection_rule` varchar(140) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `internal_transport` tinyint(1) NOT NULL DEFAULT 0,
  `transport_id` int(11) NOT NULL,
  `transport_unit` int(11) NOT NULL,
  `transport_charge` decimal(14,2) NOT NULL,
  `rfq_id` int(11) NOT NULL,
  `supp_location_id` int(11) NOT NULL,
  `delivery_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `warehouse_id` int(11) NOT NULL,
  `terms_condition` text NOT NULL,
  `notes` text NOT NULL,
  `grn_created` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_created` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`order_id`, `order_code`, `req_id`, `selection_rule`, `supplier_id`, `internal_transport`, `transport_id`, `transport_unit`, `transport_charge`, `rfq_id`, `supp_location_id`, `delivery_date`, `status`, `warehouse_id`, `terms_condition`, `notes`, `grn_created`, `invoice_created`, `created_at`, `created_by`) VALUES
(1, 'RFQ_ORDER - 1', 1, '3', 4, 0, 0, 0, 0.00, 0, 5, '2024-01-09', 2, 1, 'Test', 'Test', 1, 1, '1704777683', 1),
(2, 'QWE14', 5, '3', 4, 0, 0, 0, 0.00, 0, 5, '2024-01-12', 2, 1, 'test', 'test', 0, 1, '1705053527', 1),
(3, 'CO01', 6, '3', 4, 0, 0, 0, 0.00, 0, 5, '2024-01-13', 2, 1, 'test', 'test', 1, 1, '1705056235', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_items`
--

CREATE TABLE `purchase_order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `price_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `received_qty` int(11) NOT NULL,
  `returned_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_order_items`
--

INSERT INTO `purchase_order_items` (`order_item_id`, `order_id`, `related_to`, `related_id`, `price_id`, `quantity`, `received_qty`, `returned_qty`) VALUES
(1, 1, 'raw_material', 43, 1, 5, 4, 1),
(2, 1, 'raw_material', 53, 1, 5, 4, 1),
(3, 2, 'raw_material', 47, 1, 12, 0, 0),
(4, 3, 'semi_finished', 17, 6, 12, 1, 11);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_payments`
--

CREATE TABLE `purchase_payments` (
  `purchase_pay_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_on` date NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_payments`
--

INSERT INTO `purchase_payments` (`purchase_pay_id`, `invoice_id`, `payment_id`, `amount`, `paid_on`, `transaction_id`, `notes`) VALUES
(4, 1, 1, 20000.00, '2022-03-18', '', 'Advance payment'),
(5, 1, 1, 2000.00, '2022-03-17', '', 'first off'),
(6, 2, 1, 1000.00, '2023-12-27', 'RFT-1234', 'nothing'),
(7, 2, 2, 100000.00, '2023-12-29', '6538796879', '987'),
(8, 3, 1, 1000.00, '2024-01-02', 'TEST TEST', 'Nothing'),
(9, 1, 1, 20000.00, '2024-01-13', '1234567890', 'fdgsagsdr3e r');

-- --------------------------------------------------------

--
-- Table structure for table `push_notify`
--

CREATE TABLE `push_notify` (
  `push_id` int(11) NOT NULL,
  `notify_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `fetched` tinyint(1) NOT NULL DEFAULT 0,
  `pushed_at` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `push_notify`
--

INSERT INTO `push_notify` (`push_id`, `notify_id`, `to_id`, `fetched`, `pushed_at`) VALUES
(1, 5, 1, 0, '12');

-- --------------------------------------------------------

--
-- Table structure for table `quotations`
--

CREATE TABLE `quotations` (
  `quote_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `quote_date` date NOT NULL,
  `cust_id` int(11) NOT NULL,
  `shippingaddr_id` int(11) NOT NULL,
  `transport_req` tinyint(1) NOT NULL DEFAULT 0,
  `trans_charge` decimal(14,2) NOT NULL,
  `discount` decimal(14,2) NOT NULL,
  `terms_condition` text NOT NULL,
  `payment_terms` varchar(140) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quotations`
--

INSERT INTO `quotations` (`quote_id`, `code`, `quote_date`, `cust_id`, `shippingaddr_id`, `transport_req`, `trans_charge`, `discount`, `terms_condition`, `payment_terms`, `status`, `created_at`, `created_by`) VALUES
(5, 'USAP256', '2024-01-11', 47, 14, 1, 20.00, 0.00, 'erqfdvd', 'test', 4, '1704968423', 1),
(6, 'USAP2567', '2024-01-11', 45, 13, 0, 20.00, 0.00, 'dfsfgdsfg', 'test', 3, '1704969175', 1),
(7, 'USAP25678', '2024-01-11', 45, 13, 0, 20.00, 0.00, 'dfgdfs345', 'test', 4, '1704969839', 1),
(8, 'XYZ04', '2024-01-11', 6, 3, 1, 20.00, 0.00, 'sdfsdf', 'dsfsdf', 4, '1704971975', 1),
(10, 'qu-2', '2024-01-17', 46, 0, 0, 0.00, 0.00, 'test', '1 day', 0, '1705493290', 1);

-- --------------------------------------------------------

--
-- Table structure for table `raw_materials`
--

CREATE TABLE `raw_materials` (
  `raw_material_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `short_desc` varchar(1000) NOT NULL,
  `long_desc` text NOT NULL,
  `group_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `raw_materials`
--

INSERT INTO `raw_materials` (`raw_material_id`, `name`, `short_desc`, `long_desc`, `group_id`, `code`, `unit_id`, `brand_id`, `created_at`, `created_by`) VALUES
(42, 'Pens', 'test', 'test34', 9, '78768768', 1, 2, '1702365934', 1),
(43, 'Grape', 'no', 'no\r\n', 10, '2345', 1, 1, '1702365979', 1),
(45, 'Raj', 'sdfsdf', 'dfgsdfg', 9, '1517', 2, 2, '1703418703', 1),
(47, 'test2', 'wsera', 'rhyseht', 9, 'c58554', 2, 2, '1703829990', 1),
(50, 'IGST', '', '', 9, '15', 2, 5, '1703830282', 1),
(53, 'vegetabl', 'fsf', 'fsdf', 9, 'JHJ', 1, 2, '1703852159', 1),
(56, 'test123', 'wearghedth', 'esraghedth', 9, 'b650745', 1, 1, '1704178435', 1),
(58, 'Thamizh', 'swgreg', 'wegfdg', 10, 'cfseh', 1, 2, '1704189142', 1),
(60, 'dhssdfzkhc', 'dhtaezt', 'erheazd', 9, 'dfxhjn6', 1, 1, '1704191459', 1),
(66, 'TEST EMAIL', 'esgrseg', 'aer', 9, 'SO128', 1, 1, '1704800020', 1),
(68, 'test', 'sfgag', 'asdgasg', 9, 'SO128dfs', 2, 1, '1705664411', 1),
(70, 'fdhseh', 'xfgsjg', 'fgjsjsrfgjsg\r\n', 10, '876', 2, 2, '1705750892', 1);

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `request_id` int(11) NOT NULL,
  `from_m` varchar(140) NOT NULL,
  `to_m` varchar(140) NOT NULL,
  `purpose` varchar(140) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `mail_request` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `requested_at` varchar(20) NOT NULL,
  `requested_by` int(11) NOT NULL,
  `responded_by` int(11) NOT NULL,
  `responded_at` varchar(20) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `updated_at` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`request_id`, `from_m`, `to_m`, `purpose`, `related_to`, `related_id`, `description`, `mail_request`, `status`, `requested_at`, `requested_by`, `responded_by`, `responded_at`, `created_at`, `updated_at`) VALUES
(1, 'CRM', 'Sales', 'Order Request', 'customer', 9, 'Want audi car', 1, 0, '1645877705', 1, 0, '1646477095', '', ''),
(2, 'CRM', 'Sales', 'Order Request', 'customer', 8, 'Test', 0, 0, '1646023067', 1, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `requisition`
--

CREATE TABLE `requisition` (
  `req_id` int(11) NOT NULL,
  `req_code` varchar(140) NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `priority` tinyint(1) NOT NULL,
  `mail_sent` tinyint(1) NOT NULL DEFAULT 0,
  `description` text NOT NULL,
  `remarks` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requisition`
--

INSERT INTO `requisition` (`req_id`, `req_code`, `assigned_to`, `status`, `priority`, `mail_sent`, `description`, `remarks`, `created_at`, `created_by`) VALUES
(1, 'REQ -1', 1, 2, 1, 0, 'Raw materials', 'arrpoved', '1704777210', 1),
(2, 'USAP1234', 2, 0, 3, 1, 'test', '', '1704970233', 1),
(5, 'USAP12345', 1, 2, 2, 0, 'dfsdfgfg', 'ttt', '1705053250', 1),
(6, 'CR01', 1, 2, 2, 0, 'test', 'test', '1705054691', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rfq`
--

CREATE TABLE `rfq` (
  `rfq_id` int(11) NOT NULL,
  `rfq_code` varchar(140) NOT NULL,
  `req_id` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  `terms_condition` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rfq`
--

INSERT INTO `rfq` (`rfq_id`, `rfq_code`, `req_id`, `expiry_date`, `terms_condition`, `created_at`, `created_by`, `status`) VALUES
(2, 'RFQ1436', 6, '2024-01-26', 'dsagseg', '1705752467', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sale_invoice`
--

CREATE TABLE `sale_invoice` (
  `invoice_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `invoice_date` date NOT NULL,
  `invoice_expiry` date NOT NULL,
  `cust_id` int(11) NOT NULL,
  `shippingaddr_id` int(11) NOT NULL,
  `transport_req` tinyint(1) NOT NULL DEFAULT 0,
  `trans_charge` decimal(14,2) NOT NULL,
  `discount` decimal(14,2) NOT NULL,
  `terms_condition` text NOT NULL,
  `payment_terms` varchar(140) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `paid_till` decimal(14,2) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `can_edit` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_invoice`
--

INSERT INTO `sale_invoice` (`invoice_id`, `code`, `invoice_date`, `invoice_expiry`, `cust_id`, `shippingaddr_id`, `transport_req`, `trans_charge`, `discount`, `terms_condition`, `payment_terms`, `status`, `remarks`, `paid_till`, `type`, `can_edit`, `created_at`, `created_by`) VALUES
(48, 'INV123', '2024-01-05', '2024-01-18', 45, 0, 1, 50.50, 0.00, 'ufds', 'fd', 3, '', 0.00, 1, 1, '1704448527', 1),
(54, 'QWE03', '2024-01-12', '2024-01-13', 45, 13, 0, 0.00, 0.00, 'fdsadf', 'fdsgfdg', 1, '', 1010.00, 1, 0, '1705050943', 1),
(56, 'INV6', '2024-01-13', '2024-01-25', 37, 0, 1, 10.00, 0.00, 'test', '1 day', 0, '', 0.00, 1, 1, '1705130846', 1),
(57, 'cvnfxdn5465445', '2024-01-17', '2024-01-17', 45, 13, 0, 0.00, 0.00, 'dghsth', '20 days', 1, '', 100.00, 1, 0, '1705472242', 1),
(60, 'rfmkdh5566', '2024-01-18', '2024-01-18', 45, 13, 0, 0.00, 0.00, 'sadgsag', 'google pay', 2, '', 0.00, 1, 1, '1674021056', 1),
(65, 'SO128545', '2024-01-20', '2024-01-26', 45, 13, 0, 0.00, 0.00, 'tyuilhof', 'cheque', 2, '', 120.00, 1, 0, '1705749196', 1),
(66, 'b65015', '2024-01-23', '2024-01-24', 45, 13, 1, 500.00, 0.00, 'cdsgedfh', 'phone pay', 1, '', 0.00, 1, 1, '1705993961', 1),
(69, 'que123', '2024-01-23', '2024-01-24', 45, 13, 0, 0.00, 0.00, 'efgesafg', 'phone pay', 1, '', 0.00, 1, 1, '1705996340', 1),
(70, 'GT1234c', '2024-01-24', '2024-01-25', 45, 13, 0, 0.00, 0.00, 'b xcvgndx', 'google pay', 1, '', 0.00, 1, 1, '1706071823', 1),
(71, 'inv10', '2024-01-24', '2024-01-25', 45, 13, 0, 0.00, 0.00, 'test', '3 day', 1, '', 650.00, 1, 0, '1706096125', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sale_order`
--

CREATE TABLE `sale_order` (
  `order_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `order_date` date NOT NULL,
  `order_expiry` date NOT NULL,
  `cust_id` int(11) NOT NULL,
  `shippingaddr_id` int(11) NOT NULL,
  `transport_req` tinyint(1) NOT NULL DEFAULT 0,
  `trans_charge` decimal(14,2) NOT NULL,
  `discount` decimal(14,2) NOT NULL,
  `terms_condition` text NOT NULL,
  `payment_terms` varchar(140) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `can_edit` tinyint(1) NOT NULL DEFAULT 1,
  `stock_pick` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_order`
--

INSERT INTO `sale_order` (`order_id`, `code`, `order_date`, `order_expiry`, `cust_id`, `shippingaddr_id`, `transport_req`, `trans_charge`, `discount`, `terms_condition`, `payment_terms`, `status`, `remarks`, `type`, `can_edit`, `stock_pick`, `created_at`, `created_by`) VALUES
(2, 'SO124', '2022-04-08', '2022-05-07', 9, 0, 0, 0.00, 1000.00, 'hello', '30 days', 0, '', 1, 0, 0, '1649480965', 1),
(8, 'SO126', '2022-04-11', '2022-05-07', 9, 0, 0, 0.00, 100000.00, 'hello', '30 days', 1, '', 0, 0, 0, '1649663959', 1),
(30, 'werewr', '2024-01-04', '2024-01-11', 41, 11, 0, 60.00, 0.00, '234234234dfgfdg', '234234', 0, '', 1, 1, 0, '1704375898', 1),
(31, 'ghdrfg5868796', '2024-01-05', '2024-01-06', 47, 14, 1, 20.00, 0.00, 'dsgws', '20 days', 1, '', 1, 1, 0, '1704454895', 1),
(32, 'fghdf4565', '2024-01-10', '2024-01-18', 45, 13, 0, 0.00, 0.00, 'sfghr', '555', 0, '', 1, 1, 0, '1704866917', 1),
(34, 'USAP234', '2024-01-11', '2024-01-12', 47, 14, 0, 0.00, 0.00, 'test', 'test', 0, '', 1, 0, 0, '1704964761', 1),
(35, 'USAP234', '2024-01-11', '2024-01-12', 47, 14, 0, 0.00, 0.00, 'test', 'test', 0, '', 1, 0, 0, '1704964795', 1),
(36, 'USAP234', '2024-01-11', '2024-01-12', 47, 14, 0, 0.00, 0.00, 'test', 'test', 1, '', 1, 0, 0, '1704964976', 1),
(37, '1516', '2024-01-13', '2024-01-12', 6, 3, 0, 50.41, 0.00, 'asd', 'ssad', 0, '', 1, 0, 0, '1704965867', 1),
(38, '234USAP', '2024-01-11', '2024-01-11', 47, 14, 1, 20.00, 0.00, 'erqfdvd', 'test', 0, '', 1, 0, 0, '1704968486', 1),
(46, 'SO541', '2024-01-18', '2024-01-25', 6, 3, 0, 0.00, 0.00, 'as', 'as', 0, '', 1, 1, 0, '1705577497', 1),
(47, 'SO128df6', '2024-01-23', '2024-01-24', 45, 13, 0, 0.00, 0.00, 'afd', 'google pay', 0, '', 1, 1, 0, '1705996664', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sale_order_items`
--

CREATE TABLE `sale_order_items` (
  `sale_item_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `price_id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(14,2) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `send_qty` int(11) NOT NULL,
  `return_qty` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_order_items`
--

INSERT INTO `sale_order_items` (`sale_item_id`, `related_to`, `related_id`, `price_id`, `quote_id`, `order_id`, `invoice_id`, `quantity`, `unit_price`, `amount`, `tax1`, `tax2`, `send_qty`, `return_qty`, `timestamp`) VALUES
(1, 'finished_good', 4, 1, 1, 1, 1, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(2, 'finished_good', 4, 1, 2, 2, 0, 2, 2000.00, 4000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(3, 'finished_good', 4, 1, 0, 4, 0, 2, 2000.00, 4000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(6, 'property_unit', 1, 0, 0, 8, 2, 1, 3200000.00, 3200000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(8, 'property_unit', 2, 0, 0, 8, 2, 1, 3000000.00, 3000000.00, 18, 0, 0, 0, '2024-01-17 10:23:21'),
(9, 'finished_good', 4, 1, 0, 0, 3, 15, 2000.00, 30000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(10, 'property_unit', 3, 0, 0, 0, 4, 1, 4500000.00, 4500000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(11, 'finished_good', 4, 1, 0, 9, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(12, 'finished_good', 4, 1, 0, 10, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(13, 'finished_good', 4, 1, 0, 0, 39, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(14, 'finished_good', 4, 1, 0, 0, 40, 20, 2000.00, 40000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(15, 'finished_good', 4, 1, 0, 26, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(16, 'finished_good', 4, 1, 0, 27, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(17, 'finished_good', 21, 1, 0, 29, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(18, 'finished_good', 21, 1, 0, 0, 41, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(19, 'finished_good', 21, 1, 0, 0, 42, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(20, 'finished_good', 21, 2, 0, 0, 45, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(21, 'finished_good', 21, 1, 0, 0, 44, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(22, 'finished_good', 21, 1, 0, 0, 45, 4, 2000.00, 8000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(23, 'finished_good', 21, 1, 0, 0, 46, 5, 2000.00, 10000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(24, 'finished_good', 21, 1, 0, 30, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(25, 'finished_good', 22, 2, 0, 0, 48, 12, 3000.00, 36000.00, 18, 9, 0, 0, '2024-01-17 10:23:21'),
(26, 'finished_good', 21, 1, 0, 0, 47, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(27, 'finished_good', 21, 1, 0, 31, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(28, 'finished_good', 21, 1, 0, 0, 49, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(29, 'finished_good', 22, 2, 3, 37, 0, 1, 3000.00, 3000.00, 18, 9, 0, 0, '2024-01-17 10:23:21'),
(31, 'finished_good', 22, 2, 0, 32, 0, 1, 3000.00, 3000.00, 18, 9, 0, 0, '2024-01-17 10:23:21'),
(32, 'finished_good', 21, 1, 4, 36, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(33, 'finished_good', 21, 1, 5, 38, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(34, 'finished_good', 22, 2, 6, 0, 0, 1, 3000.00, 3000.00, 18, 9, 0, 0, '2024-01-17 10:23:21'),
(35, 'finished_good', 21, 1, 7, 40, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(36, 'finished_good', 21, 1, 8, 39, 0, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(37, 'finished_good', 21, 8, 0, 0, 52, 1, 120.00, 120.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(38, 'finished_good', 21, 8, 0, 0, 53, 1, 120.00, 120.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(39, 'finished_good', 21, 1, 0, 0, 54, 1, 2000.00, 2000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(40, 'finished_good', 25, 8, 0, 0, 55, 4, 120.00, 480.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(41, 'finished_good', 25, 8, 0, 0, 56, 2, 120.00, 240.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(42, 'finished_good', 21, 1, 0, 0, 56, 3, 2000.00, 6000.00, 9, 9, 0, 0, '2024-01-17 10:23:21'),
(43, 'finished_good', 25, 8, 0, 0, 57, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-17 10:23:21'),
(44, 'finished_good', 21, 8, 0, 0, 58, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-17 10:23:21'),
(45, 'finished_good', 22, 2, 0, 0, 59, 2, 3000.00, 6000.00, 18, 9, 0, 0, '2024-01-17 11:04:24'),
(46, 'finished_good', 22, 2, 9, 41, 0, 1, 3000.00, 3000.00, 18, 9, 0, 0, '2024-01-17 11:49:30'),
(48, 'finished_good', 22, 2, 10, 0, 0, 1, 3000.00, 3000.00, 18, 9, 0, 0, '2024-01-18 05:22:41'),
(49, 'finished_good', 25, 8, 0, 0, 60, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-18 05:50:56'),
(50, 'finished_good', 25, 8, 10, 0, 0, 2, 120.00, 240.00, 9, 18, 0, 0, '2024-01-18 06:17:28'),
(55, 'finished_good', 22, 2, 0, 46, 0, 1, 3000.00, 3000.00, 18, 9, 0, 0, '2024-01-18 11:31:37'),
(56, 'finished_good', 25, 8, 0, 0, 65, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-20 11:13:16'),
(57, 'finished_good', 21, 1, 0, 0, 66, 1, 2000.00, 2000.00, 9, 18, 0, 0, '2024-01-23 07:12:41'),
(58, 'finished_good', 25, 8, 0, 0, 67, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-23 07:15:41'),
(59, 'finished_good', 21, 1, 0, 0, 68, 1, 2000.00, 2000.00, 9, 18, 0, 0, '2024-01-23 07:42:11'),
(60, 'finished_good', 25, 8, 0, 0, 69, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-23 07:52:20'),
(61, 'finished_good', 21, 1, 0, 47, 0, 1, 2000.00, 2000.00, 9, 18, 0, 0, '2024-01-23 07:57:44'),
(62, 'finished_good', 25, 8, 0, 0, 70, 1, 120.00, 120.00, 9, 18, 0, 0, '2024-01-24 04:50:23'),
(63, 'finished_good', 21, 1, 0, 0, 71, 1, 2000.00, 2000.00, 9, 18, 0, 0, '2024-01-24 11:35:25');

-- --------------------------------------------------------

--
-- Table structure for table `sale_payments`
--

CREATE TABLE `sale_payments` (
  `sale_pay_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `paid_on` date NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_payments`
--

INSERT INTO `sale_payments` (`sale_pay_id`, `invoice_id`, `payment_id`, `amount`, `paid_on`, `transaction_id`, `notes`) VALUES
(2, 2, 1, 40000.00, '2022-04-15', '', ''),
(8, 2, 1, 100000.00, '2022-04-15', '', ''),
(9, 1, 3, 12.35, '2023-12-26', '134', 'test'),
(13, 2, 1, 12.90, '2023-12-27', '9696', 'test'),
(14, 1, 1, 2000.00, '2022-04-15', 'tsf', 'fds'),
(16, 3, 1, 3000.00, '2023-12-27', 'tes123', 'tret'),
(18, 44, 2, 1000.00, '2024-01-04', '6538796879', 'fyk'),
(19, 44, 1, 1000.00, '2024-01-12', '1234567890', 'test'),
(20, 45, 1, 10000.00, '2024-01-11', '1234567890', 'tertsdfgf'),
(21, 46, 2, 10000.00, '2024-01-11', '1234567890', 'safdsr32'),
(24, 54, 1, 1000.00, '2024-01-18', 'tes1212', 'rewst'),
(25, 54, 2, 10.00, '2024-01-18', '134', 'ijoik'),
(26, 57, 2, 100.00, '2024-02-08', 'sdf', 'fds'),
(27, 65, 2, 120.00, '2024-01-25', 'tes1212', 'dfs'),
(28, 71, 1, 100.00, '2024-01-24', 'test123', 'dfs'),
(29, 71, 1, 200.00, '2024-01-25', 'test123', 'tet'),
(30, 71, 1, 350.00, '2024-01-24', 'tes56', 'fds');

-- --------------------------------------------------------

--
-- Table structure for table `scheduling`
--

CREATE TABLE `scheduling` (
  `scheduling_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scheduling`
--

INSERT INTO `scheduling` (`scheduling_id`, `start_date`, `due_date`, `location`, `service_id`) VALUES
(2, '2024-01-28', '2024-01-31', 'address ', 4),
(4, '2024-01-19', '2024-01-21', 'test', 5);

-- --------------------------------------------------------

--
-- Table structure for table `selection_rule`
--

CREATE TABLE `selection_rule` (
  `rule_id` int(11) NOT NULL,
  `rule_name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `selection_rule`
--

INSERT INTO `selection_rule` (`rule_id`, `rule_name`, `description`, `created_at`, `created_by`) VALUES
(3, 'rule 1', 'Test rule', '1646907504', 1),
(8, 'test', 'rtet', '1705909175', 1);

-- --------------------------------------------------------

--
-- Table structure for table `selection_rule_segment`
--

CREATE TABLE `selection_rule_segment` (
  `rule_seg_id` int(11) NOT NULL,
  `rule_id` int(11) NOT NULL,
  `segment_id` int(11) NOT NULL,
  `segment_value_idx` tinyint(4) NOT NULL,
  `above_below` tinyint(1) NOT NULL DEFAULT 0,
  `exclude` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `selection_rule_segment`
--

INSERT INTO `selection_rule_segment` (`rule_seg_id`, `rule_id`, `segment_id`, `segment_value_idx`, `above_below`, `exclude`) VALUES
(3, 3, 1, 1, 1, 0),
(4, 3, 2, 2, 1, 0),
(5, 3, 3, 1, 1, 0),
(17, 8, 2, 3, 1, 1),
(18, 8, 3, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `semi_finished`
--

CREATE TABLE `semi_finished` (
  `semi_finished_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `short_desc` varchar(1000) NOT NULL,
  `long_desc` text NOT NULL,
  `group_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `semi_finished`
--

INSERT INTO `semi_finished` (`semi_finished_id`, `name`, `short_desc`, `long_desc`, `group_id`, `code`, `unit_id`, `brand_id`, `created_at`, `created_by`) VALUES
(17, 'test', 'rawegheath', 'awreghthea', 12, 'SO128', 1, 1, '1704177246', 1),
(18, 'Thinner', 'wsefgeawfg', 'fesafgearg', 12, 'egfes74565', 2, 1, '1704863727', 1);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `assigned_to` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `service_desc` text NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `code`, `name`, `priority`, `status`, `assigned_to`, `employee_id`, `service_desc`, `created_by`) VALUES
(4, 'SA03', 'test', 1, 0, 3, 14, 'test', 1),
(5, 'SA04', 'Qbs Support', 3, 2, 1, 13, 'test', 1),
(6, 'dsgsd', 'test', 1, 0, 2, 14, 'sdfhsh', 1),
(7, 'fdhs574', 'test', 1, 0, 2, 13, 'edfgdfhdf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `stock_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`stock_id`, `related_to`, `related_id`, `warehouse_id`, `quantity`, `price_id`, `timestamp`) VALUES
(12, 'raw_material', 2, 15, 0, 1, '2024-01-17 10:39:23'),
(13, 'raw_material', 16, 8, 0, 1, '2024-01-17 10:39:23'),
(14, 'finished_good', 21, 1, 1, 1, '2024-01-17 10:39:23'),
(15, 'semi_finished', 17, 4, 1, 2, '2024-01-17 10:39:23'),
(17, 'semi_finished', 17, 11, 0, 2, '2024-01-17 10:39:23'),
(18, 'finished_good', 22, 6, 1, 2, '2024-01-17 10:39:23'),
(19, 'finished_good', 25, 11, 1, 8, '2024-01-17 10:39:23'),
(20, 'finished_good', 21, 1, 1, 8, '2024-01-17 10:39:23'),
(21, 'finished_good', 21, 4, 1, 1, '2024-01-17 10:39:23'),
(22, 'semi_finished', 18, 2, 1, 1, '2024-01-17 10:39:23'),
(23, 'finished_good', 25, 1, 1, 8, '2024-01-17 10:39:23'),
(24, 'finished_good', 21, 2, 0, 8, '2024-01-20 11:54:33'),
(25, 'semi_finished', 18, 1, 0, 1, '2024-01-20 11:54:44'),
(26, 'finished_good', 21, 6, 0, 8, '2024-01-20 11:55:00'),
(27, 'finished_good', 21, 6, 1, 1, '2024-01-20 11:55:24'),
(28, 'raw_material', 50, 1, 1, 1, '2024-01-20 12:04:54'),
(29, 'finished_good', 21, 2, 1, 1, '2024-01-20 12:07:11'),
(30, 'semi_finished', 17, 1, 1, 2, '2024-01-20 12:50:23'),
(31, 'raw_material', 50, 9, 1, 1, '2024-01-22 05:25:45'),
(32, 'finished_good', 23, 1, 1, 1, '2024-01-22 05:31:30'),
(33, 'raw_material', 47, 2, 1, 1, '2024-01-22 07:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `stock_alerts`
--

CREATE TABLE `stock_alerts` (
  `stock_alert_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `alert_qty_level` int(11) NOT NULL,
  `alert_before` tinyint(4) NOT NULL,
  `recurring` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_alerts`
--

INSERT INTO `stock_alerts` (`stock_alert_id`, `related_to`, `related_id`, `alert_qty_level`, `alert_before`, `recurring`) VALUES
(2, 'raw_material', 2, 30, 20, 1),
(3, 'semi_finished', 2, 45, 127, 1),
(4, 'finished_good', 2, 30, 20, 0),
(5, 'raw_material', 24, 324, 76, 1),
(6, 'finished_good', 7, 324, 76, 1),
(7, 'raw_material', 17, 10000, 2, 1),
(9, 'raw_material', 45, 324, 76, 1),
(12, 'semi_finished', 12, 20, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `stock_entry`
--

CREATE TABLE `stock_entry` (
  `stock_entry_id` int(11) NOT NULL,
  `entry_type` tinyint(1) NOT NULL DEFAULT 0,
  `stock_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `entry_log` varchar(1000) NOT NULL,
  `order_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_entry`
--

INSERT INTO `stock_entry` (`stock_entry_id`, `entry_type`, `stock_id`, `qty`, `entry_log`, `order_id`, `project_id`, `created_at`) VALUES
(3, 0, 1, 8, '', 0, 0, '2022-03-22'),
(4, 0, 2, 10, '', 0, 0, '2022-03-22'),
(5, 1, 0, 1, '', 0, 0, '2022-04-04'),
(6, 1, 0, 1, '', 0, 0, '2022-04-04'),
(7, 1, 9, 1, '', 0, 0, '2022-04-12'),
(22, 2, 9, 1, '', 1, 0, '2022-04-13'),
(23, 2, 10, 1, '', 1, 0, '2022-04-13'),
(37, 3, 7, 5, '', 0, 1, ''),
(41, 3, 8, 5, '', 0, 1, '2022-05-03'),
(42, 3, 2, 3, '', 0, 1, '2022-05-03'),
(43, 3, 8, 2, '', 0, 1, '2023-12-16'),
(44, 3, 2, 15, '', 0, 1, '2023-12-16'),
(45, 1, 0, 1, '', 0, 0, '2024-01-02'),
(46, 1, 0, 1, '', 0, 0, '2024-01-03'),
(47, 1, 0, 1, '', 0, 0, '2024-01-03'),
(48, 1, 0, 1, '', 0, 0, '2024-01-04'),
(49, 1, 0, 1, '', 0, 0, '2024-01-10'),
(50, 1, 0, 1, '', 0, 0, '2024-01-10'),
(51, 1, 0, 1, '', 0, 0, '2024-01-13'),
(52, 1, 0, 1, '', 0, 0, '2024-01-13'),
(53, 1, 14, 1, '', 0, 0, '2024-01-20'),
(54, 1, 21, 1, '', 0, 0, '2024-01-20'),
(55, 1, 0, 1, '', 0, 0, '2024-01-20'),
(56, 1, 14, 1, '', 0, 0, '2024-01-20'),
(57, 1, 0, 1, '', 0, 0, '2024-01-20'),
(58, 1, 0, 1, '', 0, 0, '2024-01-22'),
(59, 1, 0, 1, '', 0, 0, '2024-01-22'),
(60, 1, 0, 1, '', 0, 0, '2024-01-22');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `source_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `code` varchar(20) NOT NULL,
  `position` varchar(40) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `office_number` varchar(13) NOT NULL,
  `fax_number` varchar(13) NOT NULL,
  `company` varchar(140) NOT NULL,
  `gst` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `website` varchar(255) NOT NULL,
  `payment_terms` text NOT NULL,
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `source_id`, `name`, `code`, `position`, `email`, `phone`, `office_number`, `fax_number`, `company`, `gst`, `address`, `city`, `state`, `country`, `zipcode`, `website`, `payment_terms`, `description`, `active`, `created_at`, `created_by`) VALUES
(4, 1, 'Production Thamizharasi', 'SO128', 'web developer', 'support@qbrainstorm.com', '1234567890', '', '', 'qbs', '5754654466689898', 'madurai', 'Thiruvallur', 'tamilnadu', 'India', '602024', '', '', '', 1, '1704187140', 1),
(6, 1, 'QBS Support', 'werewr', '434', 'suppor9t@qbrainstorm.com', '9080780700', 'werwer', 'werewr', 'qbrainstorm', 'rer', 'Test Address', 'chennai', 'Tamil Nadu', 'India', '600087', 'wer', 'werwer', 'werwer', 1, '1705909217', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_contacts`
--

CREATE TABLE `supplier_contacts` (
  `contact_id` int(11) NOT NULL,
  `firstname` varchar(140) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `position` varchar(140) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_contacts`
--

INSERT INTO `supplier_contacts` (`contact_id`, `firstname`, `lastname`, `email`, `phone`, `active`, `position`, `supplier_id`, `created_at`, `created_by`) VALUES
(10, 'QBSsss', 'Support', 'supporttr@qbrainstorm.comf', '9080780700', 1, 'werwer', 4, '1702126664', 1),
(13, 'delete', 'Support', 'support@qbrainstorm.com', '9080780700', 1, 'Purchase Managers', 40, '1702208458', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_locations`
--

CREATE TABLE `supplier_locations` (
  `location_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_locations`
--

INSERT INTO `supplier_locations` (`location_id`, `address`, `city`, `state`, `country`, `zipcode`, `supplier_id`, `created_at`, `created_by`) VALUES
(7, 'Delete Address', 'chennai', 'Tamil Nadu', 'India', '600087', 40, '1702208450', 1),
(15, 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 4, '1705907980', 1),
(16, 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 4, '1705907987', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_rfq`
--

CREATE TABLE `supplier_rfq` (
  `supp_rfq_id` int(11) NOT NULL,
  `rfq_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `selection_rule` varchar(140) NOT NULL,
  `mail_status` tinyint(1) NOT NULL DEFAULT 0,
  `send_contacts` tinyint(1) NOT NULL DEFAULT 0,
  `include_attach` tinyint(1) NOT NULL DEFAULT 0,
  `responded` tinyint(1) NOT NULL DEFAULT 0,
  `responded_at` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supplier_segments`
--

CREATE TABLE `supplier_segments` (
  `segment_id` int(11) NOT NULL,
  `segment_key` varchar(140) NOT NULL,
  `segment_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_segments`
--

INSERT INTO `supplier_segments` (`segment_id`, `segment_key`, `segment_value`, `created_at`, `created_by`) VALUES
(2, 'Product Quality', '{\"0\":\"Not Applicable\",\"1\":\"Poor\",\"2\":\"Average\",\"3\":\"Standard\"}', '1646312456', 1),
(3, 'Support', '{\"0\":\"Not Applicable\",\"1\":\"Poor\",\"2\":\"Good\",\"3\":\"Average\",\"4\":\"Excellent\"}', '1646910701', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_segment_map`
--

CREATE TABLE `supplier_segment_map` (
  `supp_seg_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `segment_json` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_segment_map`
--

INSERT INTO `supplier_segment_map` (`supp_seg_id`, `supplier_id`, `segment_json`) VALUES
(3, 7, '{\"1\":\"2\",\"2\":\"2\",\"3\":\"1\"}'),
(4, 4, '{\"1\":\"1\",\"2\":\"1\",\"3\":\"1\"}'),
(5, 6, '{\"1\":\"3\",\"2\":\"2\",\"3\":\"0\"}'),
(8, 40, '{\"1\":\"3\",\"2\":\"1\",\"3\":\"0\"}');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_sources`
--

CREATE TABLE `supplier_sources` (
  `source_id` int(11) NOT NULL,
  `source_name` varchar(140) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_sources`
--

INSERT INTO `supplier_sources` (`source_id`, `source_name`, `created_at`, `created_by`) VALUES
(1, 'Email campaign', '1646283489', 1),
(8, 'General', '1705908706', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supply_list`
--

CREATE TABLE `supply_list` (
  `supply_list_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supply_qty` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supply_list`
--

INSERT INTO `supply_list` (`supply_list_id`, `related_to`, `related_id`, `supplier_id`, `supply_qty`, `created_at`, `created_by`) VALUES
(4, 'raw_material', 17, 4, 0, '1647066656', 1),
(19, 'semi_finished', 6, 40, 0, '1702208413', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `task_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `related_to` varchar(20) NOT NULL,
  `related_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `assignees` int(11) NOT NULL,
  `followers` int(11) NOT NULL,
  `task_description` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `name`, `status`, `start_date`, `due_date`, `related_to`, `related_id`, `priority`, `assignees`, `followers`, `task_description`, `created_by`) VALUES
(2, 'Follow the lead', 0, '2024-01-06', '2024-01-11', 'lead', 4, 1, 1, 2, 'Follow the lead', 1),
(3, 'QBS Support', 3, '2024-01-06', '2024-01-24', 'project', 3, 0, 2, 3, 'test', 1),
(4, 'Domain C', 1, '2024-01-07', '2024-01-13', 'ticket', 10, 2, 2, 3, 'test two', 1);

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

CREATE TABLE `taxes` (
  `tax_id` int(11) NOT NULL,
  `tax_name` varchar(50) NOT NULL,
  `percent` tinyint(4) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `taxes`
--

INSERT INTO `taxes` (`tax_id`, `tax_name`, `percent`, `created_at`, `created_by`) VALUES
(1, 'CGST', 9, '1645106126', 1),
(2, 'SGST', 9, '1645158708', 1),
(3, 'IGST', 18, '1645159286', 1),
(4, 'HGST', 20, '1703321477', 1);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `team_count` smallint(6) NOT NULL,
  `lead_by` int(11) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`team_id`, `name`, `description`, `team_count`, `lead_by`, `created_at`, `created_by`) VALUES
(15, 'test', 'wsrhht', 5, 2, '1704173024', 1);

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `member_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`member_id`, `team_id`, `employee_id`) VALUES
(3, 1, 1),
(4, 1, 2),
(5, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `subject` varchar(140) NOT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT 0,
  `cust_id` int(11) NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `problem` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `subject`, `priority`, `cust_id`, `assigned_to`, `problem`, `status`, `remarks`, `created_at`, `created_by`) VALUES
(9, 'doubt', 0, 6, 2, 'aezgtbhadn', 2, '', '1703842779', 1),
(10, 'doub', 1, 9, 2, 'sehtsht', 0, '', '1704447163', 1),
(11, 'Software ', 1, 6, 1, 'Some problems ', 0, '', '1704720702', 1),
(12, 'doubt', 1, 45, 3, 'sfgag', 0, '', '1705665339', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transports`
--

CREATE TABLE `transports` (
  `transport_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `type_id` int(11) NOT NULL,
  `code` varchar(140) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `delivery_count` int(11) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transports`
--

INSERT INTO `transports` (`transport_id`, `name`, `type_id`, `code`, `active`, `status`, `delivery_count`, `description`, `created_at`, `created_by`) VALUES
(1, 'test2', 1, '123', 1, 1, 0, 'hello', '1647087322', 1),
(2, 'test', 3, '124', 1, 1, 0, 'hellow', '1647087414', 1),
(6, 'Leo', 3, '234234', 1, 1, 0, 'test', '1703409406', 1),
(7, 'Q Brainstorm', 3, '6969', 1, 1, 0, 'test', '1703661598', 1),
(9, 'test', 3, 'c58554', 1, 0, 0, 'dfhssdh', '1705743126', 1),
(10, 'Thamizharasi', 12, 'b6501', 1, 0, 0, 'sdyhrthsrh', '1705743269', 1),
(11, 'kkkkkk', 1, 'werewr', 1, 0, 0, 'wqewqe', '1705743352', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transport_type`
--

CREATE TABLE `transport_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(140) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transport_type`
--

INSERT INTO `transport_type` (`type_id`, `type_name`, `created_at`, `created_by`) VALUES
(1, 'Airways', '1647082077', 1),
(3, 'Roadways', '1647328672', 1),
(11, 'shipway', '1705743195', 1),
(12, 'Lorry', '1705743222', 1),
(14, 'Bike', '1705743244', 1);

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(20) NOT NULL,
  `created_at` varchar(20) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`unit_id`, `unit_name`, `created_at`, `created_by`) VALUES
(1, 'Kg', '1645537313', 1),
(2, 'Litter', '1702460196', 1),
(5, 'gram', '1704864231', 1);

-- --------------------------------------------------------

--
-- Table structure for table `warehouses`
--

CREATE TABLE `warehouses` (
  `warehouse_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(140) NOT NULL,
  `state` varchar(140) NOT NULL,
  `country` varchar(140) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `has_bins` tinyint(1) NOT NULL DEFAULT 0,
  `description` text NOT NULL,
  `aisle_count` int(11) NOT NULL,
  `racks_per_aisle` int(11) NOT NULL,
  `shelf_per_rack` int(11) NOT NULL,
  `bins_per_shelf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warehouses`
--

INSERT INTO `warehouses` (`warehouse_id`, `name`, `address`, `city`, `state`, `country`, `zipcode`, `has_bins`, `description`, `aisle_count`, `racks_per_aisle`, `shelf_per_rack`, `bins_per_shelf`) VALUES
(1, 'LOC-3', 'No.164, First Floor, Arcot Rd, Valasaravakkam', 'Chennai', 'Tamil Nadu', 'India', '600087', 1, '', 12, 10, 5, 4),
(2, 'LOC-2', 'No.164, First Floor, Arcot Rd, Valasaravakkam', 'Chennai', 'Tamil Nadu', 'India', '600087', 0, '', 0, 0, 0, 0),
(4, 'vinitha', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 0, '', 0, 0, 0, 0),
(6, 'sample6', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 1, 'zsvjksv', 45, 45, 55, 55),
(8, 'sadhana', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 1, 'ftjyguj', 44, 547, 635, 5),
(9, 'harina', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 1, 'ftjyguj', 44, 547, 635, 5),
(11, 'fathima', 'chennai', 'Thiruvallur', 'tamilnadu', 'India', '602024', 1, 'sfffrg', 54, 45, 45, 54);

-- --------------------------------------------------------

--
-- Table structure for table `work_groups`
--

CREATE TABLE `work_groups` (
  `wgroup_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `approx_days` smallint(6) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `work_groups`
--

INSERT INTO `work_groups` (`wgroup_id`, `name`, `approx_days`, `description`) VALUES
(2, 'Group 2', 50, 'hello'),
(3, 'Group 3', 120, 'hello'),
(10, 'QBS Support', 32767, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `work_group_equip`
--

CREATE TABLE `work_group_equip` (
  `wgroup_equip_id` int(11) NOT NULL,
  `wgroup_id` int(11) NOT NULL,
  `equip_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `work_group_equip`
--

INSERT INTO `work_group_equip` (`wgroup_equip_id`, `wgroup_id`, `equip_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(9, 10, 1),
(10, 11, 1),
(11, 12, 1),
(12, 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `work_group_items`
--

CREATE TABLE `work_group_items` (
  `wgroup_item_id` int(11) NOT NULL,
  `wgroup_id` int(11) NOT NULL,
  `related_to` varchar(140) NOT NULL,
  `related_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `work_group_items`
--

INSERT INTO `work_group_items` (`wgroup_item_id`, `wgroup_id`, `related_to`, `related_id`, `qty`) VALUES
(1, 1, 'raw_material', 2, 5),
(5, 3, 'raw_material', 21, 10),
(6, 10, 'raw_material', 3, 78),
(7, 11, 'raw_material', 20, 59),
(9, 12, 'raw_material', 47, 1),
(10, 2, 'raw_material', 43, 78),
(11, 13, 'raw_material', 53, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountbase`
--
ALTER TABLE `accountbase`
  ADD PRIMARY KEY (`base_id`);

--
-- Indexes for table `account_groups`
--
ALTER TABLE `account_groups`
  ADD PRIMARY KEY (`acc_group_id`);

--
-- Indexes for table `additions`
--
ALTER TABLE `additions`
  ADD PRIMARY KEY (`add_id`);

--
-- Indexes for table `amenity`
--
ALTER TABLE `amenity`
  ADD PRIMARY KEY (`amenity_id`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`attach_id`);

--
-- Indexes for table `auto_transaction`
--
ALTER TABLE `auto_transaction`
  ADD PRIMARY KEY (`autotrans_id`);

--
-- Indexes for table `auto_trans_list`
--
ALTER TABLE `auto_trans_list`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `bankaccounts`
--
ALTER TABLE `bankaccounts`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `contractors`
--
ALTER TABLE `contractors`
  ADD PRIMARY KEY (`contractor_id`);

--
-- Indexes for table `contractor_payments`
--
ALTER TABLE `contractor_payments`
  ADD PRIMARY KEY (`contractor_pay_id`);

--
-- Indexes for table `credit_items`
--
ALTER TABLE `credit_items`
  ADD PRIMARY KEY (`credit_item_id`);

--
-- Indexes for table `credit_notes`
--
ALTER TABLE `credit_notes`
  ADD PRIMARY KEY (`credit_id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`currency_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `customer_contacts`
--
ALTER TABLE `customer_contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `customer_shippingaddr`
--
ALTER TABLE `customer_shippingaddr`
  ADD PRIMARY KEY (`shippingaddr_id`);

--
-- Indexes for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD PRIMARY KEY (`cf_id`);

--
-- Indexes for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD PRIMARY KEY (`cfv_id`);

--
-- Indexes for table `deductions`
--
ALTER TABLE `deductions`
  ADD PRIMARY KEY (`deduct_id`);

--
-- Indexes for table `delivery_records`
--
ALTER TABLE `delivery_records`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`designation_id`);

--
-- Indexes for table `dispatch`
--
ALTER TABLE `dispatch`
  ADD PRIMARY KEY (`dispatch_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `emp_attendance`
--
ALTER TABLE `emp_attendance`
  ADD PRIMARY KEY (`attend_id`);

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
  ADD PRIMARY KEY (`equip_id`);

--
-- Indexes for table `erp_groups`
--
ALTER TABLE `erp_groups`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `erp_groups_map`
--
ALTER TABLE `erp_groups_map`
  ADD PRIMARY KEY (`groupmap_id`);

--
-- Indexes for table `erp_jobqueue`
--
ALTER TABLE `erp_jobqueue`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `erp_log`
--
ALTER TABLE `erp_log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `erp_roles`
--
ALTER TABLE `erp_roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `erp_settings`
--
ALTER TABLE `erp_settings`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `erp_users`
--
ALTER TABLE `erp_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `estimates`
--
ALTER TABLE `estimates`
  ADD PRIMARY KEY (`estimate_id`);

--
-- Indexes for table `estimate_items`
--
ALTER TABLE `estimate_items`
  ADD PRIMARY KEY (`est_item_id`);

--
-- Indexes for table `finished_goods`
--
ALTER TABLE `finished_goods`
  ADD PRIMARY KEY (`finished_good_id`);

--
-- Indexes for table `general_ledger`
--
ALTER TABLE `general_ledger`
  ADD PRIMARY KEY (`ledger_id`);

--
-- Indexes for table `gl_accounts`
--
ALTER TABLE `gl_accounts`
  ADD PRIMARY KEY (`gl_acc_id`);

--
-- Indexes for table `grn`
--
ALTER TABLE `grn`
  ADD PRIMARY KEY (`grn_id`);

--
-- Indexes for table `inventory_requisition`
--
ALTER TABLE `inventory_requisition`
  ADD PRIMARY KEY (`invent_req_id`);

--
-- Indexes for table `inventory_services`
--
ALTER TABLE `inventory_services`
  ADD PRIMARY KEY (`invent_service_id`);

--
-- Indexes for table `inventory_warehouse`
--
ALTER TABLE `inventory_warehouse`
  ADD PRIMARY KEY (`invent_house_id`);

--
-- Indexes for table `journal_entry`
--
ALTER TABLE `journal_entry`
  ADD PRIMARY KEY (`journal_id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`lead_id`);

--
-- Indexes for table `lead_source`
--
ALTER TABLE `lead_source`
  ADD PRIMARY KEY (`source_id`);

--
-- Indexes for table `marketing`
--
ALTER TABLE `marketing`
  ADD PRIMARY KEY (`marketing_id`);

--
-- Indexes for table `master`
--
ALTER TABLE `master`
  ADD PRIMARY KEY (`master_id`);

--
-- Indexes for table `mrp_bom`
--
ALTER TABLE `mrp_bom`
  ADD PRIMARY KEY (`bom_id`);

--
-- Indexes for table `mrp_dataset_forecast`
--
ALTER TABLE `mrp_dataset_forecast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mrp_scheduling`
--
ALTER TABLE `mrp_scheduling`
  ADD PRIMARY KEY (`mrp_scheduling_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notify_id`);

--
-- Indexes for table `packs`
--
ALTER TABLE `packs`
  ADD PRIMARY KEY (`pack_id`);

--
-- Indexes for table `pack_records`
--
ALTER TABLE `pack_records`
  ADD PRIMARY KEY (`pack_rec_id`);

--
-- Indexes for table `pack_unit`
--
ALTER TABLE `pack_unit`
  ADD PRIMARY KEY (`pack_unit_id`);

--
-- Indexes for table `payment_modes`
--
ALTER TABLE `payment_modes`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `payroll_additions`
--
ALTER TABLE `payroll_additions`
  ADD PRIMARY KEY (`pay_add_id`);

--
-- Indexes for table `payroll_deductions`
--
ALTER TABLE `payroll_deductions`
  ADD PRIMARY KEY (`pay_deduct_id`);

--
-- Indexes for table `payroll_entry`
--
ALTER TABLE `payroll_entry`
  ADD PRIMARY KEY (`pay_entry_id`);

--
-- Indexes for table `payroll_process`
--
ALTER TABLE `payroll_process`
  ADD PRIMARY KEY (`pay_proc_id`);

--
-- Indexes for table `planning`
--
ALTER TABLE `planning`
  ADD PRIMARY KEY (`planning_id`);

--
-- Indexes for table `price_list`
--
ALTER TABLE `price_list`
  ADD PRIMARY KEY (`price_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `project_amenity`
--
ALTER TABLE `project_amenity`
  ADD PRIMARY KEY (`project_amen_id`);

--
-- Indexes for table `project_expense`
--
ALTER TABLE `project_expense`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `project_members`
--
ALTER TABLE `project_members`
  ADD PRIMARY KEY (`project_mem_id`);

--
-- Indexes for table `project_phase`
--
ALTER TABLE `project_phase`
  ADD PRIMARY KEY (`phase_id`);

--
-- Indexes for table `project_rawmaterials`
--
ALTER TABLE `project_rawmaterials`
  ADD PRIMARY KEY (`project_raw_id`);

--
-- Indexes for table `project_testing`
--
ALTER TABLE `project_testing`
  ADD PRIMARY KEY (`project_test_id`);

--
-- Indexes for table `project_workgroup`
--
ALTER TABLE `project_workgroup`
  ADD PRIMARY KEY (`project_wgrp_id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`property_id`);

--
-- Indexes for table `propertytype`
--
ALTER TABLE `propertytype`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `property_amenity`
--
ALTER TABLE `property_amenity`
  ADD PRIMARY KEY (`prop_ament_id`);

--
-- Indexes for table `property_unit`
--
ALTER TABLE `property_unit`
  ADD PRIMARY KEY (`prop_unit_id`);

--
-- Indexes for table `purchase_invoice`
--
ALTER TABLE `purchase_invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `purchase_payments`
--
ALTER TABLE `purchase_payments`
  ADD PRIMARY KEY (`purchase_pay_id`);

--
-- Indexes for table `push_notify`
--
ALTER TABLE `push_notify`
  ADD PRIMARY KEY (`push_id`);

--
-- Indexes for table `quotations`
--
ALTER TABLE `quotations`
  ADD PRIMARY KEY (`quote_id`);

--
-- Indexes for table `raw_materials`
--
ALTER TABLE `raw_materials`
  ADD PRIMARY KEY (`raw_material_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `requisition`
--
ALTER TABLE `requisition`
  ADD PRIMARY KEY (`req_id`);

--
-- Indexes for table `rfq`
--
ALTER TABLE `rfq`
  ADD PRIMARY KEY (`rfq_id`);

--
-- Indexes for table `sale_invoice`
--
ALTER TABLE `sale_invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `sale_order`
--
ALTER TABLE `sale_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `sale_order_items`
--
ALTER TABLE `sale_order_items`
  ADD PRIMARY KEY (`sale_item_id`);

--
-- Indexes for table `sale_payments`
--
ALTER TABLE `sale_payments`
  ADD PRIMARY KEY (`sale_pay_id`);

--
-- Indexes for table `scheduling`
--
ALTER TABLE `scheduling`
  ADD PRIMARY KEY (`scheduling_id`);

--
-- Indexes for table `selection_rule`
--
ALTER TABLE `selection_rule`
  ADD PRIMARY KEY (`rule_id`);

--
-- Indexes for table `selection_rule_segment`
--
ALTER TABLE `selection_rule_segment`
  ADD PRIMARY KEY (`rule_seg_id`);

--
-- Indexes for table `semi_finished`
--
ALTER TABLE `semi_finished`
  ADD PRIMARY KEY (`semi_finished_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_id`),
  ADD UNIQUE KEY `service_code` (`code`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `stock_alerts`
--
ALTER TABLE `stock_alerts`
  ADD PRIMARY KEY (`stock_alert_id`);

--
-- Indexes for table `stock_entry`
--
ALTER TABLE `stock_entry`
  ADD PRIMARY KEY (`stock_entry_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `supplier_contacts`
--
ALTER TABLE `supplier_contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `supplier_locations`
--
ALTER TABLE `supplier_locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `supplier_rfq`
--
ALTER TABLE `supplier_rfq`
  ADD PRIMARY KEY (`supp_rfq_id`);

--
-- Indexes for table `supplier_segments`
--
ALTER TABLE `supplier_segments`
  ADD PRIMARY KEY (`segment_id`);

--
-- Indexes for table `supplier_segment_map`
--
ALTER TABLE `supplier_segment_map`
  ADD PRIMARY KEY (`supp_seg_id`);

--
-- Indexes for table `supplier_sources`
--
ALTER TABLE `supplier_sources`
  ADD PRIMARY KEY (`source_id`);

--
-- Indexes for table `supply_list`
--
ALTER TABLE `supply_list`
  ADD PRIMARY KEY (`supply_list_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `taxes`
--
ALTER TABLE `taxes`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `transports`
--
ALTER TABLE `transports`
  ADD PRIMARY KEY (`transport_id`);

--
-- Indexes for table `transport_type`
--
ALTER TABLE `transport_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `warehouses`
--
ALTER TABLE `warehouses`
  ADD PRIMARY KEY (`warehouse_id`);

--
-- Indexes for table `work_groups`
--
ALTER TABLE `work_groups`
  ADD PRIMARY KEY (`wgroup_id`);

--
-- Indexes for table `work_group_equip`
--
ALTER TABLE `work_group_equip`
  ADD PRIMARY KEY (`wgroup_equip_id`);

--
-- Indexes for table `work_group_items`
--
ALTER TABLE `work_group_items`
  ADD PRIMARY KEY (`wgroup_item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountbase`
--
ALTER TABLE `accountbase`
  MODIFY `base_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `account_groups`
--
ALTER TABLE `account_groups`
  MODIFY `acc_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `additions`
--
ALTER TABLE `additions`
  MODIFY `add_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `amenity`
--
ALTER TABLE `amenity`
  MODIFY `amenity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `attach_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;

--
-- AUTO_INCREMENT for table `auto_transaction`
--
ALTER TABLE `auto_transaction`
  MODIFY `autotrans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `auto_trans_list`
--
ALTER TABLE `auto_trans_list`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bankaccounts`
--
ALTER TABLE `bankaccounts`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contractors`
--
ALTER TABLE `contractors`
  MODIFY `contractor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contractor_payments`
--
ALTER TABLE `contractor_payments`
  MODIFY `contractor_pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `credit_items`
--
ALTER TABLE `credit_items`
  MODIFY `credit_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `credit_notes`
--
ALTER TABLE `credit_notes`
  MODIFY `credit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `currency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `customer_contacts`
--
ALTER TABLE `customer_contacts`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `customer_shippingaddr`
--
ALTER TABLE `customer_shippingaddr`
  MODIFY `shippingaddr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `custom_fields`
--
ALTER TABLE `custom_fields`
  MODIFY `cf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  MODIFY `cfv_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `deductions`
--
ALTER TABLE `deductions`
  MODIFY `deduct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `delivery_records`
--
ALTER TABLE `delivery_records`
  MODIFY `delivery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `designation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dispatch`
--
ALTER TABLE `dispatch`
  MODIFY `dispatch_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `emp_attendance`
--
ALTER TABLE `emp_attendance`
  MODIFY `attend_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `equipments`
--
ALTER TABLE `equipments`
  MODIFY `equip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `erp_groups`
--
ALTER TABLE `erp_groups`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `erp_groups_map`
--
ALTER TABLE `erp_groups_map`
  MODIFY `groupmap_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=340;

--
-- AUTO_INCREMENT for table `erp_jobqueue`
--
ALTER TABLE `erp_jobqueue`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `erp_log`
--
ALTER TABLE `erp_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2504;

--
-- AUTO_INCREMENT for table `erp_roles`
--
ALTER TABLE `erp_roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `erp_settings`
--
ALTER TABLE `erp_settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `erp_users`
--
ALTER TABLE `erp_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `estimates`
--
ALTER TABLE `estimates`
  MODIFY `estimate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `estimate_items`
--
ALTER TABLE `estimate_items`
  MODIFY `est_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `finished_goods`
--
ALTER TABLE `finished_goods`
  MODIFY `finished_good_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `general_ledger`
--
ALTER TABLE `general_ledger`
  MODIFY `ledger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `gl_accounts`
--
ALTER TABLE `gl_accounts`
  MODIFY `gl_acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `grn`
--
ALTER TABLE `grn`
  MODIFY `grn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55850;

--
-- AUTO_INCREMENT for table `inventory_requisition`
--
ALTER TABLE `inventory_requisition`
  MODIFY `invent_req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `inventory_services`
--
ALTER TABLE `inventory_services`
  MODIFY `invent_service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `inventory_warehouse`
--
ALTER TABLE `inventory_warehouse`
  MODIFY `invent_house_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `journal_entry`
--
ALTER TABLE `journal_entry`
  MODIFY `journal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `lead_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `lead_source`
--
ALTER TABLE `lead_source`
  MODIFY `source_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `marketing`
--
ALTER TABLE `marketing`
  MODIFY `marketing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `master`
--
ALTER TABLE `master`
  MODIFY `master_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mrp_bom`
--
ALTER TABLE `mrp_bom`
  MODIFY `bom_id` int(200) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mrp_dataset_forecast`
--
ALTER TABLE `mrp_dataset_forecast`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `mrp_scheduling`
--
ALTER TABLE `mrp_scheduling`
  MODIFY `mrp_scheduling_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notify_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `packs`
--
ALTER TABLE `packs`
  MODIFY `pack_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pack_records`
--
ALTER TABLE `pack_records`
  MODIFY `pack_rec_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pack_unit`
--
ALTER TABLE `pack_unit`
  MODIFY `pack_unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `payment_modes`
--
ALTER TABLE `payment_modes`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payroll_additions`
--
ALTER TABLE `payroll_additions`
  MODIFY `pay_add_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payroll_deductions`
--
ALTER TABLE `payroll_deductions`
  MODIFY `pay_deduct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `payroll_entry`
--
ALTER TABLE `payroll_entry`
  MODIFY `pay_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `payroll_process`
--
ALTER TABLE `payroll_process`
  MODIFY `pay_proc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `planning`
--
ALTER TABLE `planning`
  MODIFY `planning_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `price_list`
--
ALTER TABLE `price_list`
  MODIFY `price_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `project_amenity`
--
ALTER TABLE `project_amenity`
  MODIFY `project_amen_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `project_expense`
--
ALTER TABLE `project_expense`
  MODIFY `expense_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `project_members`
--
ALTER TABLE `project_members`
  MODIFY `project_mem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `project_phase`
--
ALTER TABLE `project_phase`
  MODIFY `phase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `project_rawmaterials`
--
ALTER TABLE `project_rawmaterials`
  MODIFY `project_raw_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `project_testing`
--
ALTER TABLE `project_testing`
  MODIFY `project_test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `project_workgroup`
--
ALTER TABLE `project_workgroup`
  MODIFY `project_wgrp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `property_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `propertytype`
--
ALTER TABLE `propertytype`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `property_amenity`
--
ALTER TABLE `property_amenity`
  MODIFY `prop_ament_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `property_unit`
--
ALTER TABLE `property_unit`
  MODIFY `prop_unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `purchase_invoice`
--
ALTER TABLE `purchase_invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `purchase_payments`
--
ALTER TABLE `purchase_payments`
  MODIFY `purchase_pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `push_notify`
--
ALTER TABLE `push_notify`
  MODIFY `push_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quotations`
--
ALTER TABLE `quotations`
  MODIFY `quote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `raw_materials`
--
ALTER TABLE `raw_materials`
  MODIFY `raw_material_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `requisition`
--
ALTER TABLE `requisition`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rfq`
--
ALTER TABLE `rfq`
  MODIFY `rfq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sale_invoice`
--
ALTER TABLE `sale_invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `sale_order`
--
ALTER TABLE `sale_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `sale_order_items`
--
ALTER TABLE `sale_order_items`
  MODIFY `sale_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `sale_payments`
--
ALTER TABLE `sale_payments`
  MODIFY `sale_pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `scheduling`
--
ALTER TABLE `scheduling`
  MODIFY `scheduling_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `selection_rule`
--
ALTER TABLE `selection_rule`
  MODIFY `rule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `selection_rule_segment`
--
ALTER TABLE `selection_rule_segment`
  MODIFY `rule_seg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `semi_finished`
--
ALTER TABLE `semi_finished`
  MODIFY `semi_finished_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `stock_alerts`
--
ALTER TABLE `stock_alerts`
  MODIFY `stock_alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `stock_entry`
--
ALTER TABLE `stock_entry`
  MODIFY `stock_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `supplier_contacts`
--
ALTER TABLE `supplier_contacts`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `supplier_locations`
--
ALTER TABLE `supplier_locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `supplier_rfq`
--
ALTER TABLE `supplier_rfq`
  MODIFY `supp_rfq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `supplier_segments`
--
ALTER TABLE `supplier_segments`
  MODIFY `segment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `supplier_segment_map`
--
ALTER TABLE `supplier_segment_map`
  MODIFY `supp_seg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `supplier_sources`
--
ALTER TABLE `supplier_sources`
  MODIFY `source_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `supply_list`
--
ALTER TABLE `supply_list`
  MODIFY `supply_list_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `taxes`
--
ALTER TABLE `taxes`
  MODIFY `tax_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `team_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `transports`
--
ALTER TABLE `transports`
  MODIFY `transport_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `transport_type`
--
ALTER TABLE `transport_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `warehouses`
--
ALTER TABLE `warehouses`
  MODIFY `warehouse_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `work_groups`
--
ALTER TABLE `work_groups`
  MODIFY `wgroup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `work_group_equip`
--
ALTER TABLE `work_group_equip`
  MODIFY `wgroup_equip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `work_group_items`
--
ALTER TABLE `work_group_items`
  MODIFY `wgroup_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
