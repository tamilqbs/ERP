<?php
    include_once 'Mailer.php';
    include_once APPPATH.'third_party/PHPMailer/vendor/autoload.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    class Php_mailer extends Mailer{

        public function __construct(){
            parent::__construct();
            $this->mailer=new PHPMailer(true);

            $this->config();
            $this->constructBCC();
            $this->constructCC();
        }

        protected function config(){
            $this->mailer->Username=$this->settings['smtp_username'];
            $this->mailer->Password=$this->settings['smtp_password'];
            $this->mailer->isHTML(true);
            $this->mailer->isSMTP();
            $this->mailer->SMTPDebug=0;
            $this->mailer->Host=$this->settings['smtp_host'];
            $this->mailer->Port=$this->settings['smtp_port'];
            $this->mailer->SMTPAuth=true;
            if($this->settings['email_encryption']=="tls"){
                $this->mailer->SMTPSecure="tls";
                $this->mailer->SMTPOptions=array(
                    "ssl"=>array(
                        "verify_peer"=>false,
                        "verify_peer_name"=>false,
                        "allow_self_signed"=>true
                    )
                );
            }else if($this->settings['email_encryption']=="ssl"){
                $this->mailer->SMTPSecure="ssl";
            }
            parent::config();
        }

        public function addTo($email,$name=""){
            $this->mailer->addAddress($email,$name);
        }

        public function addCc($email,$name=""){
            $this->mailer->addCC($email,$name);
        }

        public function addBcc($email,$name=""){
            $this->mailer->addBCC($email,$name);
        }

        public function addFrom($email,$name){
            $this->mailer->setFrom($email,$name);
        }

        public function getFrom(){
            return $this->mailer->From;
        }

        public function getFromName(){
            return $this->mailer->FromName;
        }

        public function addReplyto($email,$name=""){
            $this->mailer->addReplyTo($email,$name);
        }

        public function attachFileAsString($str,$filename,$contenttype){
            $this->mailer->addStringAttachment($str,$filename);
        }

        public function attachFile($filepath,$filename,$contenttype){
            $this->mailer->addAttachment($filepath,$filename);
        }

        public function clearAll($attach=true){
            if($attach){
                $this->mailer->clearAttachments();
            }
            $this->mailer->clearAddresses();
            $this->mailer->clearBCCs();
            $this->mailer->clearCCs();
            $this->mailer->clearReplyTos();
            //Reconstructing
            $this->constructBCC();
            $this->constructCC();
        }

        public function addSubject($subject){
            $this->mailer->Subject=$subject;
        }

        public function addBody($body){
            $this->mailer->Body=$body;
        }

        public function send(){
            $send=false;
            try{
                $this->mailer->send();
                $send=true;
            }catch(Exception $ex){
                print_r($ex);
                $send=false;
            }
            return $send;
        }
    }
?>