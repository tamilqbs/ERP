<?php
    defined('BASEPATH') or exit('No direct script access allowed');

    include_once APPPATH.'libraries/emailtemplates/RequisitionLink.php';
    
    class EmailTemplate{

        private static function getCreater($name){
            $creater=null;
            if($name=="requisitionlink"){
                $creater=new RequisitionLink();
            }
            return $creater;
        }

        public static function getTemplate($name,$config){
            $creater=self::getCreater($name);
            $template="";
            if(isset($creater)){
                $template=$creater->createTemplate($config);
            }
            return $template;
        }
    }
?>