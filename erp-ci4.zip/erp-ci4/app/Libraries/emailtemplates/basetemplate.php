<!DOCTYPE html>
<html>
    <head>
    <title></title>
    <style type="text/css">
        .wrapper{
            font-family: sans-serif;
            width:100%;
            margin:0px;
            table-layout:fixed;
            background-color:lightgray;
        }
        .main{
            width:100%;
            max-width:600px;
            margin:0px auto;
            background-color:white;
            border-spacing:0px;
        }
    </style>
    </head>
<body>
    <center class="wrapper" >
        <table class="main" width="100%">
            <tr>
                <td style="padding:8px;border-top:3px solid lightgray;">
                    <img src="<?php echo base_url().'assets/images/logo.png' ;?>" width="120" />
                </td>
            </tr>
            <tr>
                <td style="padding:3px 0px;background-color:cadetblue;"></td>
            </tr>
            <tr>
                <td style="text-align:center;" >
                    <h1 style="font-weight:600;font-size:22px;color:dodgerblue"><?php echo $g_settings['company_name']; ?></h1>
                </td>
            </tr>
            <tr>
                <td style="padding:8px;">
                    <table width="100%" >
                        <tr>
                            <td style="text-align:center"><h4 style="font-weight:600;">General Notification</h4></td>
                        </tr>
                        <tr>
                            <td>
                                
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="padding:3px 0px;background-color:cadetblue;"></td>
            </tr>
            <tr>
                <td style="text-align:center;border-bottom:3px solid lightgray;">
                    <p style="font-size:14px;margin:8px 0px;padding:6px;line-height:20px;color:lightslategray;">
                        <?php echo $g_settings['address']; ?>, <br/>
                        <?php echo $g_settings['city']; ?>, <?php echo $g_settings['state']; ?> <br/>
                        <?php echo $g_settings['country'] ;?> <?php echo $g_settings['zip'] ; ?><br/>
                    </p>
                </td>
            </tr>
        </table>
    </center>
</body>
</html>