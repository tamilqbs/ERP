<?php
    defined('BASEPATH') or exit('No direct script access allowed');

    include_once APPPATH.'libraries/emailtemplates/AbstractTemplate.php';

    class RequisitionLink extends AbstractTemplate{

        public function getStyle(){
            return "";
        }

        public function getTitle(){
            return "Requisition";
        }

        public function getBody($config){
            $data=$config['data'];
            $body='
                <table>
                    <tr >
                        <td style="padding:8px 0px;">Dear <b>'.$data->assigned.'</b>, Kindly approve the requisition</td> 
                    </tr>
                    <tr>
                        <td style="padding:8px 0px;"><b>Description: </b>'.$data->description.'</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0px;"><b>Priority: </b>'.$config['priority'][$data->priority].'</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0px;">'.$data->created.' created this requisition on '.date("d F Y",$data->created_at).'</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0px;">Click the Requisition Link 
                        <a target="_BLANK" style="color:dodgerblue" href="'.$config['link'].'">'.$data->req_code.'</a>
                        </td>
                    </tr>
                </table>
            ';
            return $body;
        }

    }
?>