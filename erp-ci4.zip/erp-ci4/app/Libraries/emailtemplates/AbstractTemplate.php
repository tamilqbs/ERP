<?php

namespace App\Libraries;

use CodeIgniter\CodeIgniter;
use CodeIgniter\HTTP\Response;
use Config\Services;

defined('BASEPATH') or exit('No direct script access allowed');

abstract class AbstractTemplate
{
    protected $ci;
    protected $template;

    public function __construct()
    {
        $this->ci = Services::codeigniter();
        $this->template = '';
    }

    protected function startHeader()
    {
        $gSettings = $this->ci->getData()['g_settings'];
        $this->template .= '
            <!DOCTYPE html>
            <html>
                <head>
                    <title>Email</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                    <meta name="X_UA_Compatible" content="IE=Edge" />
                    <style type="text/css">
                        .wrapper{
                            font-family: sans-serif;
                            width:100%;
                            margin:0px;
                            table-layout:fixed;
                            background-color:#f5f5f5;
                        }
                        .main{
                            width:100%;
                            max-width:600px;
                            margin:0px auto;
                            background-color:white;
                            border-spacing:0px;
                        }
                        {{style}}
                    </style>
                </head>
                <body>
                    <center class="wrapper" >
                        <table class="main" width="100%">
                            <tr>
                                <td style="padding:8px;border-top:3px solid lightgray;">
                                    <img src="' . base_url('assets/images/logo.png') . '" width="120" />
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:3px 0px;background-color:cadetblue;"></td>
                            </tr>
                            <tr>
                                <td style="text-align:center;" >
                                    <h1 style="font-weight:600;font-size:22px;color:dodgerblue">' . $gSettings['company_name'] . '</h1>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:8px;">
                                    <table width="100%" >
                                        <tr>
                                            <td style="text-align:center"><h4 style="font-weight:600;font-size:20px;margin:4px 0px;">{{title}}</h4></td>
                                        </tr>
                                        <tr>
                                            <td>
            ';
    }

    protected function endHeader()
    {
        $gSettings = $this->ci->getData()['g_settings'];
        $this->template .= '
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td style="padding:3px 0px;background-color:cadetblue;"></td>
                </tr>
                <tr>
                    <td style="text-align:center;border-bottom:3px solid lightgray;">
                        <p style="font-size:14px;margin:8px 0px;padding:6px;line-height:20px;color:lightslategray;">
                            ' . $gSettings['address'] . ', <br/>
                            ' . $gSettings['city'] . ', ' . $gSettings['state'] . ' <br/>
                            ' . $gSettings['country'] . ' - ' . $gSettings['zip'] . '<br/>
                        </p>
                    </td>
                </tr>
                </table>
                </center>
                </body>
                </html>
            ';
    }

    public abstract function getStyle();
    public abstract function getTitle();
    public abstract function getBody($config);

    public function createTemplate($config = array())
    {
        $this->startHeader();
        $style = $this->getStyle();
        $this->template = str_replace("{{style}}", $style, $this->template);
        $title = $this->getTitle();
        $this->template = str_replace("{{title}}", $title, $this->template);
        $body = $this->getBody($config);
        $this->template .= $body;
        $this->endHeader();

        return $this->template;
    }
}
