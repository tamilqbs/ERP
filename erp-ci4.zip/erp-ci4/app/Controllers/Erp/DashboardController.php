<?php

namespace App\Controllers\Erp;

use App\Controllers\BaseController;
use App\Models\Erp\ProjectsModel;
use App\Models\Erp\Sale\InvoiceModel;
use App\Models\Erp\Sale\SalePaymentModel;

class DashboardController extends BaseController
{
    protected $projectsModel;
    protected $InvoiceModel;
    protected $logger;
    public function __construct()
    {
        $this->projectsModel = new ProjectsModel();
        $this->InvoiceModel = new InvoiceModel();
        $this->logger = service('log');
    }
    public function index()
    {
        helper('erp');
        $data['statusCounts'] = $this->projectsModel->countStatus();
        $data['leadsCountStatus'] = $this->projectsModel->leadsCountStatus();
        $data['leads2CountStatus'] = $this->projectsModel->leads2CountStatus();
        $data['invoiceCount'] = $this->InvoiceModel->invoiceCount();
        $data['quotationCount'] = $this->InvoiceModel->quotationCount();
        $data['menu'] = "dashboard";
        $data['submenu'] = "";
        $data['page'] = "dashboard/dashboard";
        // $this->logger->error($data);
        return view("erp/index", $data);
    }
    public function orderStatus()
    {
        $salePaymentModel = new SalePaymentModel();
        $data = $salePaymentModel->orderStatus();
        return json_encode($data);
    }
    // public function projectCount()
    // {

    //     return 
    // }
}
