<?php

namespace App\Controllers\Erp;

use App\Controllers\BaseController;
use App\Models\Erp\CustomFieldModel;
use App\Models\Erp\Sale\RequestModel;
// use App\Libraries\Requestor;
use App\Libraries\PdfCreater as LibrariesPdfCreater;
use App\Libraries\Requestor;
use App\Libraries\Requests\AbstractRequest;
use App\Models\Erp\Sale\EstimatesModel;
use App\Libraries\Exporter;
use App\Libraries\Exporter\ExporterConst;
use App\Models\Erp\NotificationModel;
use App\Models\Erp\Sale\OrdersModel;
use App\Models\Erp\Sale\QuotationModel;
use App\Models\Erp\Sale\InvoiceModel;
use App\Models\Erp\Sale\CreditNotesModel;
use App\Models\Erp\Sale\SalePaymentModel;
use App\Models\Erp\Sale\DispatchModel;
use App\Models\Erp\Sale\SaleOrderModel;
use App\Models\Erp\CustomersModel;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\Session\Session;

class SaleController extends BaseController
{
    protected $SaleModel;
    protected $RequestModel;
    protected $CustomFieldModel;
    protected $EstimatesModel;
    protected $NotifyModel;
    protected $OrdersModel;
    protected $InvoiceModel;
    protected $CreditNotesModel;
    protected $QuotationModel;
    protected $SalePaymentModel;
    protected $DispatchModel;
    protected $SaleOrderModel;
    protected $CustomersModel;

    protected $db;
    protected $session;


    public function __construct()
    {
        //parent::__construct();
        helper('erp');
        helper('form');
        //$this->SaleModel = new SaleModel();
        $this->RequestModel = new RequestModel();
        $this->CustomFieldModel = new CustomFieldModel();
        $this->EstimatesModel = new EstimatesModel();
        $this->NotifyModel = new NotificationModel();
        $this->QuotationModel = new QuotationModel();
        $this->OrdersModel = new OrdersModel();
        $this->InvoiceModel = new InvoiceModel();
        $this->CreditNotesModel = new CreditNotesModel();
        $this->SalePaymentModel = new SalePaymentModel();
        $this->DispatchModel = new DispatchModel();
        $this->SaleOrderModel = new SaleOrderModel();
        $this->CustomersModel = new CustomersModel();
        $this->db = \Config\Database::connect();
        $this->session = session();
    }
    //request
    public function Request()
    {
        $data['request_datatable_config'] = $this->RequestModel->getDatatableConfig();
        $data['page'] = "sale/request";
        $data['menu'] = "sale";
        $data['submenu'] = "request";
        return view("erp/index", $data);
    }

    public function convertorderQuote($quote_id)
    {
        $post = [
            'order_expiry' => $this->request->getPost("order_expiry"),
            'code' => $this->request->getPost("code"),
        ];
        if ($this->request->getPost("order_expiry")) {
            if ($this->SaleOrderModel->convert_order_from_quote($quote_id, $post)) {
                return $this->response->redirect(url_to("erp.sale.orders"));
            } else {
                return $this->response->redirect(url_to("erp.sale.quotations", $quote_id));
            }
        }
        return $this->response->redirect(url_to("erp.sale.quotations", $quote_id));
    }

    public function AjaxRequestResponse()
    {
        $response = array();
        $response = $this->RequestModel->getRequestDatatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    // Request Add
    public function Requestadd()
    {
        if ($this->request->getPost("request_type")) {
            $requestor = new Requestor($this->request->getPost("request_type"));
            if ($requestor->request(true)) {
                return $this->response->redirect(url_to('erp.sale.requests'));
            } else {
                return $this->response->redirect(url_to('erp.sale.requests.edit'));
            }
        }

        $requestor = new Requestor();
        $data['requesttypes'] = $requestor->getRequestTypes("Sales");
        $data['attach_filetypes'] = $requestor->getAllowedFileTypes();
        $data['attach_maxfilesize'] = $requestor->getMaxFileSize();
        $data['page'] = "sale/requestadd";
        $data['menu'] = "sale";
        $data['submenu'] = "request";

        return view("erp/index", $data);
    }

    public function requestaction($request_id)
    {
        if ($_POST["action"]) {
            $this->RequestModel->process_requestaction($request_id);
        }
        redirect("erp/sale/requestview/" . $request_id);
    }

    // Code for Estimates
    public function Estimates()
    {

        $data['estimate_datatable_config'] = $this->EstimatesModel->getDtconfigEstimates();
        $data['page'] = "sale/estimates";
        $data['menu'] = "sale";
        $data['submenu'] = "estimate";
        return view("erp/index", $data);
    }

    public function ajax_estimate_response()
    {
        $response = array();
        $response = $this->EstimatesModel->getEstimateDatatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    // Add
    public function EstimateAdd()
    {
        if ($this->request->getPost("code")) {
            $created_by = get_user_id();

            $dataPost = [
                'code' => $this->request->getPost("code"),
                'cust_id' => $this->request->getPost("cust_id"),
                'estimate_date' => $this->request->getPost("estimate_date"),
                'shippingaddr_id' => $this->request->getPost("shippingaddr_id"),
                'terms_condition' => $this->request->getPost("terms_condition"),
                'created_at' => time(),
                'updated_at' => time(),
                'created_by' => $created_by,
            ];

            // return var_dump($dataPost);
            if ($this->EstimatesModel->insertEstimate($dataPost)) {
                return $this->response->redirect(url_to('erp.sale.estimates'));
            } else {
                return $this->response->redirect(url_to('erp.sale.estimates.add'));
            }
        }
        $data['page'] = "sale/m_estimateadd";
        $data['menu'] = "sale";
        $data['submenu'] = "estimate";
        return view("erp/index", $data);
    }

    public function estimateExport()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Estimates";
        if ($type == "pdf") {
            $config['column'] = array("Code", "Customer", "Shipping Address", "Estimate Date", "Total Amount", "Terms and Condition");
        } else {
            $config['column'] = array("Code", "Customer", "Shipping Address", "Estimate Date", "Total Amount", "Terms and Condition");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->EstimatesModel->get_estimate_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }


    // View
    public function EstimateView($estimate_id)
    {
        $user_email = session()->get('erp_email');
        $user_name =  session()->get('erp_username');
        $data['estimate'] = $this->EstimatesModel->get_m_estimate_for_view($estimate_id);
        if (empty($data['estimate'])) {
            session()->setflashdata("op_error", "Estimate Not Found");
            redirect("erp/sale/estimates");
        }
        $data['estimate_id'] = $estimate_id;
        $data['estimate_items'] = $this->EstimatesModel->get_estimate_items_for_view($estimate_id);
        $data['notify_datatable_config'] = $this->EstimatesModel->get_dtconfig_notify();
        $data['attachments'] = $this->EstimatesModel->get_attachments("estimate", $estimate_id);
        $data['user_email'] = $user_email;
        $data['user_name'] = $user_name;
        $data['page'] = "sale/m_estimateview";
        $data['menu'] = "sale";
        $data['submenu'] = "estimate";
        return view("erp/index", $data);
    }

    // Estimate Edit
    public function EstimateEdit($estimate_id)
    {
        if ($this->request->getPost("code")) {
            $data['product_ids'] = $this->request->getPost("product_id");
            $data['quantities'] = $this->request->getPost("quantity");
            $data['price_ids'] = $this->request->getPost("price_id");
            if ($this->EstimatesModel->updateEstimates($estimate_id, $data)) {
                return $this->response->redirect(url_to('erp.sale.estimates'));
            } else {
                // redirect("erp/sale/estimateedit/".$estimate_id);
                return $this->response->redirect(url_to('erp.sale.estimates.edit', $estimate_id));
            }
        }
        $data['estimate'] = $this->EstimatesModel->get_m_estimate_by_id($estimate_id);
        if (empty($data['estimate'])) {
            $this->session->setFlashdata("op_error", "Estimate Not Found");
            return $this->response->redirect(url_to('erp.sale.estimates'));
        }
        $data['shippingaddr'] = $this->EstimatesModel->get_m_shipping_addr($data['estimate']->cust_id);
        $data['estimate_items'] = $this->EstimatesModel->get_m_estimate_items($estimate_id);
        $data['page'] = "sale/m_estimateedit";
        $data['estimate_id'] = $estimate_id;
        $data['menu'] = "sale";
        $data['submenu'] = "estimate";
        return view("erp/index", $data);
    }

    // Estimate Delete
    //IMPLEMENTED BY ASHOK
    public function EstimateDelete($estimate_id)
    {

        $estimate = $this->EstimatesModel->get_m_estimate_by_id($estimate_id);

        if (empty($estimate)) {
            session()->setFlashdata("op_error", "Estimate Not Found");
            return $this->response->redirect(url_to('erp.sale.estimates'));
        }

        $deleted = $this->EstimatesModel->DeleteEstimate($estimate_id);

        if ($deleted) {
            // Equipment successfully deleted
            session()->setFlashdata("op_success", "Equipment successfully deleted");
        } else {
            // Failed to delete Estimate
            session()->setFlashdata("op_error", "Equipment failed to delete");
        }

        return $this->response->redirect(url_to('erp.sale.estimates'));
    }

    // Upload Attachements
    public function uploadEstimateAttachment()
    {
        $response = array();
        if (!empty($_FILES['attachment']['name'])) {
            $response = $this->EstimatesModel->upload_attachment("estimate");
        } else {
            $response['error'] = 1;
            $response['reason'] = "No file to upload";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }
    // Delete Attachements
    public function deleteEstimateAttachment()
    {
        $response = array();
        $response = $this->EstimatesModel->delete_attachment("estimate");
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    // Customer Fetch
    public function ajaxFetchCustomers()
    {
        $search = $_GET['search'] ?? "";
        $response = array();
        $response['error'] = 1;
        if (!empty($search)) {
            $query = "SELECT cust_id,CONCAT(name,' - ',company) AS name FROM customers WHERE name LIKE '%" . $search . "%' OR company LIKE '%" . $search . "%' LIMIT 10";
            $result = $this->db->query($query)->getResultArray();
            $m_result = array();
            foreach ($result as $r) {
                array_push($m_result, array(
                    "key" => $r['cust_id'],
                    "value" => $r['name']
                ));
            }
            $response['error'] = 0;
            $response['data'] = $m_result;
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    // fetch Shipping address
    public function ajaxFetchShippingAddr()
    {
        $cust_id = $_GET['cust_id'] ?? 0;
        $response = array();
        $response['error'] = 1;
        if (!empty($cust_id)) {
            $query = "SELECT shippingaddr_id,CONCAT(address,' , ',city) AS name FROM customer_shippingaddr WHERE cust_id=$cust_id ";
            $result = $this->db->query($query)->getResultArray();
            $m_result = array();
            foreach ($result as $r) {
                array_push($m_result, array(
                    "key" => $r['shippingaddr_id'],
                    "value" => $r['name']
                ));
            }
            $response['error'] = 0;
            $response['data'] = $m_result;
        } else {
            $response['reason'] = "No shipping address";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    // Price List
    public function ajaxFetchPriceList()
    {
        $product_id = $_GET['product_id'] ?? 0;
        //echo var_dump($product_id);
        // exit();
        $response = array();
        $response['error'] = 1;
        if (!empty($product_id)) {
            $query = "SELECT stocks.price_id,price_list.amount,price_list.name,SUM(stocks.quantity) AS quantity FROM stocks JOIN price_list ON stocks.price_id=price_list.price_id WHERE stocks.related_id=$product_id AND stocks.related_to='finished_good' GROUP BY stocks.price_id";
            $result = $this->db->query($query)->getResultArray();
            $m_result = array();
            foreach ($result as $r) {
                $extra = array();
                array_push($extra, $r['amount']);
                array_push($extra, $r['quantity']);
                array_push($m_result, array(
                    "key" => $r['price_id'],
                    "value" => $r['name'],
                    "extra" => $extra
                ));
            }
            $response['error'] = 0;
            $response['data'] = $m_result;
        } else {
            $response['reason'] = "No Price List";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxEstimateCodeUnique()
    {
        $code = $_GET['data'];
        $id = $_GET['id'] ?? 0;
        $query = "SELECT code FROM estimates WHERE code='$code' LIMIT 1";
        if (!empty($id)) {
            $query = "SELECT code FROM estimates WHERE code='$code' AND estimate_id<>$id LIMIT 1";
        }
        $check = $this->db->query($query)->getRow();
        $response = array();
        if (empty($check)) {
            $response['valid'] = 1;
        } else {
            $response['valid'] = 0;
            $response['msg'] = "Estimate Code already exists";
        }
        header("content-type:application/json");
        echo json_encode($response);
        exit();
    }
    // Notify Response List Estimates
    public function ajaxEstimatenotifyResponse()
    {
        $response = array();
        $response = $this->EstimatesModel->getEstimatenotifyDatatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxFetchNotify($notify_id)
    {
        $response = array();
        $query = "SELECT notify_id,notify_email,title,notify_text,notify_at,erp_users.user_id,erp_users.name FROM notification JOIN erp_users ON notification.user_id=erp_users.user_id WHERE notify_id=$notify_id";
        $result = $this->db->query($query)->getRow();
        if (!empty($result)) {
            $response['error'] = 0;
            $result->notify_at = date("Y-m-d\TH:i", $result->notify_at);
            $response['data'] = $result;
        } else {
            $response['error'] = 1;
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function estimatenotifydelete($estimate_id, $notify_id)
    {
        $this->EstimatesModel->delete_estimate_notify($estimate_id, $notify_id);
        return $this->response->redirect(url_to('erp.sale.estimates.view', $estimate_id));
    }

    public function estimateNotifyExport()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Estimate Notification";
        if ($type == "pdf") {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
        } else {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->EstimatesModel->get_estimatenotify_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }

    // Estimate Notify Add
    public function EstimateNotifyAdd($estimate_id)
    {
        if ($_POST["notify_title"]) {
            $this->NotifyModel->insert_update_estimatenotify($estimate_id);
            // exit('Insertion Happened');
        }
        // var_dump($_POST);
        // var_dump($_GET);
        // exit('Insertion Not Happened');
        return $this->response->redirect(url_to('erp.sale.estimates.view', $estimate_id));
    }

    // Quotation 
    public function Quotation()
    {
        $data['quote_status'] = $this->QuotationModel->get_quote_status();
        $data['quotation_datatable_config'] = $this->QuotationModel->get_dtconfig_quotations();
        $data['page'] = "sale/quotations";
        $data['menu'] = "sale";
        $data['submenu'] = "quotation";
        return view("erp/index", $data);
    }

    public function QuotationAdd()
    {
        $inserted = false;
        $logger = \Config\Services::logger();

        // $logger->error($_POST);
        $data['code'] = $this->request->getPost("code");
        $data['cust_id'] = $this->request->getPost("cust_id");
        $data['estimate_date'] = $this->request->getPost("quote_date");
        $data['shippingaddr_id'] = $this->request->getPost("shippingaddr_id");
        $data['terms_condition'] = $this->request->getPost("terms_condition");
        $data['payment_terms'] = $this->request->getPost("payment_terms");
        $data['transport_req'] = $this->request->getPost("transport_req") ?? 0;
        $data['trans_charge'] = $this->request->getPost("trans_charge");
        $data['discount'] = $this->request->getPost("discount");
        $data['created_by'] = get_user_id();
        if ($data['code']) {
            if ($this->QuotationModel->insert_quotation($data)) {
                return $this->response->redirect(url_to('erp.sale.quotations'));
            } else {
                return $this->response->redirect(url_to('erp.sale.quotation.add'));
            }
        }
        $data['page'] = "sale/quotationadd";
        $data['menu'] = "sale";
        $data['submenu'] = "quotation";
        return view("erp/index", $data);
    }

    public function QuotationEdit($quote_id)
    {
        if ($this->request->getPost("code")) {
            if ($this->QuotationModel->update_quotation($quote_id)) {
                return $this->response->redirect(url_to('erp.sale.quotations'));
            } else {
                return $this->response->redirect(url_to('erp.sale.quotations.edit', $quote_id));
            }
        }
        $data['quotation'] = $this->QuotationModel->get_quotation_by_id($quote_id);
        if (empty($data['quotation'])) {
            $this->session->setFlashdata("op_error", "Quotation Not Found");
            return $this->response->redirect(url_to('erp.sale.quotations'));
        }
        $data['shipping_addr'] = $this->QuotationModel->get_m_shipping_addr($data['quotation']->cust_id);
        $data['quote_items'] = $this->QuotationModel->get_quotation_items($quote_id);
        $data['quote_id'] = $quote_id;
        $data['page'] = "sale/quotationedit";
        $data['menu'] = "sale";
        $data['submenu'] = "quotation";
        return view("erp/index", $data);
    }

    public function QuotationView($quote_id)
    {
        $user_email = session()->get('erp_email');
        $user_name =  session()->get('erp_username');
        $data['quotation'] = $this->QuotationModel->get_quotation_for_view($quote_id);
        if (empty($data['quotation'])) {
            $this->session->setFlashdata("op_error", "Quotation Not Found");
            redirect("erp/sale/quotations");
        }
        $data['quote_status'] = $this->QuotationModel->get_quote_status();
        $data['quote_status_bg'] = $this->QuotationModel->get_quote_status_bg();
        $data['quote_id'] = $quote_id;
        $data['quotation_items'] = $this->QuotationModel->get_quotation_items_for_view($quote_id);
        $data['notify_datatable_config'] = $this->QuotationModel->get_dtconfig_notify();
        $data['attachments'] = $this->QuotationModel->get_attachments("quotation", $quote_id);
        $data['user_email'] = $user_email;
        $data['user_name'] = $user_name;
        $data['page'] = "sale/quotationview";
        $data['menu'] = "sale";
        $data['submenu'] = "quotation";
        return view("erp/index", $data);
    }
    // End of CRUD

    // Notification
    public function ajax_quotationnotify_response()
    {
        $response = array();
        $response = $this->QuotationModel->get_quotationnotify_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function quotationnotify($quote_id)
    {
        if ($this->request->getPost("notify_title")) {
            $this->NotifyModel->insert_update_quotationnotify($quote_id);
        }
        return $this->response->redirect(url_to('erp.sale.quotations.view', $quote_id));
    }

    public function quotationnotifydelete($quote_id, $notify_id)
    {
        $this->NotifyModel->delete_quotation_notify($quote_id, $notify_id);
        return $this->response->redirect(url_to('erp.sale.quotations.view', $quote_id));
    }


    public function quotation_notify_export()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Quotation Notification";
        if ($type == "pdf") {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
        } else {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->NotifyModel->get_quotationnotify_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }
    // QuoteNotification
    public function quotationaccept($quote_id)
    {
        $this->QuotationModel->accept_quotation($quote_id);
        return $this->response->redirect(url_to('erp.sale.quotations.view', $quote_id));
    }

    public function quotationdecline($quote_id)
    {
        $this->QuotationModel->decline_quotation($quote_id);
        return $this->response->redirect(url_to('erp.sale.quotations.view', $quote_id));
    }

    public function ajax_quotations_response()
    {
        $response = array();
        $response = $this->QuotationModel->get_quotation_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajax_quotation_code_unique()
    {
        $code = $_GET['data'];
        $id = $_GET['id'] ?? 0;
        $query = "SELECT code FROM quotations WHERE code='$code' LIMIT 1";
        if (!empty($id)) {
            $query = "SELECT code FROM quotations WHERE code='$code' AND quote_id<>$id LIMIT 1";
        }
        $check = $this->db->query($query)->getRow();
        $response = array();
        if (empty($check)) {
            $response['valid'] = 1;
        } else {
            $response['valid'] = 0;
            $response['msg'] = "Quotation Code already exists";
        }
        header("content-type:application/json");
        echo json_encode($response);
        exit();
    }

    public function upload_quoteattachment()
    {
        $response = array();
        if (!empty($_FILES['attachment']['name'])) {
            $response = $this->QuotationModel->upload_attachment("quotation");
        } else {
            $response['error'] = 1;
            $response['reason'] = "No file to upload";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function quote_delete_attachment()
    {
        $response = array();
        $response = $this->QuotationModel->delete_attachment("quotation");
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function QuotationExport()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Quotations";
        if ($type == "pdf") {
            $config['column'] = array("Code", "Customer", "Quotation Date", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount");
        } else {
            $config['column'] = array("Code", "Customer", "Shipping Address", "Quotation Date", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount", "Payment Terms", "Terms Condition");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->QuotationModel->get_quotation_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }

    //Quotation Delete Implemented

    public function quotation_delete($quote_id)
    {

        $QuotationModel = new QuotationModel();
        $quotation = $QuotationModel->get_quote_by_id($quote_id);

        if (empty($quotation)) {
            session()->setFlashdata("op_error", "Quotation Not Found");
            return $this->response->redirect(url_to('erp.sale.quotations'));
        }


        $deleted = $QuotationModel->delete_Quotation($quote_id);

        if ($deleted) {

            session()->setFlashdata("op_success", "Quotation successfully deleted");
        } else {

            session()->setFlashdata("op_error", "Quotation failed to delete");
        }
        return $this->response->redirect(url_to('erp.sale.quotations'));
    }




    // Orders Starts From Here
    public function Orders()
    {
        if (is_manufacturing_system()) {
            $data['order_status'] = $this->OrdersModel->get_order_status();
            $data['order_datatable_config'] = $this->OrdersModel->get_dtconfig_m_orders();
            $data['page'] = "sale/m_orders";
        } else {
            $data['order_status'] = $this->OrdersModel->get_order_status();
            $data['order_datatable_config'] = $this->OrdersModel->get_dtconfig_c_orders();
            $data['page'] = "sale/c_orders";
        }
        $data['menu'] = "sale";
        $data['submenu'] = "order";
        return view("erp/index", $data);
    }

    public function ajax_m_order_response()
    {
        $response = array();
        $response = $this->OrdersModel->get_m_order_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajax_c_order_response()
    {
        $response = array();
        $response = $this->OrdersModel->get_c_order_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxFetchOrders()
    {
        if (is_manufacturing_system()) {
            $this->ajax_m_order_response();
        } else {
            $this->ajax_c_order_response();
        }
    }


    public function OrderAdd()
    {
        if (is_manufacturing_system()) {
            if ($this->request->getPost("code")) {
                $updated = true;
                $data['product_ids'] = $this->request->getPost("product_id");
                $data['quantities'] = $this->request->getPost("quantity");
                $data['price_ids'] = $this->request->getPost("price_id");
                if ($this->OrdersModel->insert_m_order()) {

                    return $this->response->redirect(url_to('erp.sale.orders'));
                } else {
                    return $this->response->redirect(url_to('erp.sale.orders.orderadd'));
                }
            }
            $data['page'] = "sale/m_orderadd";
        } else {
            if ($this->request->getPost("code")) {
                if ($this->OrdersModel->insert_c_order()) {
                    return $this->response->redirect(url_to('erp.sale.orders'));
                } else {
                    return $this->response->redirect(url_to('erp.sale.orders.orderadd'));
                }
            }
            $data['page'] = "sale/c_orderadd";
        }
        $data['menu'] = "sale";
        $data['submenu'] = "order";
        return view("erp/index", $data);
    }

    public function ajax_order_code_unique()
    {
        $code = $_GET['data'];
        $id = $_GET['id'] ?? 0;
        $query = "SELECT code FROM sale_order WHERE code='$code' LIMIT 1";
        if (!empty($id)) {
            $query = "SELECT code FROM sale_order WHERE code='$code' AND order_id<>$id LIMIT 1";
        }
        $check = $this->db->query($query)->getRow();
        $response = array();
        if (empty($check)) {
            $response['valid'] = 1;
        } else {
            $response['valid'] = 0;
            $response['msg'] = "Order Code already exists";
        }
        header("content-type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxfetchproperties()
    {
        $search = $_GET['search'] ?? "";
        $response = array();
        $response['error'] = 1;
        if (!empty($search)) {
            $query = "SELECT property_id,name FROM properties WHERE name LIKE '%" . $search . "%' LIMIT 10";
            $result = $this->db->query($query)->getResultArray();
            $m_result = array();
            foreach ($result as $r) {
                array_push($m_result, array(
                    "key" => $r['property_id'],
                    "value" => $r['name']
                ));
            }
            $response['error'] = 0;
            $response['data'] = $m_result;
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxfetchpropertyunits()
    {
        $property_id = $_GET['property_id'] ?? "";
        $order_id = $_GET['order_id'] ?? 0;
        $response = array();
        $response['error'] = 1;
        if (!empty($property_id)) {
            $query = "SELECT prop_unit_id,unit_name,price FROM property_unit WHERE property_id=$property_id AND status=0";
            if (!empty($order_id)) {
                $query = "SELECT prop_unit_id,unit_name,price FROM property_unit WHERE property_id=$property_id AND ( status=0 OR EXISTS (SELECT sale_item_id FROM sale_order_items WHERE order_id=$order_id AND related_id=property_unit.prop_unit_id))";
            }
            $result = $this->db->query($query)->getResultArray();
            $m_result = array();
            foreach ($result as $r) {
                $extra = array();
                array_push($extra, $r['price']);
                array_push($m_result, array(
                    "key" => $r['prop_unit_id'],
                    "value" => $r['unit_name'],
                    "extra" => $extra
                ));
            }
            $response['error'] = 0;
            $response['data'] = $m_result;
        } else {
            $response['reason'] = "No property units";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    //edit order

    public function SaleOrderEdit($order_id)
    {
        if (is_manufacturing_system()) {
            if ($this->request->getPost("code")) {
                if ($this->OrdersModel->update_m_order($order_id)) {
                    return $this->response->redirect(url_to("erp.sale.orders"));
                } else {
                    return $this->response->redirect(url_to("erp.sale.order.edit",  $order_id));
                }
            }
            $data['order'] = $this->OrdersModel->get_m_order_by_id($order_id);
            if (empty($data['order'])) {
                $this->session->setFlashdata("op_error", "Order Not Found");
                redirect("erp/sale/orders");
            }
            $data['shippingaddr'] = $this->OrdersModel->get_m_shipping_addr($data['order']->cust_id);
            $data['order_items'] = $this->OrdersModel->get_m_order_items($order_id);
            $data['page'] = "sale/m_orderedit";
        } else {
            if ($_POST["code"]) {
                $updated = false;
                $data['code'] = $this->request->getPost("code");
                $data['cust_id'] = $this->request->getPost("cust_id");
                $data['order_date'] = $this->request->getPost("order_date");
                $data['terms_condition'] = $this->request->getPost("terms_condition");
                $data['payment_terms'] = $this->request->getPost("payment_terms");
                $data['discount'] = $this->request->getPost("discount");
                $data['order_expiry'] = $this->request->getPost("order_expiry");
                if ($this->OrdersModel->update_c_order($order_id, $data)) {
                    redirect("erp/sale/orders");
                } else {
                    redirect("erp/sale/orderedit/" . $order_id);
                }
            }
            $data['order'] = $this->OrdersModel->get_c_order_by_id($order_id);
            if (empty($data['order'])) {
                session()->setFlashdata("op_error", "Order Not Found");
                redirect("erp/sale/orders");
            }
            $data['order_items'] = $this->OrdersModel->get_c_order_items($order_id);
            $data['page'] = "sale/c_orderedit";
        }
        $data['order_id'] = $order_id;
        $data['menu'] = "sale";
        $data['submenu'] = "order";
        return view("erp/index", $data);
    }

    // View Order
    public function OrderView($order_id)
    {
        $user_email = session()->get('erp_email');
        $user_name =  session()->get('erp_username');
        if (is_manufacturing_system()) {

            $data['order'] = $this->OrdersModel->get_m_order_for_view($order_id);
            if (empty($data['order'])) {
                $this->session->setFlashdata("op_error", "Order Not Found");
                redirect("erp/sale/orders");
            }
            $data['stock_pick'] = $this->OrdersModel->get_m_stock_pick($order_id);
            $data['order_items'] = $this->OrdersModel->get_m_order_items_for_view($order_id);
            if ($data['order']->stock_pick == 1) {
                $data['stock_entry'] = $this->OrdersModel->get_stock_pick_items($order_id);
            }
            $data['page'] = "sale/m_orderview";
        } else {
            $data['order'] = $this->OrdersModel->get_c_order_for_view($order_id);
            if (empty($data['order'])) {
                $this->session->setFlashdata("op_error", "Order Not Found");
                redirect("erp/sale/orders");
            }
            $data['order_items'] = $this->OrdersModel->get_c_order_items_for_view($order_id);
            $data['page'] = "sale/c_orderview";
        }
        $data['notify_datatable_config'] = $this->OrdersModel->get_dtconfig_notify();
        $data['attachments'] = $this->OrdersModel->get_attachments("sale_order", $order_id);
        $data['order_status'] = $this->OrdersModel->get_order_status();
        $data['order_status_bg'] = $this->OrdersModel->get_order_status_bg();
        $data['dispatch_datatable_config'] = $this->DispatchModel->get_dtconfig_m_dispatch();

        $data['dispatch_status'] = $this->DispatchModel->get_dispatch_status();
        $data['dispatch_status_bg'] = $this->DispatchModel->get_dispatch_status_bg();

        $logger = \Config\Services::logger();
        $logger->error($data['dispatch_status']);
        $logger->error($data['dispatch_status_bg']);
        $data['order_id'] = $order_id;
        $data['user_email'] = $user_email;
        $data['user_name'] = $user_name;
        $data['menu'] = "sale";
        $data['submenu'] = "order";
        return view("erp/index", $data);
    }
    //delete

    public function orderdelete($order_id)
    {
        $OrdersModel = new OrdersModel();

        $order = $OrdersModel->get_order_by_id($order_id);

        if (empty($order)) {
            session()->setFlashdata("op_error", "Stock Not Found");
            return $this->response->redirect(url_to('erp.warehouse.managestock.delete'));
        }


        $deleted = $OrdersModel->delete_orders($order_id);

        if ($deleted) {

            session()->setFlashdata("op_success", "Stock successfully deleted");
        } else {

            session()->setFlashdata("op_error", "Stock failed to delete");
        }


        return $this->response->redirect(url_to('erp.warehouse.managestock'));
    }


    public function OrderExport()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Sale Order";
        if (is_manufacturing_system()) {
            if ($type == "pdf") {
                $config['column'] = array("Code", "Customer", "Order Date", "Order Expiry", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount");
            } else {
                $config['column'] = array("Code", "Customer", "Shipping Address", "Order Date", "Order Expiry", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount", "Payment Terms", "Terms Condition");
                $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
            }
            $config['data'] = $this->OrdersModel->get_m_order_export($type);
        } else {
            if ($type == "pdf") {
                $config['column'] = array("Code", "Customer", "Order Date", "Order Expiry", "Status", "Discount", "Total Amount");
            } else {
                $config['column'] = array("Code", "Customer", "Order Date", "Order Expiry", "Status", "Discount", "Total Amount", "Payment Terms", "Terms Condition");
                $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
            }
            $config['data'] = $this->OrdersModel->get_c_order_export($type);
        }
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }


    public function OrderViewExport()
    {
        $type = $_GET['export'];
        $config = [];
        $config['title'] = "Sale Order";

        if (is_manufacturing_system()) {
            $config['column'] = ["Code", "Customer", "Shipping Address", "Order Date", "Order Expiry", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount"];
        } else {
            $config['column'] = ["Code", "Customer", "Order Date", "Order Expiry", "Status", "Discount", "Total Amount", "Payment Terms", "Terms Condition"];
            $config['column_data_type'] = [ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING];
        }

        if (is_manufacturing_system()) {
            $config['data'] = $this->OrdersModel->get_m_order_export($type);
        } else {
            $config['data'] = $this->OrdersModel->get_c_order_export($type);
        }

        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        }
    }



    public function upload_orderattachment()
    {
        $response = array();
        if (!empty($_FILES['attachment']['name'])) {
            $response = $this->OrdersModel->upload_attachment("sale_order");
        } else {
            $response['error'] = 1;
            $response['reason'] = "No file to upload";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function order_delete_attachment()
    {
        $response = array();
        $response = $this->OrdersModel->delete_attachment("sale_order");
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    //notify export

    public function order_notify_export()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Sale Order Notification";
        if ($type == "pdf") {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
        } else {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->OrdersModel->get_ordernotify_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }
    // ORDER notify

    public function ordernotify($order_id)
    {
        if ($_POST["notify_title"]) {
            $this->OrdersModel->insert_update_ordernotify($order_id);
        }
        return $this->response->redirect(url_to("erp.sale.orders.view",  $order_id));
    }

    public function ajax_ordernotify_response()
    {
        $response = array();
        $response = $this->OrdersModel->get_ordernotify_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ordernotifydelete($order_id, $notify_id)
    {
        $this->OrdersModel->delete_order_notify($order_id, $notify_id);
        return $this->response->redirect(url_to("erp.sale.orders.view",  $order_id));
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////

    //Dispatch Implemented Ta
    public function Dispatch()
    {
        $data['dispatch_status'] = $this->DispatchModel->get_dispatch_status();
        $data['dispatch_datatable_config'] = $this->DispatchModel->get_dtconfig_m_dispatch();
        $data['page'] = "sale/m_orderview";
        $data['menu'] = "sale";
        $data['submenu'] = "dispatch";
        return view("erp/index", $data);
    }

    public function ajax_order_dispatch_response()
    {
        $response = array();
        $limit = $this->request->getGet('limit');
        $offset = $this->request->getGet('offset');
        $search = $this->request->getGet('search') ?? "";
        // Handle 'orderby' possibly being null
        $orderby = $this->request->getGet('orderby') ?? "";
        $orderby = $orderby !== null ? strtoupper($orderby) : "";
        $ordercolPost = $this->request->getGet('ordercol');
        $status = $this->request->getGet('status');
        // var_dump($_GET);
        // exit();
        $response = $this->DispatchModel->get_Sale_Dispatch_Datatable($limit, $offset, $search, $orderby, $ordercolPost, $status);
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    //Dispatch ADD 

    public function DispatchAdd($order_id)
    {
        $logger = \Config\Services::logger();


        $dataPost = [
            'order_id' => $order_id,
            'order_code' => $this->request->getPost("order_code"),
            'customer' => $this->request->getPost("customer_name"),
            'delivery_date' => $this->request->getPost("delivery_date"),
            'description' => $this->request->getPost("dispatch_desc"),
            'status' => $this->request->getPost("dispatch_status"),
            'cust_id' => $this->request->getPost("cust_id"),
            'created_at' => time(),
            'updated_at' => time(),
        ];

        if ($this->request->getPost("order_code")) {
            if ($this->DispatchModel->insertdispatch($dataPost)) {
                return $this->response->redirect(url_to('erp.sale.orders.view', $order_id));
            } else {
                return $this->response->redirect(url_to('erp.sale.orders.view', $order_id));
            }
        } else {
            session()->setFlashdata("op_error", "There was an Error");
            return $this->response->redirect(url_to('erp.sale.orders.view', $order_id));
        }
    }

    //Dispatch Export

    public function DispatchOrderExport()
    {
        $type = $this->request->getGet('export');
        $limit = $this->request->getGet('limit');
        $offset = $this->request->getGet('offset');
        $search = $this->request->getGet('search') ?? "";
        // Handle 'orderby' possibly being null
        $orderby = $this->request->getGet('orderby') ?? "";
        $orderby = $orderby !== null ? strtoupper($orderby) : "";
        $ordercolPost = $this->request->getGet('ordercol');
        $status = $this->request->getGet('status');

        $config = [];

        $config['title'] = "dispatch";

        if ($type == "pdf") {
            $config['column'] = ["Order Code", "Customer", "Delivery Date", "description", "Status"];
        } else {
            $config['column'] = ["Order Code", "Customer", "Delivery Date", "Description", "Status"];
            $config['column_data_type'] = [ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING];
        }

        $DispatchModel = new DispatchModel();
        $config['data'] =  $this->DispatchModel->get_dispatch_order_export($type, $limit, $offset, $search, $orderby, $ordercolPost, $status);

        if ($type == "pdf") {
            return Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            return Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            return Exporter::export(ExporterConst::CSV, $config);
        }
    }

    public function DeleteSaleDispatch($dispatch_id)
    {

        $dispatch = $this->DispatchModel->get_dispatch_by_id($dispatch_id);

        if (empty($dispatch)) {
            session()->setFlashdata("op_error", "Dispatch Not Found");
            return redirect()->to('erp/asset/equipments');
        }

        // Attempt to delete the Dispatch
        $deleted = $this->DispatchModel->Delete_Sale_Dispatch($dispatch_id);

        if ($deleted) {
            // Dispatch successfully deleted
            session()->setFlashdata("op_success", "Dispatch successfully deleted");
        } else {
            // Failed to delete Dispatch
            session()->setFlashdata("op_error", "Dispatch failed to delete");
        }

        // Redirect to the Dispatch list page
        return $this->response->redirect(url_to('erp.sale.orders'));
    }











    /////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Invoice sale
    public function Invoices()
    {
        if (is_manufacturing_system()) {
            $data['invoice_datatable_config'] = $this->InvoiceModel->get_dtconfig_m_invoices();
            $data['page'] = "sale/m_invoices";
        } else {
            $data['invoice_datatable_config'] = $this->InvoiceModel->get_dtconfig_c_invoices();
            $data['page'] = "sale/c_invoices";
        }
        $data['invoice_status'] = $this->InvoiceModel->get_invoice_status();
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }

    public function AjaxInvoiceResponse()
    {
        $response = array();
        $response = $this->InvoiceModel->get_c_invoice_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    //invoice view

    public function InvoiceView($invoice_id)
    {
        $user_email = session()->get('erp_email');
        $user_name =  session()->get('erp_username');
        if (is_manufacturing_system()) {
            $data['invoice'] = $this->InvoiceModel->get_m_invoice_for_view($invoice_id);
            
            $data['applied_credits'] = $this->CreditNotesModel->getAppliedCreditsByInvoiceId($invoice_id);
            // var_dump($data['applied_credits']);
            if (empty($data['invoice'])) {
                $this->session->setFlashdata("op_error", "Invoice Not Found");
                redirect("erp/sale/invoices");
            }
            $data['invoice_items'] = $this->InvoiceModel->get_m_invoice_items_for_view($invoice_id);
            $data['page'] = "sale/m_invoiceview";
        } else {
            $data['invoice'] = $this->InvoiceModel->get_c_invoice_for_view($invoice_id);
            if (empty($data['invoice'])) {
                $this->session->setFlashdata("op_error", "Invoice Not Found");
                redirect("erp/sale/invoices");
            }
            $data['invoice_items'] = $this->InvoiceModel->get_c_invoice_items_for_view($invoice_id);
            $data['page'] = "sale/c_invoiceview";
        }
        $data['paymentmodes'] = $this->InvoiceModel->get_all_paymentmodes();
        $data['payment_datatable_config'] = $this->InvoiceModel->get_dtconfig_payments();
        $data['notify_datatable_config'] = $this->InvoiceModel->get_dtconfig_notify();
        $data['attachments'] = $this->InvoiceModel->get_attachments("sale_invoice", $invoice_id);
        $data['invoice_status'] = $this->InvoiceModel->get_invoice_status();
        $data['invoice_status_bg'] = $this->InvoiceModel->get_invoice_status_bg();
        $data['invoice_id'] = $invoice_id;
        $data['user_email'] = $user_email;
        $data['user_name'] = $user_name;
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }

    public function AjaxInvoiceResponseManufature()
    {
        $response = array();
        $response = $this->InvoiceModel->get_m_invoice_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }




    //Export

    public function invoice_export()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Sale Invoice";
        if (is_manufacturing_system()) {
            if ($type == "pdf") {
                $config['column'] = array("Code", "Customer", "Invoice Date", "Invoice Expiry", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount");
            } else {
                $config['column'] = array("Code", "Customer", "Shipping Address", "Invoice Date", "Invoice Expiry", "Status", "Transport Requested", "Transport Charge", "Discount", "Total Amount", "Payment Terms", "Terms Condition");
                $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
            }
            $config['data'] = $this->InvoiceModel->get_m_invoice_export($type);
        } else {
            if ($type == "pdf") {
                $config['column'] = array("Code", "Customer", "Invoice Date", "Invoice Expiry", "Status", "Discount", "Total Amount");
            } else {
                $config['column'] = array("Code", "Customer", "Invoice Date", "Invoice Expiry", "Status", "Discount", "Total Amount", "Payment Terms", "Terms Condition");
                $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
            }
            $config['data'] = $this->InvoiceModel->get_c_invoice_export($type);
        }
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }


    //invoiceadd
    public function invoiceadd()
    {

        $data['code'] = $this->request->getpost("code");
        $data['cust_id'] = $this->request->getpost("cust_id");
        $data['invoice_date'] = $this->request->getpost("invoice_date");
        $data['shippingaddr_id'] = $this->request->getpost("shippingaddr_id");
        $data['terms_condition'] = $this->request->getpost("terms_condition");
        $data['payment_terms'] = $this->request->getpost("payment_terms");
        $data['transport_req'] = $this->request->getpost("transport_req") ?? 0;
        $data['trans_charge'] = $this->request->getpost("trans_charge");
        $data['discount'] = $this->request->getpost("discount");
        $data['invoice_expiry'] = $this->request->getpost("invoice_expiry");
        $data['status'] = $this->request->getpost("status");
        $data['created_by'] = get_user_id();
        $data['product_ids'] = $this->request->getpost("product_id");
        $data['quantities'] = $this->request->getpost("quantity");
        $data['price_ids'] = $this->request->getpost("price_id");
        if (is_manufacturing_system()) {
            if ($this->request->getpost("code")) {
                if ($this->InvoiceModel->insert_m_invoice($data)) {
                    return $this->response->redirect(url_to('erp.sale.invoice'));
                } else {
                    return $this->response->redirect(url_to('erp.sale.invoice.add'));
                }
            }
            $data['page'] = "sale/m_invoiceadd";
        } else {
            if ($this->request->getpost("code")) {
                if ($this->InvoiceModel->insert_c_invoice($data)) {
                    return $this->response->redirect(url_to('erp.sale.invoice'));
                } else {
                    return $this->response->redirect(url_to('erp.sale.invoice.add'));
                }
            }
            $data['page'] = "sale/c_invoiceadd";
        }
        $data['invoice_status'] = $this->InvoiceModel->get_invoice_status();
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }


    public function invoiceedit($invoice_id)
    {
        if (is_manufacturing_system()) {
            if ($this->request->getPost("code")) {
                $data['code'] = $this->request->getPost("code");
                $data['cust_id'] = $this->request->getPost("cust_id");
                $data['invoice_date'] = $this->request->getPost("invoice_date");
                $data['shippingaddr_id'] = $this->request->getPost("shippingaddr_id");
                $data['terms_condition'] = $this->request->getPost("terms_condition");
                $data['payment_terms'] = $this->request->getPost("payment_terms");
                $data['transport_req'] = $this->request->getPost("transport_req") ?? 0;
                $data['trans_charge'] = $this->request->getPost("trans_charge");
                $data['discount'] = $this->request->getPost("discount");
                $data['invoice_expiry'] = $this->request->getPost("invoice_expiry");

                $data['product_ids'] = $this->request->getpost("product_id");
                $data['quantities'] = $this->request->getpost("quantity");
                $data['price_ids'] = $this->request->getpost("price_id");


                $logger = \Config\Services::logger();

                $logger->error($data);

                if ($this->InvoiceModel->update_m_invoice($invoice_id, $data)) {
                    return $this->response->redirect(url_to("erp.sale.invoice"));
                } else {
                    return $this->response->redirect(url_to("erp.sale.invoice", $invoice_id));
                }
            }
            $data['invoice'] = $this->InvoiceModel->get_m_invoice_by_id($invoice_id);
            if (empty($data['invoice'])) {
                $this->session->setFlashdata("op_error", "Invoice Not Found");
                return $this->response->redirect(url_to("erp.sale.invoice"));
            }
            $data['shippingaddr'] = $this->InvoiceModel->get_m_shipping_addr($data['invoice']->cust_id);
            $data['invoice_items'] = $this->InvoiceModel->get_m_invoice_items($invoice_id);
            $taxVal = array();
            foreach ($data['invoice_items'] as $tax) {
                $taxVal[] = [
                    'tax1' => $tax['tax1'],
                    'tax2' => $tax['tax2']
                ];
            }
            $taxIds = array_column($taxVal, 'tax1', 'tax2');
            // $data['tax'] = $this->InvoiceModel->getTaxNamePercentage($taxIds);
            // return var_dump($data['tax']);
            $data['page'] = "sale/m_invoiceedit";
        } else {
            if ($this->request->getPost("code")) {
                $data['code'] = $this->request->getPost("code");
                $data['cust_id'] = $this->request->getPost("cust_id");
                $data['invoice_date'] = $this->request->getPost("invoice_date");
                $data['terms_condition'] = $this->request->getPost("terms_condition");
                $data['payment_terms'] = $this->request->getPost("payment_terms");
                $data['discount'] = $this->request->getPost("discount");
                $data['invoice_expiry'] = $this->request->getPost("invoice_expiry");
                $data['property_ids'] = $this->request->getPost("property_id");
                $data['unit_ids'] = $this->request->getPost("unit_id");

                if ($this->InvoiceModel->update_c_invoice($invoice_id, $data)) {
                    return $this->response->redirect(url_to("erp.sale.invoice"));
                } else {
                    return $this->response->redirect(url_to("erp.sale.invoice.edit.post" . $invoice_id));
                }
            }
            $data['invoice'] = $this->InvoiceModel->get_c_invoice_by_id($invoice_id);
            if (empty($data['invoice'])) {
                session()->setFlashdata("op_error", "Invoice Not Found");
                redirect("erp/sale/invoices");
            }
            $data['invoice_items'] = $this->InvoiceModel->get_c_invoice_items($invoice_id);
            $data['page'] = "sale/c_invoiceedit";
        }
        $data['invoice_id'] = $invoice_id;
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }

    public function ajaxfetchinvoicepropertyunits()
    {
        $property_id = $_GET['property_id'] ?? "";
        $invoice_id = $_GET['invoice_id'] ?? 0;
        $response = array();
        $response['error'] = 1;
        if (!empty($property_id)) {
            $query = "SELECT prop_unit_id,unit_name,price FROM property_unit WHERE property_id=$property_id AND status=0";
            if (!empty($invoice_id)) {
                $query = "SELECT prop_unit_id,unit_name,price FROM property_unit WHERE property_id=$property_id AND ( status=0 OR EXISTS (SELECT sale_item_id FROM sale_order_items WHERE invoice_id=$invoice_id AND related_id=property_unit.prop_unit_id))";
            }
            $result = $this->db->query($query)->getResultArray();
            $m_result = array();
            foreach ($result as $r) {
                $extra = array();
                array_push($extra, $r['price']);
                array_push($m_result, array(
                    "key" => $r['prop_unit_id'],
                    "value" => $r['unit_name'],
                    "extra" => $extra
                ));
            }
            $response['error'] = 0;
            $response['data'] = $m_result;
        } else {
            $response['reason'] = "No property units";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    //invoice delete


    public function invoicedelete($invoice_id)
    {
        $InvoiceModel = new InvoiceModel();

        $invoice = $InvoiceModel->get_m_invoice_by_id($invoice_id);

        if (empty($invoice)) {
            session()->setFlashdata("op_error", "Invoice Not Found");
            return $this->response->redirect(url_to('erp.sale.invoice'));
        }

        $deleted = $InvoiceModel->delete_invoice($invoice_id);

        if ($deleted) {

            session()->setFlashdata("op_success", "Invoice successfully deleted");
        } else {

            session()->setFlashdata("op_error", "Invoice failed to delete");
        }

        return $this->response->redirect(url_to('erp.sale.invoice'));
    }



    public function createinvoice($order_id, $data)
    {
        $data['created'] = false;
        $data['invoice_date'] = $this->request->getpost("invoice_date");
        $data['invoice_expiry'] = $this->request->getpost("invoice_expiry");
        $data['code'] = $this->request->getpost("code");

        if (is_manufacturing_system()) {
            if ($this->InvoiceModel->create_m_invoice($order_id, $data)) {
                return $this->response->redirect(url_to('erp.sale.invoice'));
            } else {
                redirect("erp/sale/orderview/" . $order_id);
            }
        } else {
            $data['created'] = false;
            $data['invoice_date'] = $this->request->getpost("invoice_date");
            $data['invoice_expiry'] = $this->request->getpost("invoice_expiry");
            $data['code'] = $this->request->getpost("code");
            if ($this->InvoiceModel->create_c_invoice($order_id, $data)) {
                return $this->response->redirect(url_to('erp.sale.invoice'));
            } else {
                redirect("erp/sale/orderview/" . $order_id);
            }
        }
    }

    //Attachments invoice
    public function upload_invoiceattachment()
    {
        $response = array();
        if (!empty($_FILES['attachment']['name'])) {
            $response = $this->InvoiceModel->upload_attachment("sale_invoice");
        } else {
            $response['error'] = 1;
            $response['reason'] = "No file to upload";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function invoice_delete_attachment()
    {
        $response = array();
        $response = $this->InvoiceModel->delete_attachment("sale_invoice");
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function invoicenotify($invoice_id)
    {
        if ($_POST["notify_title"]) {
            $this->InvoiceModel->insert_update_invoicenotify($invoice_id);
        }
        return $this->response->redirect(url_to('erp.sale.invoice.view', $invoice_id));
    }

    public function ajax_invoicenotify_response()
    {
        $response = array();
        $response = $this->InvoiceModel->get_invoicenotify_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function invoicenotifydelete($invoice_id, $notify_id)
    {
        $this->InvoiceModel->delete_invoice_notify($invoice_id, $notify_id);
        return $this->response->redirect(url_to('erp.sale.invoice.view', $invoice_id));
    }


    public function invoice_notify_export()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Sale Invoice Notification";
        if ($type == "pdf") {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
        } else {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->InvoiceModel->get_invoicenotify_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }

    // creditnote add

    public function creditadd($invoice_id)
    {
        if ($this->request->getpost("code")) {

            $data['code'] = $this->request->getpost("code");
            $data['issued_date'] = $this->request->getpost("issued_date");
            $data['other_charge'] = $this->request->getpost("other_charge");
            $data['payment_terms'] = $this->request->getpost("payment_terms");
            $data['terms_condition'] = $this->request->getpost("terms_condition");
            $data['remarks'] = $this->request->getpost("remarks");
            $data['created_by'] = get_user_id();
            $data['product_ids'] = $this->request->getpost("product_id");
            $data['qtys'] = $this->request->getpost("quantity");
            $data['unit_prices'] = $this->request->getpost("unit_price");
            if ($this->InvoiceModel->insertcredit($invoice_id, $data)) {
                return $this->response->redirect(url_to("erp.sale.invoice", $invoice_id));
            } else {
                return $this->response->redirect(url_to('erp.sale.invoice', $invoice_id));
            }
        }
        $data['invoice_items'] = $this->InvoiceModel->get_m_invoice_items_for_credit($invoice_id);
        if (empty($data['invoice_items'])) {
            session()->setFlashdata("op_error", "Invoice Not Found");
            return $this->response->redirect(url_to("erp.sale.invoice"));
        }
        $data['invoice_id'] = $invoice_id;
        $data['page'] = "sale/creditadd";
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }


    //New credit Note 
    public function creditNoteAddPage()
    {
        if ($this->request->getpost("code")) {
            $data['code'] = $this->request->getpost("code");
            $data['cust_id'] = $this->request->getpost("customer_id");
            $data['issued_date'] = $this->request->getpost("issued_date");
            $data['other_charge'] = $this->request->getpost("other_charge");
            $data['payment_terms'] = $this->request->getpost("payment_terms");
            $data['terms_condition'] = $this->request->getpost("terms_condition");
            $data['remarks'] = $this->request->getpost("remarks");
            $data['created_by'] = get_user_id();
            if ($this->InvoiceModel->insertCreditNote($data)) {
                return $this->response->redirect(url_to("erp.sale.creditnotes"));
            } else {
                return $this->response->redirect(url_to('erp.add.creditnoteadd'));
            }
        }
        $data['customer_company'] = $this->CustomersModel->getCustomersCompanyName();
        $data['page'] = "sale/creditnoteadd";
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }


    //New CreditNote Apply Page for Invoice
    public function creditApplyPage($invoice_id)
    {
        $data['invoice_id'] = $invoice_id;
        $customer_id = $this->InvoiceModel->getCustomerIdByInvoiceId($invoice_id);
        $data['credit_note'] = $this->CreditNotesModel->getCreditNoteDetailsByCustomerId($customer_id);
        $data['page'] = "sale/creditnoteapply";
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        return view("erp/index", $data);
    }

    public function creditApply($invoice_id)
    {
        $credit_id = $this->request->getPost('credit_code');
        $applied_amount = $this->request->getPost('credit_amount');

        // return var_dump($invoice_id);
        if ($this->CreditNotesModel->updateCreditAmount($credit_id, $applied_amount, $invoice_id)) {
            $this->session->setFlashdata("op_success", "Credit Note Applied Succssfully!");
            return $this->response->redirect(url_to('erp.sale.invoice.view', $invoice_id));
        } else {
            $this->session->setFlashdata("op_error", "Credit Note Failed to Applied!");
            return $this->response->redirect(url_to('erp.invoice.add.creditnote', $invoice_id));
        }
        $data['menu'] = "sale";
        $data['submenu'] = "invoice";
        $data['page'] = "sale/creditnoteapply";
        return view("erp/index", $data);
    }

    public function getCreditAmountByAjax()
    {
        $response = array();
        $credit_id = $this->request->getPost('creditId');
        $data['amount'] = $this->CreditNotesModel->getCreditAmountByCreditId($credit_id);
        return $this->response->setJSON($data);
    }



    public function stock_pick($order_id)
    {
        $this->OrdersModel->stock_pick($order_id);
        redirect("erp/sale/orderview/" . $order_id);
    }




    public function ajax_invoice_code_unique()
    {
        $code = $_GET['data'];
        $id = $_GET['id'] ?? 0;
        $query = "SELECT code FROM sale_invoice WHERE code='$code' LIMIT 1";
        if (!empty($id)) {
            $query = "SELECT code FROM sale_invoice WHERE code='$code' AND invoice_id<>$id LIMIT 1";
        }
        $check = $this->db->query($query)->getRow();
        $response = array();
        if (empty($check)) {
            $response['valid'] = 1;
        } else {
            $response['valid'] = 0;
            $response['msg'] = "Invoice Code already exists";
        }
        header("content-type:application/json");
        echo json_encode($response);
        exit();
    }

    //Payments

    public function ajaxSalepaymentResponse()
    {
        $response = array();
        $invoice_id = $this->request->getGet("invoiceid");
        $response = $this->SalePaymentModel->get_payment_datatable($invoice_id);
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function invoicePayment($invoice_id)
    {
        if ($this->request->getPost("amount")) {
            $data['amount'] = $this->request->getPost("amount");
            $data['paid_on'] = $this->request->getPost("paid_on");
            $data['payment_id'] = $this->request->getPost("payment_id");
            $data['transaction_id'] = $this->request->getPost("transaction_id");
            $data['notes'] = $this->request->getPost("notes");
            $sale_pay_id = $this->request->getPost("sale_pay_id") ?? 0;
            $this->SalePaymentModel->insert_update_payment($invoice_id, $sale_pay_id, $data);
        }
        return $this->response->redirect(url_to('erp.sale.invoice.view', $invoice_id));
    }

    public function ajaxFetchInvoicepayment($sale_pay_id)
    {
        $response = array();
        $query = "SELECT * FROM sale_payments WHERE sale_pay_id=$sale_pay_id";
        $result = $this->db->query($query)->getRow();
        if (!empty($result)) {
            $response['error'] = 0;
            $response['data'] = $result;
        } else {
            $response['error'] = 1;
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function invoicePaymentDelete($invoice_id, $sale_pay_id)
    {
        $this->SalePaymentModel->delete_payment($invoice_id, $sale_pay_id);
        return $this->response->redirect(url_to('erp.sale.invoice.view', $invoice_id));
    }

    public function invoicePaymentExport()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Sale Payments";
        if ($type == "pdf") {
            $config['column'] = array("Payment Mode", "Amount", "Paid on", "Transaction ID", "Notes");
        } else {
            $config['column'] = array("Payment Mode", "Amount", "Paid on", "Transaction ID", "Notes");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->SalePaymentModel->get_invoicepayment_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }

    //Email Send starts here



    //Credit Notes Starts
    public function creditNotes()
    {
        $data['credit_datatable_config'] = $this->CreditNotesModel->get_dtconfig_creditnotes();
        $data['page'] = "sale/creditnotes";
        $data['menu'] = "sale";
        $data['submenu'] = "creditnote";
        return view("erp/index", $data);
    }


    public function ajax_creditnote_code_unique()
    {
        $code = $_GET['data'];
        $id = $_GET['id'] ?? 0;
        $query = "SELECT code FROM credit_notes WHERE code='$code' LIMIT 1";
        if (!empty($id)) {
            $query = "SELECT code FROM credit_notes WHERE code='$code' AND credit_id<>$id LIMIT 1";
        }
        $check = $this->db->query($query)->getRow();
        $response = array();
        if (empty($check)) {
            $response['valid'] = 1;
        } else {
            $response['valid'] = 0;
            $response['msg'] = "Credit Code already exists";
        }
        header("content-type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxCreditnoteResponse()
    {
        $response = array();
        $response = $this->CreditNotesModel->getCreditnoteDatatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function creditnote_export()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Credit Note";
        if ($type == "pdf") {
            $config['column'] = array("Credit Code", "Customer Company", "Issued Date", "Amount", "Outstanding Amount");
        } else {
            $config['column'] = array("Credit Code", "Customer Company", "Issued Date", "Amount", "Outstanding Amount");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $config['data'] = $this->CreditNotesModel->get_creditnote_export($type);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }


    public function creditNotesView($credit_id)
    {
        $user_email = session()->get('erp_email');
        $user_name =  session()->get('erp_username');
        $data['creditnote'] = $this->CreditNotesModel->get_creditnote_for_view($credit_id);
        if (empty($data['creditnote'])) {
            $this->session->setFlashdata("op_error", "Credit Note Not Found");
            redirect("erp/sale/creditnotes");
        }
        $data['credit_items'] = $this->CreditNotesModel->get_creditnote_items($credit_id);
        $data['notify_datatable_config'] = $this->CreditNotesModel->get_dtconfig_notify();
        $data['attachments'] = $this->CreditNotesModel->get_attachments("credit_note", $credit_id);
        $data['credit_id'] = $credit_id;
        $data['user_email'] = $user_email;
        $data['user_name'] = $user_name;
        $data['page'] = "sale/creditview";
        $data['menu'] = "sale";
        $data['submenu'] = "creditnote";
        return view("erp/index", $data);
    }

    public function applyCredit($credit_id)
    {
        $this->CreditNotesModel->apply_credit($credit_id);
        redirect("erp/sale/creditview/" . $credit_id);
    }

    public function uploadCreditAttachment()
    {
        $id = $_GET["id"] ?? 0;
        $response = array();
        if (!empty($_FILES['attachment']['name'])) {
            $response = $this->CreditNotesModel->upload_attachment("credit_note", $id);
        } else {
            $response['error'] = 1;
            $response['reason'] = "No file to upload";
        }
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function creditDeleteAttachment()
    {
        $response = array();
        $response = $this->CreditNotesModel->delete_attachment("credit_note");
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function ajaxCreditnotifyResponse()
    {
        $response = array();
        $response = $this->CreditNotesModel->get_creditnotify_datatable();
        header("Content-Type:application/json");
        echo json_encode($response);
        exit();
    }

    public function creditNotify($credit_id)
    {
        if ($this->request->getPost("notify_title")) {
            $notify_id = $this->request->getPost("notify_id") ?? 0;
            $data['notify_title'] = $this->request->getPost("notify_title");
            $data['notify_desc'] = $this->request->getPost("notify_desc");
            $data['notify_to'] = $this->request->getPost("notify_to");
            $data['notify_at'] = $this->request->getPost("notify_at");
            $data['notify_email'] = $this->request->getPost("notify_email") ?? 0;
            $this->CreditNotesModel->insert_update_creditnotify($credit_id, $notify_id, $data);
        }
        return $this->response->redirect(url_to('erp.sale.creditnotesview', $credit_id));
    }

    public function creditNotifyExport()
    {
        $type = $_GET['export'];
        $config = array();
        $config['title'] = "Credit Notes Notification";
        if ($type == "pdf") {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
        } else {
            $config['column'] = array("Title", "Description", "Notify At", "Notify To", "Notified");
            $config['column_data_type'] = array(ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING, ExporterConst::E_STRING);
        }
        $credit_id = $this->request->getGet("creditid");
        $config['data'] = $this->CreditNotesModel->get_creditnotify_export($type, $credit_id);
        if ($type == "pdf") {
            Exporter::export(ExporterConst::PDF, $config);
        } else if ($type == "excel") {
            Exporter::export(ExporterConst::EXCEL, $config);
        } else if ($type == "csv") {
            Exporter::export(ExporterConst::CSV, $config);
        }
    }


    public function creditNotifyDelete($credit_id, $notify_id)
    {
        $this->CreditNotesModel->delete_credit_notify($credit_id, $notify_id);
        return $this->response->redirect(url_to('erp.sale.creditnotesview', $credit_id));
    }

    // IMPLEMENTED  Credit Note Delete 
    public function creditNotesDelete($credit_id)
    {
        $creditNote = $this->CreditNotesModel->get_creditnote_by_id($credit_id);

        if (empty($creditNote)) {
            session()->setFlashdata("op_error", "Credit Note Not Found");
            return $this->response->redirect(url_to('erp.sale.creditnotes'));
        }

        $deleted = $this->CreditNotesModel->delete_creditnote($credit_id);

        if ($deleted) {

            session()->setFlashdata("op_success", "Credit Note successfully deleted");
        } else {

            session()->setFlashdata("op_error", "Credit Note failed to delete");
        }

        return $this->response->redirect(url_to('erp.sale.creditnotes'));
    }


    //Overall Reports

    public function listReports()
    {
        $data['quotationStatus'] = $this->QuotationModel->quotationStatus();
        // $this->logger->error();21
        $data['title'] = "Sale Reports";
        $data['page'] = 'sale/salereports';
        $data['menu'] = 'sale';
        $data['submenu'] = 'reports';
        return view('erp/index', $data);
    }

    public function ajaxReportData()
    {
        $type = $this->request->getGet('r_type');
        $response = array();

        if ($type == 'inv_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->invoiceTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getInvoiceData();
        } elseif ($type == 'item_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->itemTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getItemData();
        } elseif ($type == 'payment_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->invoicePaymentTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getPaymentData();
        } elseif ($type == 'credit_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->creditNoteTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getCreditNoteData();
        } elseif ($type == 'proposal_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->quotationsTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getquotationsData();
        } elseif ($type == 'estimate_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->EstimatesTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getEstimatesData();
        } elseif ($type == 'customer_report') {
            $response['datatable_config_title'] = $this->InvoiceModel->customerTitle();
            $response['datatable_config_data'] = $this->InvoiceModel->getCustomerData();
        }
        return $this->response->setJSON($response);
    }


    public function ajaxPeriodReport()
    {
        $report_type = $this->request->getGet('report_type');
        $selected_period = $this->request->getGet('selectedPeriod');
        $fromDate = $this->request->getGet('fromDate');
        $toDate = $this->request->getGet('toDate');

        $period = $this->InvoiceModel->getTimePeriod();
        $payment_date = $this->SalePaymentModel->getAllTime();
        $quotation_date = $this->QuotationModel->getAllTime();
        $creditNote_date = $this->CreditNotesModel->getAllTime();
        $estimate_date = $this->EstimatesModel->getAllTime();

        $response = array();

        //All Time Data
        if ($selected_period == 'all_time') {
            if ($report_type == 'inv_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->invoiceTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getInvoiceData();
            } elseif ($report_type == 'item_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->itemTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getItemData();
            } elseif ($report_type == 'payment_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->invoicePaymentTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getPaymentData();
            } elseif ($report_type == 'credit_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->creditNoteTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getCreditNoteData();
            } elseif ($report_type == 'proposal_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->quotationsTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getquotationsData();
            } elseif ($report_type == 'estimate_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->EstimatesTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getEstimatesData();
            } elseif ($report_type == 'customer_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->customerTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getCustomerData();
            }

            //Current Month Data
        } elseif ($selected_period == 'this_month') {
            $currentMonth = date('m');
            if ($report_type == 'inv_report') {

                $filteredData = array_filter($period, function ($date) use ($currentMonth) {
                    return date('m', $date['created_at']) == $currentMonth;
                });
                $thisMonth = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->invoiceTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getInvoiceDataByDate($thisMonth);
            } elseif ($report_type == 'item_report') {

                $response['datatable_config_title'] = $this->InvoiceModel->itemTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getItemDataByMonth();
            } elseif ($report_type == 'payment_report') {

                $filteredData = array_filter($payment_date, function ($date) use ($currentMonth) {
                    return date('m', strtotime($date['paid_on'])) == $currentMonth;
                });
                $thisMonth = array_column($filteredData, 'paid_on');
                $response['alld'] =  $filteredData;
                $response['datatable_config_title'] = $this->InvoiceModel->invoicePaymentTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getPaymentDataByDate($thisMonth);
            } elseif ($report_type == 'credit_report') {

                $filteredData = array_filter($creditNote_date, function ($date) use ($currentMonth) {
                    return date('m', $date['created_at']) == $currentMonth;
                });
                $thisMonth = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->creditNoteTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getCreditNoteDataByDate($thisMonth);
            } elseif ($report_type == 'proposal_report') {

                $filteredData = array_filter($quotation_date, function ($date) use ($currentMonth) {
                    return date('m', $date['created_at']) == $currentMonth;
                });
                $thisMonth = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->quotationsTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getquotationsDataByDate($thisMonth);
            } elseif ($report_type == 'estimate_report') {

                $filteredData = array_filter($estimate_date, function ($date) use ($currentMonth) {
                    return date('m', $date['created_at']) == $currentMonth;
                });
                $thisMonth = array_column($filteredData, 'created_at');
                $response['alld'] =  $thisMonth;
                $response['datatable_config_title'] = $this->InvoiceModel->EstimatesTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getEstimatesDataByDate($thisMonth);
            } elseif ($report_type == 'customer_report') {

                $filteredData = array_filter($period, function ($date) use ($currentMonth) {
                    return date('m', $date['created_at']) == $currentMonth;
                });
                $thisMonth = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->customerTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getCustomerDataByDate($thisMonth);
            }

            //Customized Date Data
        } elseif ($selected_period == 'duration') {
            $fromDateTimestamp = strtotime($fromDate . ' 00:00:00');
            $toDateTimestamp = strtotime($toDate . ' 23:59:58');

            if ($report_type == 'inv_report') {
                $filteredData = array_filter($period, function ($date) use ($fromDateTimestamp, $toDateTimestamp) {
                    return $date['created_at'] >= $fromDateTimestamp && $date['created_at'] <= $toDateTimestamp;
                });
                $durationData = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->invoiceTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getInvoiceDataByDate($durationData);
            } elseif ($report_type == 'item_report') {
                $response['datatable_config_title'] = $this->InvoiceModel->itemTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getItemDataBySpecific_period($fromDateTimestamp, $toDateTimestamp);
            } elseif ($report_type == 'payment_report') {
                $filteredData = array_filter($payment_date, function ($date) use ($fromDate, $toDate) {
                    return $date['paid_on'] >= $fromDate && $date['paid_on'] <= $toDate;
                });
                $durationData = array_column($filteredData, 'paid_on');
                $response['fromDate'] = $durationData;
                $response['datatable_config_title'] = $this->InvoiceModel->invoicePaymentTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getPaymentDataByDate($durationData);
            } elseif ($report_type == 'credit_report') {

                $filteredData = array_filter($creditNote_date, function ($date) use ($fromDateTimestamp, $toDateTimestamp) {
                    return $date['created_at'] >= $fromDateTimestamp && $date['created_at'] <= $toDateTimestamp;
                });
                $durationData = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->creditNoteTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getCreditNoteDataByDate($durationData);
            } elseif ($report_type == 'proposal_report') {
                $filteredData = array_filter($quotation_date, function ($date) use ($fromDateTimestamp, $toDateTimestamp) {
                    return $date['created_at'] >= $fromDateTimestamp && $date['created_at'] <= $toDateTimestamp;
                });
                $durationData = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->quotationsTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getquotationsDataByDate($durationData);
            } elseif ($report_type == 'estimate_report') {
                $filteredData = array_filter($estimate_date, function ($date) use ($fromDateTimestamp, $toDateTimestamp) {
                    return $date['created_at'] >= $fromDateTimestamp && $date['created_at'] <= $toDateTimestamp;
                });
                $durationData = array_column($filteredData, 'created_at');
                $response['alld'] =  $durationData;
                $response['datatable_config_title'] = $this->InvoiceModel->EstimatesTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getEstimatesDataByDate($durationData);
            } elseif ($report_type == 'customer_report') {
                $filteredData = array_filter($period, function ($date) use ($fromDateTimestamp, $toDateTimestamp) {
                    return $date['created_at'] >= $fromDateTimestamp && $date['created_at'] <= $toDateTimestamp;
                });
                $durationData = array_column($filteredData, 'created_at');
                $response['datatable_config_title'] = $this->InvoiceModel->customerTitle();
                $response['datatable_config_data'] = $this->InvoiceModel->getCustomerDataByDate($durationData);
            }
        }
        return $this->response->setJSON($response);
    }

    public function listChartReports()
    {
        $chart = $this->request->getPost('selected_chart');
        if ($chart == 'total_income') {
            $data['result'] = $this->InvoiceModel->getTotalIncome();
        } elseif ($chart == 'payment_mode') {
            $data['result'] = $this->InvoiceModel->getPaymentDataChart();
        } elseif ($chart == 'total_customer_value') {
            $data['result'] = $this->InvoiceModel->getTotalValueByCustomerGroupsChart();
        }
        return $this->response->setJSON($data);
    }


    //Mail send Invoice

    // public function sendEmail($recipientEmail,$senderEmail,$subject,$message)
    // {

    //     $email = \Config\Services::email();

    //     // Set recipient email dynamically
    //     $email->setTo($recipientEmail);
    //     $email->setFrom($senderEmail);
    //     $email->setSubject($subject);
    //     $email->setMessage($message);

    //     // Send email
    //     if ($email->send()) {
    //         echo 'Email sent successfully to ' . $recipientEmail;
    //     } else {
    //         echo 'Email sending failed. Error: ' . $email->printDebugger(['headers']);
    //     }
    // }
}
