<?php

namespace App\Controllers\Erp;

use App\Controllers\BaseController;
use App\Models\Erp\AssetModel;
use App\Models\Erp\MRP\BOMModel;
use App\Models\ERP\MRP\ForecastModel;
use App\Models\Erp\MRP\PlanningModel;
use App\Models\Erp\Warehouse\CurrentStockModel;
use App\Models\Erp\Warehouse\WarehouseModel;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Config\Session;
use PSpell\Config;

class MRPController extends BaseController
{
    protected $data;
    protected $db;
    protected $session;
    protected $ForecastModel;
    protected $CurrentStockModel;
    protected $WarehouseModel;
    protected $PlanningModel;
    protected $BomModel;

    public function __construct()
    {
        $this->ForecastModel = new ForecastModel();
        $this->CurrentStockModel = new CurrentStockModel();
        $this->PlanningModel = new PlanningModel();
        $this->BomModel = new BOMModel();

        $this->WarehouseModel = new WarehouseModel();
        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();
        helper(['erp', 'form']);
    }

    public function dashboard()
    {
        $data['dev'] = "We are currently working on this";
        $data['page'] = "mrp/dashboard";
        $data['menu'] = "mrp";
        $data['submenu'] = "dashboard";
        return view("erp/index", $data);
    }

    public function Forecasting()
    {
        $logger = \Config\Services::logger();

        if (isset($_POST['start_forecast'])) {
            if (!empty($_POST['related_to']) && !empty($_POST['related_id']) && !empty($_POST['fromDate']) && !empty($_POST['toDate'])) {
                $forecastpy = 'mrpforecast.py';
                $dataForcast = $this->ForecastModel->GetDataWithTimestamp();
                foreach ($dataForcast as &$dataPoint) {
                    $dataPoint['timestamp'] = date('Y-m-d H:i:s', strtotime($dataPoint['timestamp']));
                }
                $dataForcastJson = json_encode($dataForcast);

                // $tempPath = get_tmp_path();
                $tempFile = tempnam(get_tmp_path(), 'to_forecast_data_');
                file_put_contents($tempFile, $dataForcastJson);

                $escapeDataForcast = escapeshellarg($tempFile);
                chdir(WRITEPATH . 'pyscripts/');
                $pythonPath = getenv('PYTHONPATH');
                $output = exec("$pythonPath $forecastpy $escapeDataForcast", $result);

                if (isset($result[0]) && !empty($result[0])) {
                    $forecastedRaw = json_decode($result[0], true);

                    // Logical Calculation Part
                    $current_stocks = $this->ForecastModel->GetCurrentStock($_POST['related_to'], $_POST['related_id']);
                    $timestamps = $forecastedRaw['timestamps'];
                    $forecasted = $forecastedRaw['fitted_values'];
                    $requirements = [];
                    $onhandstocks = [];
                    $scheduled = [];
                    // timestamps foeach to get the OnHandedStocks
                    foreach ($timestamps as $timestamp) {

                        $futureQty = $this->ForecastModel->GetFutureStocks($timestamp);
                        $calculatedValue = $futureQty + $current_stocks;
                        $onhandstocks[] = $calculatedValue;
                        $logger->error($current_stocks);
                    }

                    // requirements
                    foreach ($timestamps as $timestamp) {
                        $newTimestamp = date("Y-m-d H:i:s", strtotime($timestamp . " +1 year"));
                        $logger->error($newTimestamp);
                        $requiremntQty = $this->ForecastModel->GetRequiredQty($newTimestamp);
                        $requirements[] = $requiremntQty;
                    }

                    $i = 0;
                    foreach ($onhandstocks as $stock) {

                        $scheduled[] = round($forecasted[$i] - $stock);
                        $i++;
                    }

                    $forecastedTable = [];

                    $index = 0;
                    foreach ($timestamps as $timestamp) {
                        $newTimestamp = date("Y-m-d", strtotime($timestamp . " +1 year"));
                        array_push(
                            $forecastedTable,
                            array(
                                '<tr>',
                                // '<td></td>',
                                '<td>' . ($index + 1) . '</td>',
                                '<td>' . $newTimestamp . '</td>',
                                '<td>' . $onhandstocks[$index] . '</td>',
                                '<td>' . $requirements[$index] . '</td>',
                                '<td>' . round($forecasted[$index]) . '</td>',
                                '<td>' . $scheduled[$index] . '</td>',
                                '</tr>'
                            )
                        );

                        $index++;
                    }

                    $data['forcasted_table'] = $forecastedTable ?? "There Is an Error";
                    $data['result'] = ' ' . $_POST['related_to'];
                    unlink($tempFile);

                    // Data Preparation for the Export
                    $exportTable = [];

                    $exportI = 0;
                    foreach ($timestamps as $timestamp) {
                        $newTimestamp = date("Y-m-d", strtotime($timestamp . " +1 year"));
                        $exportTable[] = array(
                            $exportI + 1,
                            $newTimestamp,
                            $onhandstocks[$exportI],
                            $requirements[$exportI],
                            round($forecasted[$exportI]),
                            $scheduled[$exportI],
                        );

                        $exportI++;
                    }

                    $this->WriteExcel($exportTable);
                } else {
                    session()->setFlashdata("op_error", "There is an Error Try Again Later");
                }
            } else {
                session()->setFlashdata("op_error", "Invalid Inputs");
            }
        }

        $data['product_links'] = $this->CurrentStockModel->get_product_links();
        $data['product_types'] = $this->ForecastModel->GetProductType();
        $data['page'] = "mrp/forecasting";
        $data['menu'] = "mrp";
        $data['title'] = 'Forecasting Stocks and Demands';
        $data['submenu'] = "forecasting";
        $data['forecast_datatable_config'] = $this->ForecastModel->get_dtconfig_forecast();
        $data['min_year'] = date('Y') . "-01-01";
        $data['max_year'] = date('Y') . "-12-31";
        return view('erp/index', $data);
    }

    public function WriteExcel($exportTable)
    {
        // Create a new Spreadsheet object
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Add column headers
        $sheet->fromArray(['SNO', 'Timestamp', 'On Hand Stocks', 'Requirements', 'Forecasted', 'To Be Scheduled'], 'A1');

        // Add data to the sheet
        $sheet->fromArray($exportTable, null, 'A2');

        // Save the spreadsheet to a file
        $excelFilePath = get_tmp_path() . '/forecast/' . 'forecasting_' . date('Y-m-d_H-i-s') . '.xlsx';
        $writer = new Xlsx($spreadsheet);
        // $writer->save($excelFilePath);

        session()->set('forecast_file', $excelFilePath);
        session()->setFlashdata('op_success', 'Forecasting Completed! File Ready to Export:)');
    }

    public function ForecastExportasExcel()
    {
        $excelFilePath = session()->get('forecast_file');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="forecast_data.xlsx"');
        readfile($excelFilePath);
    }

    public function planningSchedule()
    {
        $data['planning_status'] = $this->PlanningModel->get_planning_status();
        $data['datatable_config'] = $this->PlanningModel->get_dtconfig_planning();
        $data['page'] = "mrp/planning";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }

    public function ajaxPlanningResponse()
    {
        $response = array();
        $response = $this->PlanningModel->get_planning_datatable();
        return $this->response->setJSON($response);
    }

    public function productPlanningAdding()
    {
        $post = [
            'finished_good_id' => $this->request->getPost("finished_good_id"),
            'start_date' => $this->request->getPost("start_date"),
            'end_date' => $this->request->getPost("end_date"),
            'stock' => $this->request->getPost("stock"),
            // 'status' => $this->request->getPost("status"),
        ];

        if ($this->request->getPost("finished_good_id")) {
            if ($this->PlanningModel->insert_planning($post)) {
                return $this->response->redirect(url_to("erp.mrp.planningschedule"));
            } else {
                return $this->response->redirect(url_to("erp.mrp.productplanningadding"));
            }
        }
        $data['planning_status'] = $this->PlanningModel->get_planning_status();
        $data['product'] = $this->PlanningModel->finishedGoodsProduct();
        $data['title'] = 'Forecasting Stocks and Demands';
        // $this->logger->error($data['product']);
        $data['page'] = "mrp/scheduling";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }

    public function productPlanningEdit($planning_id)
    {
        $post = [
            'finished_good_id' => $this->request->getPost("finished_good_id"),
            'start_date' => $this->request->getPost("start_date"),
            'end_date' => $this->request->getPost("end_date"),
            'stock' => $this->request->getPost("stock"),
            'status' => $this->request->getPost("status"),
        ];

        if ($this->request->getPost("finished_good_id")) {
            if ($this->PlanningModel->update_planning($planning_id, $post)) {
                return $this->response->redirect(url_to("erp.mrp.planningschedule"));
            } else {
                return $this->response->redirect(url_to("erp.mrp.productplanningedit", $planning_id));
            }
        }
        $data['planning'] = $this->PlanningModel->get_planning_by_id($planning_id);
        if (empty($data['planning'])) {
            $this->session->setFlashdata("op_error", "Planning Not Found");
            return $this->response->redirect(url_to("erp.mrp.planningschedule"));
        }
        $data['planning_status'] = $this->PlanningModel->get_planning_status();
        $data['product'] = $this->PlanningModel->finishedGoodsProduct();
        // $this->logger->error($data['planning']);
        $data['planning_id'] = $planning_id;
        $data['page'] = "mrp/schedulingedit";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }

    public function planningView($planning_id)
    {
        $data['planning'] = $this->PlanningModel->get_planning_by_id($planning_id);
        if (empty($data['planning'])) {
            $this->session->setFlashdata("op_error", "Planning Not Found");
            return $this->response->redirect(url_to("erp.mrp.planningschedule"));
        }
        $data['mrpscheduling_datatable_config'] = $this->PlanningModel->get_dtconfig_mrpscheduling();
        $data['planning_status'] = $this->PlanningModel->get_planning_status();
        $data['planning_status_bg'] = $this->PlanningModel->get_planning_status_bg();
        $data['planning'] = $this->PlanningModel->get_planning_by_id($planning_id);
        $data['planning_id'] = $planning_id;
        $data['page'] = "mrp/planningview";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }

    public function addMRPStock($planning_id)
    {

        // $this->logger->error($_POST);
        if ($this->request->getPost('sku')) {
            if ($this->PlanningModel->insert_mrp_scheduling($planning_id)) {
                return $this->response->redirect(url_to("erp.mrp.planningview", $planning_id));
            } else {
                return $this->response->redirect(url_to("erp.mrp.addmrpstock", $planning_id));
            }
        }
        $data['product_links'] = $this->PlanningModel->get_product_links();
        $data['product_types'] = $this->PlanningModel->get_product_types();
        $data['warehouses'] = $this->PlanningModel->get_all_warehouses();
        $data['stocks'] = $this->PlanningModel->getStock($planning_id);
        $data['finishedgoodProduct'] = $this->PlanningModel->getFinishedGoodProduct($planning_id);
        $data['planning_id'] = $planning_id;
        // $this->logger->error($post);
        $data['page'] = "mrp/addmrpstock";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }

    public function editMRPStock($planning_id, $mrp_scheduling_id)
    {
        // $this->logger->error($_POST);
        if ($this->request->getPost('sku')) {
            if ($this->PlanningModel->insert_mrp_scheduling($planning_id)) {
                return $this->response->redirect(url_to("erp.mrp.planningview", $planning_id));
            } else {
                return $this->response->redirect(url_to("erp.mrp.addmrpstock", $planning_id));
            }
        }
        $data['mrp_scheduling'] = $this->PlanningModel->get_mrp_scheduling_by_id($planning_id, $mrp_scheduling_id);
        if (empty($data['planning'])) {
            $this->session->setFlashdata("op_error", "MRP Scheduling Not Found");
            return $this->response->redirect(url_to("erp.mrp.planningview", $planning_id));
        }
        $data['currentstock_datatable_config'] = $this->CurrentStockModel->get_dtconfig_currentstock();
        $data['product_links'] = $this->PlanningModel->get_product_links();
        $data['product_types'] = $this->PlanningModel->get_product_types();
        $data['warehouses'] = $this->PlanningModel->get_all_warehouses();
        $data['stocks'] = $this->PlanningModel->getStock($planning_id);
        $data['finishedgoodProduct'] = $this->PlanningModel->getFinishedGoodProduct($planning_id);
        $data['planning_id'] = $planning_id;
        // $this->logger->error($post);
        $data['page'] = "mrp/addmrpstock";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }

    public function ajaxMrpSchedulingResponse()
    {
        $planningId = $this->request->getGet('planning_id');
        $response = array();
        $response = $this->PlanningModel->getMrpSchedulingDatatable($planningId);
        return $this->response->setJSON($response);
    }

    //Implemented by Tamil


    public function BOM()
    {
        $data['bom_dtconfig'] = $this->BomModel->get_dtconfig_bom();
        $data['bom_status'] = [1, 2, 3];
        $data['page'] = "mrp/bom";
        $data['title'] = "Bill of Material";
        $data['menu'] = "mrp";
        $data['submenu'] = "bom";
        return view("erp/index", $data);
    }

    
    public function get_m_invoice_datatable()
    {
        $columns = array(
            "code" => "code",
            "invoice date" => "invoice_date",
            "invoice expiry" => "invoice_expiry",
            "total amount" => "total_amount"
        );
        $limit = $_GET['limit'];
        $offset = $_GET['offset'];
        $search = $_GET['search'] ?? "";
        $orderby = isset($_GET['orderby']) ? strtoupper($_GET['orderby']) : "";
        $ordercol = isset($_GET['ordercol']) ? $columns[$_GET['ordercol']] : "";

        $query = "SELECT sale_invoice.invoice_id,code,customers.name,invoice_date,invoice_expiry,sale_invoice.status,trans_charge,discount,(SUM(sale_order_items.amount)+trans_charge-discount) AS total_amount,can_edit FROM sale_invoice JOIN customers ON sale_invoice.cust_id=customers.cust_id JOIN sale_order_items ON sale_invoice.invoice_id=sale_order_items.invoice_id WHERE sale_invoice.type=1 ";
        $count = "SELECT COUNT(sale_invoice.invoice_id) AS total FROM sale_invoice JOIN customers ON sale_invoice.cust_id=customers.cust_id JOIN sale_order_items ON sale_invoice.invoice_id=sale_order_items.invoice_id WHERE sale_invoice.type=1 ";
        $where = true;
        $filter_1_col = isset($_GET['status']) ? $columns['status'] : "";
        $filter_1_val = $_GET['status'];

        if (!empty($filter_1_col) && $filter_1_val !== "") {
            if (!$where) {
                $query .= " WHERE " . $filter_1_col . "=" . $filter_1_val . " ";
                $count .= " WHERE " . $filter_1_col . "=" . $filter_1_val . " ";
                $where = true;
            } else {
                $query .= " AND " . $filter_1_col . "=" . $filter_1_val . " ";
                $count .= " AND " . $filter_1_col . "=" . $filter_1_val . " ";
            }
        }

        if (!empty($search)) {
            if (!$where) {
                $query .= " WHERE ( code LIKE '%" . $search . "%' OR customers.name LIKE '%" . $search . "%' ) ";
                $count .= " WHERE ( code LIKE '%" . $search . "%' OR customers.name LIKE '%" . $search . "%' ) ";
                $where = true;
            } else {
                $query .= " AND ( code LIKE '%" . $search . "%' OR customers.name LIKE '%" . $search . "%' ) ";
                $count .= " AND ( code LIKE '%" . $search . "%' OR customers.name LIKE '%" . $search . "%' ) ";
            }
        }
        $query .= " GROUP BY sale_invoice.invoice_id ";
        if (!empty($ordercol) && !empty($orderby)) {
            $query .= " ORDER BY " . $ordercol . " " . $orderby;
        }
        $query .= " LIMIT $offset,$limit ";
        $result = $this->db->query($query)->getResultArray();
        $m_result = array();
        $sno = $offset + 1;
        foreach ($result as $r) {
            $action = '<div class="dropdown tableAction">
                        <a type="button" class="dropBtn HoverA "><i class="fa fa-ellipsis-v"></i></a>
                        <div class="dropdown_container">
                            <ul class="BB_UL flex">
                                <li><a href="' . url_to('erp.sale.invoice.view', $r['invoice_id']) . '" title="View" class="bg-warning "><i class="fa fa-eye"></i> </a></li>';
            if ($r['can_edit'] == 1) {
                $action .= '<li><a href="' . url_to('erp.sale.invoice.edit', $r['invoice_id']) . '" title="Edit" class="bg-success "><i class="fa fa-pencil"></i> </a></li>';
            }
            $action .= '<li><a href="' . url_to('erp.sale.invoice.delete', $r['invoice_id']) . '" title="Delete" class="bg-danger del-confirm"><i class="fa fa-trash"></i> </a></li>
                            </ul>
                        </div>
                    </div>';
            array_push(
                $m_result,
                array(
                    $r['invoice_id'],
                    $sno,
                    $r['code'],
                    $r['name'],
                    $r['invoice_date'],
                    $r['invoice_expiry'],
                    $r['trans_charge'],
                    $r['discount'],
                    $r['total_amount'],
                    $action
                )
            );
            $sno++;
        }
        $response = array();
        $response['total_rows'] = $this->db->query($count)->getRow()->total;
        $response['data'] = $m_result;
        return $response;
    }


    public function AddMrpBOM($planning_id)
    {

        // $this->logger->error($_POST);
        if ($this->request->getPost('sku')) {
            if ($this->BomModel->insert_mrp_scheduling($planning_id)) {
                return $this->response->redirect(url_to("erp.mrp.planningview", $planning_id));
            } else {
                return $this->response->redirect(url_to("erp.mrp.add.bom", $planning_id));
            }
        }
        $data['product_links'] = $this->BomModel->get_product_links();
        $data['product_types'] = $this->BomModel->get_product_types();
        $data['warehouses'] = $this->BomModel->get_all_warehouses();
        $data['stocks'] = $this->BomModel->getStock($planning_id);
        $data['finishedgoodProduct'] = $this->BomModel->getFinishedGoodProduct($planning_id);
        $data['planning_id'] = $planning_id;
        // $this->logger->error($post);
        $data['page'] = "mrp/bomadd";
        $data['menu'] = "mrp";
        $data['submenu'] = "planning";
        return view("erp/index", $data);
    }


}
