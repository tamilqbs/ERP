<?php



function get_tmp_path()
{
    return FCPATH . "temp/";
}

function get_rand_str($max = 5)
{
    return bin2hex(random_bytes($max)) . time();
}

function get_attachment_path($type)
{
    $path = FCPATH . "uploads/";
    switch ($type) {
        case "lead":
            $path .= "lead/";
            break;
        case "customer":
            $path .= "customer/";
            break;
        case "request":
            $path .= "request/";
            break;
        case "raw_material":
            $path .= "rawmaterial/";
            break;
        case "semi_finished":
            $path .= "semifinished/";
            break;
        case "finished_good":
            $path .= "finishedgood/";
            break;
        case "supplier":
            $path .= "supplier/";
            break;
        case "rfq":
            $path .= "rfq/";
            break;
        case "purchase_invoice":
            $path .= "purchaseinvoice/";
            break;
        case "employee":
            $path .= "employee/";
            break;
        case "contractor":
            $path .= "contractor/";
            break;
        case "inventory_service":
            $path .= "service/";
            break;
        case "property":
            $path .= "property/";
            break;
        case "ticket":
            $path .= "ticket/";
            break;
        case "estimate":
            $path .= "estimate/";
            break;
        case "quotation":
            $path .= "quotation/";
            break;
        case "sale_order":
            $path .= "saleorder/";
            break;
        case "sale_invoice":
            $path .= "saleinvoice/";
            break;
        case "credit_note":
            $path .= "creditnote/";
            break;
        case "team":
            $path .= "team/";
            break;
        case "equipment":
            $path .= "equipment/";
            break;
        case "project":
            $path .= "project/";
            break;
        case "expense":
            $path .= "expense/";
            break;
        case "project_testing":
            $path .= "projecttesting/";
            break;
        case "project_contractor":
            $path .= "projectcontractor/";
            break;
        default:
            break;
    }
    return $path;
}

function get_attachment_link($type)
{
    $path = base_url() . "uploads/";
    switch ($type) {
        case "lead":
            $path .= "lead/";
            break;
        case "customer":
            $path .= "customer/";
            break;
        case "request":
            $path .= "request/";
            break;
        case "raw_material":
            $path .= "rawmaterial/";
            break;
        case "semi_finished":
            $path .= "semifinished/";
            break;
        case "finished_good":
            $path .= "finishedgood/";
            break;
        case "supplier":
            $path .= "supplier/";
            break;
        case "rfq":
            $path .= "rfq/";
            break;
        case "purchase_invoice":
            $path .= "purchaseinvoice/";
            break;
        case "employee":
            $path .= "employee/";
            break;
        case "contractor":
            $path .= "contractor/";
            break;
        case "inventory_service":
            $path .= "service/";
            break;
        case "property":
            $path .= "property/";
            break;
        case "ticket":
            $path .= "ticket/";
            break;
        case "estimate":
            $path .= "estimate/";
            break;
        case "quotation":
            $path .= "quotation/";
            break;
        case "sale_order":
            $path .= "saleorder/";
            break;
        case "sale_invoice":
            $path .= "saleinvoice/";
            break;
        case "credit_note":
            $path .= "creditnote/";
            break;
        case "team":
            $path .= "team/";
            break;
        case "equipment":
            $path .= "equipment/";
            break;
        case "project":
            $path .= "project/";
            break;
        case "expense":
            $path .= "expense/";
            break;
        case "project_testing":
            $path .= "projecttesting/";
            break;
        case "project_contractor":
            $path .= "projectcontractor/";
            break;
        default:
            break;
    }
    return $path;
}

function log_activity($config = array())
{
    $db = \Config\Database::connect();
    $ci = \Config\Services::session();
    $done_by = $ci->get("erp_username");
    $additional_info = $config['additional_info']??'';
    if (!empty($config)) {
        // var_dump($config);
        // exit();
        $query = "INSERT INTO erp_log(title,log_text,ref_link,additional_info,done_by,created_at) VALUES(?,?,?,?,?,?)";
        $db->query($query, array($config['title'], $config['log_text'], $config['ref_link'], 
        $additional_info, $done_by,  date("Y-m-d H:i:s")));
    }
}



function get_user_name()
{
    $ci = \Config\Services::session();
    $username = $ci->get("erp_username");
    if (!empty($username)) {
        return $username;
    } else {
        return "User";
    }
}

function get_user_id()
{
    $ci = \Config\Services::session();
    $userid = $ci->get("erp_userid");
    return $userid;
}

function get_role_name()
{
    $ci = \Config\Services::session();
    if (is_admin()) {
        return "Admin";
    }
    $rolename = $ci->get("erp_rolename");
    if (!empty($rolename)) {
        return $rolename;
    } else {
        return "Anonymous";
    }
}

function is_admin()
{
    $ci = \Config\Services::session();
    $admin = $ci->get("erp_admin");
    if ($admin == '1') {
        return true;
    } else {
        return false;
    }
}

function has_permission($perm)
{
    $ci = \Config\Services::session();
    if ($ci->get("erp_logged")) {
        $admin = $ci->get("erp_admin");
        if ($admin == "1") {
            return true;
        }
        $perms = $ci->get("erp_perms");
        if (in_array($perm, $perms)) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function user_logged()
{
    $db = \Config\Database::connect();
    $ci = \Config\Services::session();
    if ($ci->session->get("erp_logged")) {
        return true;
    } else {
        if (isset($_COOKIE['rhash'])) {
            $rhash = $_COOKIE['rhash'];
            // $result=$db->query("SELECT password,user_id,name,email,is_admin,active,
            // role_name,permissions FROM erp_users LEFT JOIN erp_roles ON 
            // erp_users.role_id=erp_roles.role_id WHERE remember='$rhash' AND 
            // active=1")->result_array();

            $query = $db->table('erp_users');
            $query->select('password, user_id, name, email, is_admin, active, role_name, permissions');
            $query->join('erp_roles', 'erp_users.role_id = erp_roles.role_id', 'LEFT');
            $query->where('remember', $rhash);
            $query->where('active', 1);

            $result = $query->get()->getResultArray();

            if (!empty($result)) {
                $ci->set("erp_username", $result[0]['name']);
                $ci->set("erp_email", $result[0]['email']);
                $ci->set("erp_admin", $result[0]['is_admin']);
                $ci->set("erp_rolename", $result[0]['role_name']);
                $ci->set("erp_userid", $result[0]['user_id']);
                $ci->set("erp_logged", true);
                $perms = array();
                if (!empty($result[0]['permissions'])) {
                    $perms = json_decode($result[0]['permissions'], true);
                }
                $ci->set("erp_perms", $perms);

                $config['title'] = "Login";
                $config['log_text'] = "[ User successfully logged in ]";
                $config['ref_link'] = "";

                log_activity($config);
                return true;
            }
        }
    }
    return false;
}

function is_same_user($id)
{
    $ci = \Config\Services::session();
    $user_id = $ci->session->userdata("erp_userid");
    if ($id == $user_id) {
        return true;
    } else {
        return false;
    }
}


function set_transparency($dest, $src)
{
    $tindex = imagecolortransparent($src);
    $tcolor = array("red" => 255, "green" => 255, "blue" => 255);
    if ($tindex >= 0) {
        $tcolor = imagecolorsforindex($src, $tindex);
    }
    $tindex = imagecolorallocate($dest, $tcolor['red'], $tcolor['green'], $tcolor['blue']);
    imagefill($dest, 0, 0, $tindex);
    imagecolortransparent($dest, $tindex);
}

function resize_image($img_path, $width, $height)
{
    if (!file_exists($img_path)) {
        return false;
    }
    $imginfo = getimagesize($img_path);
    $img_width = $imginfo[0];
    $img_height = $imginfo[1];
    $type = $imginfo[2];
    $src = "";
    $dest = imagecreatetruecolor($width, $height);
    $resized = true;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $src = imagecreatefromjpeg($img_path);
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $img_width, $img_height);
            imagejpeg($dest, $img_path);
            break;
        case IMAGETYPE_PNG:
            $src = imagecreatefrompng($img_path);
            set_transparency($dest, $src);
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $img_width, $img_height);
            imagepng($dest, $img_path);
            break;
        case IMAGETYPE_GIF:
            $src = imagecreatefromgif($img_path);
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $img_width, $img_height);
            imagegif($dest, $img_path);
            break;
        case IMAGETYPE_BMP:
            $src = imagecreatefrombmp($img_path);
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $img_width, $img_height);
            imagebmp($dest, $img_path);
            break;
        case IMAGETYPE_WEBP:
            $src = imagecreatefromwebp($img_path);
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $img_width, $img_height);
            imagewebp($dest, $img_path);
            break;
        case IMAGETYPE_XBM:
            $src = imagecreatefromxbm($img_path);
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $width, $height, $img_width, $img_height);
            imagexbm($dest, $img_path);
            break;
        default:
            $resized = false;
    }
    imagedestroy($dest);
    imagedestroy($src);
    return $resized;
}

function get_next_seq_A($current_col)
{
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (empty($current_col)) {
        return $chars[0];
    }
    $tmp = $current_col;
    $next_col = array();
    $len = strlen($current_col);
    for ($i = 0; $i < $len; $i++) {
        $next_col[$i] = $current_col[$i];
    }
    $full_z = false;
    for ($i = $len - 1; $i >= 0; $i--) {
        if ($tmp[$i] === 'Z') {
            $next_col[$i] = $chars[0];
            $full_z = true;
        } else {
            $index = strpos($chars, $tmp[$i]);
            $next_col[$i] = $chars[$index + 1];
            $full_z = false;
            break;
        }
    }
    $next_col = implode("", $next_col);
    if ($full_z) {
        $next_col = $chars[0] . $next_col;
    }
    return $next_col;
}

function is_manufacturing_system()
{
    $db = \Config\Database::connect();
    $ci = \Config\Services::session();
    $query = $db->table('erp_settings');
    $query->select('s_value');
    $query->where('s_name', 'system_type');
    $row = $query->get()->getRow();

    $type = isset($row->s_value) ? $row->s_value : null;

    if ($type == "manufacturing") {
        return true;
    }
    return false;
}

function is_construction_system()
{   $db = \Config\Database::connect();
    $ci = \Config\Services::session();
    $query = $db->table('erp_settings');
    $query->select('s_value');
    $query->where('s_name', 'system_type');
    $row = $query->get()->getRow();

    $type = isset($row->s_value) ? $row->s_value : null;
    if ($type == "construction") {
        return true;
    }
    return false;
}

// Get Username By Id
function get_username_by_id($userid){
  
    $db = \Config\Database::connect();

    $query = $db->table('erp_users');
    $query->select('name');
    $query->select('last_name');
    $query->where('user_id',$userid);
    $result = $query->get()->getResultArray();

    // var_dump($result[0]);
    // echo '<br>';
    return $result[0]['name'].' '.$result[0]['last_name'];
}