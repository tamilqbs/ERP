<?php

namespace App\Models\Erp;

use CodeIgniter\Model;

class CustomerContactsModel extends Model
{
    protected $table = 'customer_contacts';
    protected $primaryKey = 'contact_id';
    protected $allowedFields = [
        'firstname', 'lastname', 'email', 'phone', 'active', 'position',
        'cust_id', 'created_at', 'created_by'
    ];
    protected $useTimestamps = false;
    protected $session;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();
    }
    public function get_dtconfig_contacts()
    {
        $config = array(
            "columnNames" => ["sno", "name", "email", "position", "phone", "active", "action"],
            "sortable" => [0, 1, 0, 1, 0, 0, 0],
        );
        return json_encode($config);
    }

    public function get_customercontact_datatable($cust_id)
    {

        $columns = array(
            "name" => "firstname",
            "email" => "email"
        );
        $limit = $_GET['limit'];
        $offset = $_GET['offset'];
        $search = $_GET['search'] ?? "";
        $orderby = isset($_GET['orderby']) ? strtoupper($_GET['orderby']) : "";
        $ordercol = isset($_GET['ordercol']) ? $columns[$_GET['ordercol']] : "";

        $query = "SELECT contact_id,firstname,lastname,email,phone,position,active FROM customer_contacts WHERE cust_id=$cust_id";
        $count = "SELECT COUNT(contact_id) AS total FROM customer_contacts WHERE cust_id=$cust_id";
        $where = true;

        if (!empty($search)) {
            if (!$where) {
                $query .= " WHERE ( firstname LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' ) ";
                $count .= " WHERE ( firstname LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' ) ";
                $where = true;
            } else {
                $query .= " AND ( firstname LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' ) ";
                $count .= " AND ( firstname LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' ) ";
            }
        }

        if (!empty($ordercol) && !empty($orderby)) {
            $query .= " ORDER BY " . $ordercol . " " . $orderby;
        }
        $query .= " LIMIT $offset,$limit ";
        $result = $this->db->query($query)->getResultArray();
        $m_result = array();
        $sno = $offset + 1;
        foreach ($result as $r) {
            $action = '<div class="dropdown tableAction">
                        <a type="button" class="dropBtn HoverA "><i class="fa fa-ellipsis-v"></i></a>
                        <div class="dropdown_container">
                            <ul class="BB_UL flex">
                                <li><a href="#" data-ajax-url="' . url_to('erp.crm.ajaxfetchcontact', $r['contact_id']) . '" title="Edit" class="bg-success modalBtn"><i class="fa fa-pencil"></i> </a></li>
                                <li><a href="' . url_to('erp.crm.customercontactdelete', $cust_id, $r['contact_id']) . '" title="Delete" class="bg-danger del-confirm"><i class="fa fa-trash"></i> </a></li>
                            </ul>
                        </div>
                    </div>';
            $active = '
                    <label class="toggle active-toggler-1" data-ajax-url="' . url_to('erp.crm.ajaxcontactactive', $r['contact_id']) . '" >
                        <input type="checkbox" ';
            if ($r['active'] == 1) {
                $active .= ' checked ';
            }
            $active .= ' />
                        <span class="togglebar"></span>
                    </label>';
            array_push(
                $m_result,
                array(
                    $r['contact_id'],
                    $sno,
                    $r['firstname'] . ' ' . $r['lastname'],
                    $r['email'],
                    $r['position'],
                    $r['phone'],
                    $active,
                    $action
                )
            );
            $sno++;
        }
        $response = array();
        $response['total_rows'] = $this->db->query($count)->getRow()->total;
        $response['data'] = $m_result;
        return $response;
    }

    public function get_customer_contacts_export($type)
    {
        $cust_id = $_GET["custid"];
        $columns = array(
            "name" => "firstname",
            "email" => "email"
        );
        $limit = $_GET['limit'];
        $offset = $_GET['offset'];
        $search = $_GET['search'] ?? "";
        $orderby = isset($_GET['orderby']) ? strtoupper($_GET['orderby']) : "";
        $ordercol = isset($_GET['ordercol']) ? $columns[$_GET['ordercol']] : "";

        $query = "SELECT firstname,lastname,email,phone,position,CASE WHEN active=1 THEN 'Yes' ELSE 'No' END AS active FROM customer_contacts WHERE cust_id=$cust_id";
        $where = true;

        if (!empty($search)) {
            if (!$where) {
                $query .= " WHERE ( firstname LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' ) ";
                $where = true;
            } else {
                $query .= " AND ( firstname LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' ) ";
            }
        }

        if (!empty($ordercol) && !empty($orderby)) {
            $query .= " ORDER BY " . $ordercol . " " . $orderby;
        }
        $result = $this->db->query($query)->getResultArray();
        return $result;
    }

    public function insert_update_customer_contact($cust_id, $post, $contact_id)
    {
        if (!empty($contact_id)) {
            $this->update_customer_contact($cust_id, $contact_id, $post);
        } else {
            $this->insert_customer_contact($cust_id, $post);
        }
    }

    private function update_customer_contact($cust_id, $contact_id, $post)
    {
        $firstname = $post["firstname"];
        $lastname = $post["lastname"];
        $email = $post["email"];
        $phone = $post["phone"];
        $position = $post["position"];
        $created_by = get_user_id();

        $query = "UPDATE customer_contacts SET firstname=? , lastname=? , email=? , position=? , phone=? , cust_id=? WHERE contact_id=$contact_id ";
        $this->db->query($query, array($firstname, $lastname, $email, $position, $phone, $cust_id));

        $config['title'] = "Customer Contact Update";
        if ($this->db->affectedRows() > 0) {
            $config['log_text'] = "[ Customer Contact successfully updated ]";
            $config['ref_link'] = url_to('erp.crm.customerview', $cust_id);
            $this->session->setFlashdata("op_success", "Customer Contact successfully updated");
        } else {
            $config['log_text'] = "[ Customer Contact failed to update ]";
            $config['ref_link'] = url_to('erp.crm.customerview', $cust_id);
            $this->session->setFlashdata("op_error", "Customer Contact failed to update");
        }
        log_activity($config);
    }

    private function insert_customer_contact($cust_id, $post)
    {
        $firstname = $post["firstname"];
        $lastname = $post["lastname"];
        $email = $post["email"];
        $phone = $post["phone"];
        $position = $post["position"];
        $created_by = get_user_id();

        $query = "INSERT INTO customer_contacts(firstname,lastname,email,position,phone,cust_id,created_at,created_by) VALUES(?,?,?,?,?,?,?,?) ";
        $this->db->query($query, array($firstname, $lastname, $email, $position, $phone, $cust_id, time(), $created_by));
        $contact_id = $this->db->insertId();

        $config['title'] = "Customer Contact Insert";
        if (!empty($contact_id)) {
            $config['log_text'] = "[ Customer Contact successfully created ]";
            $config['ref_link'] = url_to('erp.crm.customerview', $cust_id);
            $this->session->setFlashdata("op_success", "Customer Contact successfully created");
        } else {
            $config['log_text'] = "[ Customer Contact failed to create ]";
            $config['ref_link'] = url_to('erp.crm.customerview', $cust_id);
            $this->session->setFlashdata("op_error", "Customer Contact failed to create");
        }
        log_activity($config);
    }

     //Contact delete

     public function get_customercontact_by_id($cust_id)
     {
         return $this->db->table('customer_contacts')->select()->where('cust_id',$cust_id)->get()->getRow();
     }
 
     public function delete_contact($cust_id)
     {
         $deleted = false;
         $customer= $this->get_customercontact_by_id($cust_id);
         $this->builder()->where('cust_id', $cust_id)->delete();
 
         if ($this->db->affectedRows() > 0) {
             $deleted = true;
 
            
             $config = [
                 'title' => 'Customer Deletion',
                 'log_text' => "[ Customer successfully deleted ]",
                 'ref_link' => 'erp.crm.customercontactdelete' .$cust_id,
                 'additional_info' => json_encode($customer),
             ];
             log_activity($config);
         } else {
             $config = [
                 'title' => 'Customer Deletion',
                 'log_text' => "[ Customer failed to delete ]",
                 'ref_link' => '' .$cust_id,
             ];
             log_activity($config);
         }
         return $deleted;
     }
}
