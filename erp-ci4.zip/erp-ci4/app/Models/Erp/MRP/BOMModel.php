<?php

namespace App\Models\Erp\MRP;

use CodeIgniter\Model;

class BOMModel extends Model
{
    protected $table            = 'mrp_bom';
    protected $primaryKey       = 'bom_id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields = ['product_id', 'related_to','mrp_scheduling_id','warehouse_id', 'quantity', 'material_id', 'material_related_to', 'material_consumption', 'created_by', 'timestamp'];

    public function get_dtconfig_bom()
    {
        $config = array(
            "columnNames" => ["sno", "product", "related to", "quantity", "material name", "consumption"],
            "sortable" => [0, 0, 0, 0, 0, 0],
            "filters" => ["status"]
        );
        return json_encode($config);
    }

    public function get_product_links()
    {
        return $this->product_links;
    }

    public function get_product_types()
    {
        return $this->product_types;
    }


    public function get_all_warehouses()
    {
        $query = "SELECT warehouse_id,name FROM warehouses";
        $result = $this->db->query($query)->getResultArray();
        return $result;
    }

    public function getStock($planning_id)
    {
        $query = "SELECT stock FROM planning WHERE planning_id=$planning_id";
        return $result = $this->db->query($query)->getResultArray();
    }

    public function getFinishedGoodProduct($planning_id)
    {
        $query = "SELECT planning.finished_good_id,CONCAT(finished_goods.name,'-',finished_goods.code)as product_name FROM planning JOIN finished_goods ON planning.finished_good_id=finished_goods.finished_good_id WHERE  planning_id=$planning_id";
        return $result = $this->db->query($query)->getResultArray();
    }


    public function insert_mrp_scheduling($planning_id)
    {
        $inserted = false;

        $scheduling = $_POST["scheduling"];
        $related_to = $_POST["related_to"];
        $warehouse_id = $_POST["warehouse_id"];
        $mrp_scheduling_id = $_POST["mrp_scheduling_id"];
        $cost_per_unit = $_POST["cost_per_unit"];
        $mfg_date = $_POST["mfg_date"];
        $raw_materials = $_POST["raw_materials"];
        $amount = $_POST["amount"];
        $quantity = $_POST["quantity"];


        try {
            $this->db->transBegin();

            if (!empty($stock)) {
                $query1 = "INSERT INTO mrp_scheduling(scheduling, related_to,warehouse_id,mrp_scheduling_idm, cost_per_unit,mfg_date, raw_materials, amount, quantity) VALUES (?,? ,?, ?, ?, ?, ?, ?, ?)";
                $this->db->query($query1, array($scheduling,$related_to, $warehouse_id,$mrp_scheduling_id, $cost_per_unit, $mfg_date, $raw_materials, $amount, $quantity));

                $query2 = "UPDATE planning SET stock=? WHERE planning_id=?";
                $this->db->query($query2, array($stock, $planning_id));

                $query3 = "INSERT INTO stocks(related_to,related_id,warehouse_id,quantity,price_id) VALUE (?,?,?,?,?)";
            }

            $this->db->transCommit();
            $inserted = true;
        } catch (\Exception $e) {
            $this->db->transRollback();
            log_message('error', $e->getMessage()); // Log the error
        }

        $config['title'] = "MRP Scheduling Insert";
        $config['log_text'] = $inserted ? "[ MRP Scheduling successfully created ]" : "[ MRP Scheduling failed to create ]";
        $config['ref_link'] = $inserted ? url_to('erp.mrp.planningview', $planning_id) : url_to('erp.mrp.planningschedule');

        // $this->session->setFlashdata($inserted ? "op_success" : "op_error", $inserted ? "MRP Scheduling successfully created" : "MRP Scheduling failed to create");
        if ($inserted) {
            $this->session->setFlashdata("op_success", "MRP Scheduling successfully created");
        } else {
            $this->session->setFlashdata("op_error", "MRP Scheduling failed to create");
        }
        log_activity($config);

        return $inserted;
    }
}
