<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERP </title>
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/font-awesome.css' ;?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'; ?>">
</head>
<body>


<div class="flex loginpage">
    <div class="loginleft">
        <img src="<?php echo base_url().'assets/images/login.png'; ?>" alt="">
    </div>
    <div class="loginRight">

        <form class="allDiv" action="<?= url_to('erp.auth')?>" method="POST">
            <div class="loginTitle textCenter text-success">Welcome to <span class="text-primary">Qbrainstorm</span></div>
            
            <!-- Flash Data Commented -->
            


            <!-- End Of Flashdata -->
            <input type="email" placeholder="Email" required name="email" class="form_control">
             <div class="password poR">
                <input type="password" placeholder="Password" name="password" class="form_control">
                <a type="button"><i class="fa fa-eye"></i></a> 
             </div>
            <div class="flex">
                <label for="rememberMe"><input type="checkbox" id="rememberMe" name="remember_me" value="1" >Remember me</label>
                <a href="<?= url_to('erp.forgotpassword') ;?>" class="text-primary">Forget Password?</a>
            </div>
            <button type="submit" class="btn bg-info">Login</button>
        </form>
    </div>
</div>



<script src="<?php echo base_url().'assets/js/jquery.min.js' ;?>"></script>
<script src="<?php echo base_url().'assets/js/script.js' ;?>"></script>

</body>
</html>
