<div class="alldiv flex widget_title">
    <h3>Credit Notes Apply</h3>
    <div class="title_right">
    </div>
</div>

<div class="alldiv">

    <?php
    echo form_open(url_to('erp.add.creditnoteapplyadd', $invoice_id), array(
        "id" => "credit_add_form",
        "class" => "flex"
    ));
    ?>

    <div class="form-width-2">
        <div class="form-group  ">
            <label class="form-label">Credit Code</label>
            <select class="form_control field-check" name="credit_code" id="credit_code">
                <option value="select">select</option>
                <?php foreach ($credit_note as $row) : ?>
                    <option value="<?= $row['credit_id']; ?>"><?= $row['code']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="form-width-2">
        <div class="form-group">
            <label class="form-label ">Credit Amount</label>
            <input type="text" class="form_control field-check" id="credit_amount" name="credit_amount" />
            <p class="error-text"></p>
        </div>
    </div>
    <div class="form-width-1">
        <div class="form-group textRight ">
            <a class="btn outline-danger" href="<?= url_to('erp.sale.invoice.view', $invoice_id); ?>">Cancel</a>
            <button class="btn bg-primary" type="button" id="credit_add_btn">Save</button>
        </div>
    </div>
    <?php
    echo form_close();
    ?>
</div>


<!--SCRIPT WORKS -->
</div>
</main>
<script src="<?php echo base_url() . 'assets/js/jquery.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/script.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/erp.js'; ?>"></script>

<script type="text/javascript">
    let closer = new WindowCloser();
    let alert = new ModalAlert();
    closer.init();

    let form = document.getElementById("credit_add_form");
    let validator = new FormValidate(form);

    let lock = false;
    document.getElementById("credit_add_btn").onclick = function(evt) {
        if (!lock) {
            lock = true;
            validator.validate(
                (params) => {
                    form.submit();
                    lock = false;
                },
                (params) => {
                    lock = false;
                }, {});
        }
    }

    $('#credit_code').change(function() {
        var selectedCreditNoteId = $(this).val();
        $.ajax({
            type: 'POST',
            url: '<?= url_to('creditnoteapply.ajax'); ?>',
            data: {
                creditId: selectedCreditNoteId
            },
            success: function(data) {
                console.log(data.amount);
                $('#credit_amount').val(data.amount);
            },
            error: function(error) {
                console.log(error);
            }
        });
    });


    <?php
    if (session()->getFlashdata("op_success")) { ?>
        alert.invoke_alert("<?= session()->getFlashdata('op_success'); ?>", "success");
    <?php
    } else if (session()->getFlashdata("op_error")) { ?>
        alert.invoke_alert("<?= session()->getFlashdata('op_error'); ?>", "error");
    <?php
    }
    ?>
</script>
</body>

</html>