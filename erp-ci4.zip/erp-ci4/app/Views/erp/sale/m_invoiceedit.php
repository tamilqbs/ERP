<div class="alldiv flex widget_title">
    <h3>Update Sale Invoice</h3>
    <div class="title_right">
        <a href="<?= url_to('erp.sale.invoice'); ?>" class="btn bg-success"><i class="fa fa-reply"></i> Back </a>
    </div>
</div>

<div class="alldiv">

    <form action="<?= url_to('erp.sale.invoice.edit.post', $invoice_id) ?>" method="POST" class="flex" id="invoice_add_form">
        <div class="form-width-2">
            <div class="form-group field-ajax " data-ajax-url="<?= url_to('sale.invoice.add.fetchcode') . '?id=' . $invoice_id . '&'; ?>">
                <label class="form-label">Code</label>
                <input type="text" name="code" value="<?php echo $invoice->code; ?>" class="form_control field-check" />
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group field-required">
                <label class="form-label">Invoice Date</label>
                <input type="date" name="invoice_date" value="<?php echo $invoice->invoice_date; ?>" class="form_control field-check" />
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group field-required">
                <label class="form-label">Customer</label>
                <div class="ajaxselectBox poR" id="customer_ajax_select_box" data-ajax-url="<?= url_to('erp.sale.getCustomer'); ?>">
                    <div class="ajaxselectBoxBtn flex">
                        <div class="textFlow" data-default="select customer"><?php echo $invoice->name; ?></div>
                        <button class="close" type="button"><i class="fa fa-close"></i></button>
                        <button class="drops" type="button"><i class="fa fa-caret-down"></i></button>
                        <input type="hidden" class="ajaxselectBox_Value field-check" name="cust_id" value="<?php echo $invoice->cust_id; ?>">
                    </div>
                    <div class="ajaxselectBox_Container alldiv">
                        <input type="text" class="ajaxselectBox_Search form_control" />
                        <ul role="listbox">

                        </ul>
                    </div>
                </div>
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group ">
                <label class="form-label">Shipping Address</label>
                <div class="selectBox poR" id="customer_shipping_addr" data-ajax-url="<?= url_to('erp.sale.getShippingDataCustomer'); ?>">
                    <div class="selectBoxBtn flex">
                        <div class="textFlow" data-default="select address">select address</div>
                        <button class="close" type="button"><i class="fa fa-close"></i></button>
                        <button class="drops" type="button"><i class="fa fa-caret-down"></i></button>
                        <input type="hidden" class="selectBox_Value field-check" name="shippingaddr_id" value="<?php
                                                                                                                if (!empty($invoice->shippingaddr_id)) {
                                                                                                                    echo $invoice->shippingaddr_id;
                                                                                                                }
                                                                                                                ?>">
                    </div>
                    <ul role="listbox" class="selectBox_Container alldiv">

                    </ul>
                </div>
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group">
                <label class="form-label"></label>
                <div>
                    <label class="form-check-label"><input type="checkbox" <?php
                                                                            if ($invoice->transport_req == 1) {
                                                                                echo "checked";
                                                                            }
                                                                            ?> name="transport_req" value="1" class="field-check" /> Transport Required</label>
                </div>
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group field-money">
                <label class="form-label">Transport Charge</label>
                <input type="text" id="invoice_trans_charge" name="trans_charge" value="<?php echo $invoice->trans_charge; ?>" class="form_control field-check" />
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group field-required">
                <label class="form-label">Invoice Expiry</label>
                <input type="date" name="invoice_expiry" value="<?php echo $invoice->invoice_expiry; ?>" class="form_control field-check" />
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-2">
            <div class="form-group field-required">
                <label class="form-label">Payment Terms</label>
                <input type="text" name="payment_terms" value="<?php echo $invoice->payment_terms; ?>" class="form_control field-check" />
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-1">
            <div class="form-group field-required ">
                <label class="form-label">Terms and Condition</label>
                <textarea rows="3" name="terms_condition" class="form_control field-check"><?php echo $invoice->terms_condition; ?></textarea>
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-1">
            <div class="widget_title">
                <h3>Add Items</h3>
            </div>
        </div>
        <div class="form-width-3">
            <div class="form-group" id="invoice_product">
                <label class="form-label">Product</label>
                <div class="ajaxselectBox poR" data-ajax-url="<?php echo url_to('erp.crm.ajaxfetchfinishedgoods'); ?>">
                    <div class="ajaxselectBoxBtn flex">
                        <div class="textFlow" data-default="select product">select product</div>
                        <button class="close" type="button"><i class="fa fa-close"></i></button>
                        <button class="drops" type="button"><i class="fa fa-caret-down"></i></button>
                        <input type="hidden" class="ajaxselectBox_Value field-check" value="">
                    </div>
                    <div class="ajaxselectBox_Container alldiv">
                        <input type="text" class="ajaxselectBox_Search form_control" />
                        <ul role="listbox">

                        </ul>
                    </div>
                </div>
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-3">
            <div class="form-group" id="invoice_price_list" data-ajax-url="<?= url_to('erp.sale.getPriceData'); ?>">
                <label class="form-label">Price List</label>
                <div class="selectBox poR">
                    <div class="selectBoxBtn flex">
                        <div class="textFlow" data-default="select price">select price</div>
                        <button class="close" type="button"><i class="fa fa-close"></i></button>
                        <button class="drops" type="button"><i class="fa fa-caret-down"></i></button>
                        <input type="hidden" class="selectBox_Value field-check" value="">
                    </div>
                    <ul role="listbox" class="selectBox_Container alldiv">

                    </ul>
                </div>
                <p class="error-text"></p>
            </div>
        </div>
        <input type="hidden" id="invoice_amount" />
        <div class="form-width-3">
            <div class="form-group" id="invoice_product_qty">
                <label class="form-label">Quantity</label>
                <input type="text" class="form_control field-check" />
                <p class="error-text"></p>
            </div>
        </div>
        <div class="form-width-1">
            <div class="form-group textRight">
                <label class="form-label"></label>
                <button class="btn outline-primary" type="button" id="add_item_btn">Add Item</button>
            </div>
        </div>
        <div class="form-width-1">
            <table class="table">
                <thead>
                    <th>SNO</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Amount</th>
                    <th>Tax</th>
                    <th>Action</th>
                </thead>
                <tbody id="invoice_items_holder">
                    <?php
                    $sno = 1;
                    foreach ($invoice_items as $row) {
                    ?>
                        <tr>
                            <td><?php echo $sno; ?></td>
                            <td><span><?php echo $row['product']; ?></span><input type="hidden" name="product_id[<?php echo $sno; ?>]" value="<?php echo $row['related_id']; ?>" /></td>
                            <td><span><?php echo $row['quantity']; ?></span><input type="hidden" name="quantity[<?php echo $sno; ?>]" value="<?php echo $row['quantity']; ?>" /></td>
                            <td><span><?php echo $row['unit_price']; ?></span><input type="hidden" name="price_id[<?php echo $sno; ?>]" value="<?php echo $row['price_id']; ?>" /></td>
                            <td><span><?php echo $row['amount']; ?></span></td>
                            <!-- <td><span><?php echo $row['amount']; ?></span></td> -->
                            <td><button type="button" class="btn bg-danger product-remove-btn"><i class="fa fa-trash"></i></button>
                        </tr>
                    <?php
                        $sno++;
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5"></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="text-right"><b>Subtotal</b></td>
                        <td id="invoice_subtotal">0.00</td>
                    </tr>
                    <!-- <tr>
                        <td colspan="4" class="text-right"><b>Tax</b></td>
                        <td id="invoice_subtotal">0.00</td> 
                    </tr> -->
                    <tr>
                        <td colspan="4" class="text-right"><b>Discount</b></td>
                        <td><input type="text" name="discount" id="invoice_discount" value="<?php echo $invoice->discount; ?>" class="form_control field-check" /></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="text-right"><b>Total</b></td>
                        <td id="invoice_total">0.00</td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="form-width-1">
            <div class="form-group textRight ">
                <a class="btn outline-danger" href="<?= url_to('erp.sale.invoice'); ?>">Cancel</a>
                <button class="btn bg-primary" type="button" id="invoice_add_btn">Update</button>
            </div>
        </div>
    </form>
</div>





<!--SCRIPT WORKS -->
</div>
</main>
<script src="<?php echo base_url() . 'assets/js/jquery.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/script.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/erp.js'; ?>"></script>

<script type="text/javascript">
    let closer = new WindowCloser();
    let alert = new ModalAlert();
    closer.init();

    calculateSubtotal();
    calculateTotal();

    // let invoice_status_box=new SelectBox(document.getElementById("invoice_status"));
    // invoice_status_box.init();
    // closer.register_shutdown(invoice_status_box.shutdown,invoice_status_box.get_container());

    let customer_ajax_select = document.getElementById("customer_ajax_select_box");
    let customer_ajax_select_box = new AjaxSelectBox(customer_ajax_select);
    customer_ajax_select_box.init();
    closer.register_shutdown(customer_ajax_select_box.shutdown, customer_ajax_select_box.get_container());
    let customer_shipping_select = document.getElementById("customer_shipping_addr");
    let customer_shipping_select_box;
    customer_ajax_select_box.add_listener((params) => {
        let cust_id = params.value;
        let ajax_url = customer_shipping_select.getAttribute("data-ajax-url");
        if (cust_id !== null && cust_id !== undefined && cust_id !== "") {
            let xhr = null;
            if (window.ActiveXObject) {
                xhr = new ActiveXObject("Msxml2.XMLHTTP");
            } else if (window.XMLHttpRequest) {
                xhr = new XMLHttpRequest();
            }
            if (xhr !== null || xhr !== undefined) {
                xhr.open("GET", ajax_url + "?cust_id=" + cust_id, true);
                xhr.send(null);
                xhr.onreadystatechange = (evt) => {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        let json = JSON.parse(xhr.responseText);
                        if (json['error'] == 0) {
                            let data = json['data'];
                            let html = ``;
                            for (let i = 0; i < data.length; i++) {
                                html += ` <li role="option" data-value="` + data[i]['key'] + `" >` + data[i]['value'] + `</li>`;
                            }
                            customer_shipping_select.querySelector("ul").innerHTML = html;
                            customer_shipping_select_box = new SelectBox(customer_shipping_select);
                            customer_shipping_select_box.init();
                        } else {
                            alert.invoke_alert(json['reason'], "error");
                        }
                    }
                }
            }
        } else {
            if (customer_shipping_select_box != null) {
                customer_shipping_select.querySelector(".selectBox_Value").value = "";
                customer_shipping_select_box.construct();
            }
            customer_shipping_select.querySelector("ul").innerHTML = "";
            customer_shipping_select_box = null;
        }
    }, {});

    let form = document.getElementById("invoice_add_form");
    let validator = new FormValidate(form);

    let lock = false;
    document.getElementById("invoice_add_btn").onclick = function(evt) {
        if (!lock) {
            lock = true;
            validator.validate(
                (params) => {
                    form.submit();
                    lock = false;
                },
                (params) => {
                    lock = false;
                }, {});
        }
    }

    let invoice_product = document.getElementById("invoice_product");
    let invoice_price_list = document.getElementById("invoice_price_list");
    let invoice_price_list_box;
    let invoice_product_box = new AjaxSelectBox(invoice_product.querySelector(".ajaxselectBox"));
    invoice_product_box.init();
    invoice_product_box.add_listener((params) => {
        let product_id = params.value;
        let ajax_url = invoice_price_list.getAttribute("data-ajax-url");
        if (product_id !== null && product_id !== undefined && product_id !== "") {
            let xhr = null;
            if (window.ActiveXObject) {
                xhr = new ActiveXObject("Msxml2.XMLHTTP");
            } else if (window.XMLHttpRequest) {
                xhr = new XMLHttpRequest();
            }
            if (xhr !== null || xhr !== undefined) {
                xhr.open("GET", ajax_url + "?product_id=" + product_id, true);
                xhr.send(null);
                xhr.onreadystatechange = (evt) => {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        let json = JSON.parse(xhr.responseText);
                        if (json['error'] == 0) {
                            let data = json['data'];
                            let html = ``;
                            for (let i = 0; i < data.length; i++) {
                                let extra = [];
                                if (data[i]['extra'] !== null && data[i]['extra'] !== undefined && data[i]['extra'] !== "") {
                                    extra = JSON.stringify(data[i]['extra']);
                                }
                                html += ` <li role="option" data-value="` + data[i]['key'] + `" data-extra='` + extra + `' >` + data[i]['value'] + `</li>`;
                            }
                            invoice_price_list.querySelector("ul").innerHTML = html;
                            invoice_price_list_box = new SelectBox(invoice_price_list.querySelector(".selectBox"));
                            invoice_price_list_box.init();
                            invoice_price_list_box.add_listener((params) => {
                                document.getElementById("invoice_amount").value = params['extra'][0];
                            }, {});
                            closer.register_shutdown(invoice_price_list_box.shutdown, invoice_price_list_box.get_container());
                        } else {
                            alert.invoke_alert(json['reason'], "error");
                        }
                    }
                }
            }
        } else {
            if (invoice_price_list_box != null) {
                invoice_price_list.querySelector(".selectBox_Value").value = "";
                invoice_price_list_box.construct();
            }
            invoice_price_list.querySelector("ul").innerHTML = "";
            invoice_price_list_box = null;
            document.getElementById("invoice_amount").value = "";
        }
    }, {});
    closer.register_shutdown(invoice_product_box.shutdown, invoice_product_box.get_container());
    let invoice_quantity = document.getElementById("invoice_product_qty");

    let sno = parseInt("<?php echo $sno++; ?>");
    document.getElementById("add_item_btn").onclick = (evt) => {
        let qty = parseInt(invoice_quantity.querySelector(".field-check").value);
        let unit_price = parseFloat(document.getElementById("invoice_amount").value);
        let product_id = invoice_product.querySelector(".ajaxselectBox_Value").value;
        let product_name = invoice_product.querySelector(".textFlow").textContent;
        let price_id = invoice_price_list.querySelector(".selectBox_Value").value;
        let price_name = invoice_price_list.querySelector(".textFlow").textContent;

        if (product_id === null || product_id === undefined || product_id === "") {
            alert.invoke_alert("Select product", "error");
            return;
        }
        if (price_id === null || price_id === undefined || price_id === "") {
            alert.invoke_alert("Select price list", "error");
            return;
        }
        if (qty === null || qty === undefined || isNaN(qty) || qty <= 0) {
            alert.invoke_alert("Invalid quantity", "error");
            return;
        }

        let product_names = document.querySelectorAll("#invoice_items_holder tr td:nth-child(2) span");
        if (product_names.length != 0) {
            let dup_found = false;
            for (let i = 0; i < product_names.length; i++) {
                if (product_name == product_names[i].textContent) {
                    dup_found = true;
                    break;
                }
            }
            if (dup_found) {
                alert.invoke_alert("Duplicate product not allowed", "error");
                return;
            }
        }
        let tr = ``;
        tr += `<td>` + sno + `</td>`
        sno++;
        tr += `<td><span>` + product_name + `</span><input type="hidden" name="product_id[` + sno + `]" value="` + product_id + `" /></td>`;
        tr += `<td><span>` + qty + `</span><input type="hidden" name="quantity[` + sno + `]" value="` + qty + `" /></td>`;
        tr += `<td><span>` + unit_price + `</span><input type="hidden" name="price_id[` + sno + `]" value="` + price_id + `" /></td>`;
        let amount = unit_price * qty;
        amount = amount.toFixed(2);
        tr += `<td><span>` + amount + `</span></td>`;
        tr += `<td><button type="button" class="btn bg-danger product-remove-btn" ><i class="fa fa-trash"></i></button>`;
        let element = document.createElement("tr");
        element.innerHTML = tr;
        document.getElementById("invoice_items_holder").append(element);
        calculateSubtotal();
        calculateTotal();
    }
    document.getElementById("invoice_items_holder").onclick = (evt) => {
        let target = evt.target;
        document.querySelectorAll("#invoice_items_holder .product-remove-btn").forEach((item) => {
            if (item.contains(target)) {
                item.parentElement.parentElement.remove();
                calculateSubtotal();
                calculateTotal();
            }
        });
    }

    document.getElementById("invoice_discount").onchange = (evt) => {
        let discount = evt.target.value;
        let pattern = /^[0-9]+\.[0-9]{2}$/;
        if (!pattern.test(discount)) {
            alert.invoke_alert("Invalid discount value", "error");
        }
        calculateTotal();
    };

    document.getElementById("invoice_trans_charge").onchange = (evt) => {
        let trans_charge = evt.target.value;
        let pattern = /^[0-9]+\.[0-9]{2}$/;
        if (!pattern.test(trans_charge)) {
            alert.invoke_alert("Invalid Transport Charge value", "error");
        }
        calculateTotal();
    };

    function calculateSubtotal() {
        let amounts = document.querySelectorAll("#invoice_items_holder tr td:nth-child(5) span");
        let total = 0.00;
        if (amounts.length != 0) {
            for (let i = 0; i < amounts.length; i++) {
                total += parseFloat(amounts[i].textContent);
            }
        }
        document.getElementById("invoice_subtotal").textContent = total.toFixed(2);
    };

    function calculateTotal() {
        let amount = parseFloat(document.getElementById("invoice_subtotal").textContent);
        let trans_charge = parseFloat(document.getElementById("invoice_trans_charge").value);
        let discount = parseFloat(document.getElementById("invoice_discount").value);
        let total = 0.00;
        if (!isNaN(amount)) {
            total += amount;
        }
        if (!isNaN(trans_charge)) {
            total += trans_charge;
        }
        if (!isNaN(discount)) {
            total -= discount;
        }
        document.getElementById("invoice_total").textContent = total.toFixed(2);
    }

    <?php
    if (session()->getFlashdata("op_success")) { ?>
        alert.invoke_alert("<?= session()->getFlashdata('op_success'); ?>", "success");
    <?php
    } else if (session()->getFlashdata("op_error")) { ?>
        alert.invoke_alert("<?= session()->getFlashdata('op_error'); ?>", "error");
    <?php
    }
    ?>
</script>
</body>

</html>