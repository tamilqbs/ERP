<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/custom-style.css' ;?>">
<div class="alldiv flex widget_title">
    <h3>Notification Center</h3>
</div>

<div class="alldiv">

    <div class="chat-container">

        <div class="left-panel">
            <h1>Left</h1>
            <div class="notify-cards">
                <div class="notify-card">
                    
                </div>
            </div>
        </div>
        <div class="right-panel">
            <h1>Right</h1>
        </div>

    </div>
</div>

<!--SCRIPT WORKS-->
</div>
</main>
<script src="<?php echo base_url() . 'assets/js/jquery.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/script.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/erp.js'; ?>"></script>
<script type="text/javascript">
    <?php
    if (session()->getFlashdata("op_success")) { ?>
        let alerts = new ModalAlert();
        alerts.invoke_alert("<?php echo $this->session->flashdata('op_success'); ?>", "success");
    <?php
    } else if (session()->getFlashdata("op_error")) { ?>
        let alert = new ModalAlert();
        alert.invoke_alert("<?php echo $this->session->flashdata('op_error'); ?>", "error");
    <?php
    }
    ?>
</script>
</body>

</html>