<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<p class="mb-2"><i class="fa-solid fa-cart-shopping"></i>Orders are about to be delivered</p>

<div class="alldiv">
    <table id="orderStatusTable" class="display text-center">
        <thead>
            <tr>
                <th>Code</th>
                <th>Order Date</th>
                <th>Order Expiry</th>
                <th>Status</th>
                <th>Amount Rs.</th>
                <th>Tax Rs.</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
    <p><?php //foreach ($statusCounts as $status => $count) {
        // echo "Number of projects with status $status: $count<br>";
        //} 
        ?></p>
    <!--SCRIPT WORKS-->
</div>
<!-- <div class="alldiv"> -->
<div class="row">
    <div class="pieChart">
        <canvas id="pieChart"></canvas>
    </div>
    <div class="leadstatusChart">
        <canvas id="leadstatusChart"></canvas>
    </div>
</div>



<p class="mt-5" style="font-weight: bold;"><i class="fa-solid fa-street-view"></i> OVERVIEW</p>
<div class="alldiv mt-5">
    <table id="overView" class="display text-center">
        <thead>
            <tr>
                <th>QUOTATIONS OVERVIEW</th>
                <th>INVOICE OVERVIEW</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <a href="<?php echo url_to('erp.sale.quotations'); ?>">
                        <div class="side">
                            <p><?= $quotationCount[0]['quotation_count'] ?? 0 ?>&nbsp;<?= $quotationCount[0]['status'] = 4 ? "Converted" : "" ?></p>
                            <p><?= number_format(($quotationCount[0]['quotation_count'] ?? 0 / $quotationCount[0]['total']) * 100, 2)  ?>%</p>
                        </div>
                        <div class="bg-dark border-rounded mt-1">
                            <div class="bg-danger" style="height: 4px; width:<?= ($quotationCount[0]['quotation_count'] ?? 0 / $quotationCount[0]['total']) * 100  ?>%">

                            </div>
                        </div>
                    </a>
                </td>
                <td>
                    <a href="<?= url_to('erp.sale.invoice'); ?>">
                        <div class="side">
                            <p><?= $invoiceCount[0]['invoice_count'] ?>&nbsp;<?= $quotationCount[0]['status'] = 2 ? "Paid" : "" ?></p>
                            <p><?= number_format(($invoiceCount[0]['invoice_count'] / $invoiceCount[0]['total']) * 100, 2)  ?>%</p>
                        </div>
                        <div class="bg-dark border-rounded">
                            <div class="bg-one" style="height: 4px; width:<?= ($invoiceCount[0]['invoice_count'] / $invoiceCount[0]['total']) * 100  ?>%">

                            </div>
                        </div>
                    </a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="<?php echo url_to('erp.sale.quotations'); ?>">
                        <div class="side">
                            <p><?= $quotationCount[0]['quotation_count'] ?>&nbsp;<?= $quotationCount[0]['status'] = 4 ? "Converted" : "" ?></p>
                            <p><?= number_format(($quotationCount[0]['quotation_count'] / $quotationCount[0]['total']) * 100, 2)  ?>%</p>
                        </div>
                        <div class="bg-dark border-rounded">
                            <div class="bg-danger" style="height: 4px; width:<?= ($quotationCount[0]['quotation_count'] / $quotationCount[0]['total']) * 100  ?>%">

                            </div>
                        </div>
                    </a>
                </td>
                <td>
                    <a href="<?= url_to('erp.sale.invoice'); ?>">
                        <div class="side">
                            <p><?= $invoiceCount[1]['invoice_count'] ?>&nbsp;<?= $quotationCount[0]['status'] = 3 ? "Overdue" : "" ?></p>
                            <p><?= number_format(($invoiceCount[1]['invoice_count'] / $invoiceCount[0]['total']) * 100, 2)  ?>%</p>
                        </div>
                        <div class="bg-dark border-rounded">
                            <div class="bg-two" style="height: 4px; width:<?= ($invoiceCount[1]['invoice_count'] / $invoiceCount[0]['total']) * 100  ?>%">

                            </div>
                        </div>
                    </a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="<?php echo url_to('erp.sale.quotations'); ?>">
                        <div class="side">
                            <p><?= $quotationCount[0]['quotation_count'] ?? 0 ?>&nbsp;<?= $quotationCount[0]['status'] = 4 ? "Converted" : "" ?></p>
                            <p><?= number_format(($quotationCount[0]['quotation_count'] / $quotationCount[0]['total']) * 100, 2)  ?>%</p>
                        </div>
                        <div class="bg-dark border-rounded mt-1">
                            <div class="bg-danger" style="height: 4px; width:<?= ($quotationCount[0]['quotation_count'] / $quotationCount[0]['total']) * 100  ?>%">

                            </div>
                        </div>
                    </a>
                </td>
                <td>
                    <a href="<?= url_to('erp.sale.invoice'); ?>">
                        <div class="side">
                            <p><?= $invoiceCount[2]['invoice_count'] ?? 0 ?>&nbsp;<?= $quotationCount[0]['status'] = 1 ? "Partially Paid" : "" ?></p>
                            <p><?= number_format(($invoiceCount[2]['invoice_count'] ?? 0 / $invoiceCount[0]['total'] ?? 0) * 100, 2)  ?>%</p>
                        </div>
                        <div class="bg-dark border-rounded">
                            <div class="bg-three" style="height: 4px; width:<?= ($invoiceCount[2]['invoice_count'] ?? 0 / $invoiceCount[0]['total'] ?? 0) * 100  ?>%">

                            </div>
                        </div>
                    </a>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<style>
    .alldiv #overView_filter {
        display: none;
    }

    #overView_length {
        display: none;
    }

    .row {
        display: flex;
        margin-top: 68px;
        justify-content: space-evenly;
    }

    .pieChart {
        display: block;
        box-sizing: border-box;
        /* padding: 0 0 0 0 ; */
        box-shadow: 0 4px 6px 0 rgb(0 0 0 / 14%);
        height: 304px;
        width: 304px;
    }

    .leadstatusChart {
        display: block;
        box-sizing: border-box;
        box-shadow: 0 4px 6px 0 rgb(0 0 0 / 14%);
        height: 304px;
        width: 304px;
    }
</style>
<!-- </div> -->
</main>
<!-- <script src="<?php // echo base_url() . 'assets/js/jquery.min.js'; 
                    ?>"></script> -->
<script src="<?php echo base_url() . 'assets/js/script.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/erp.js'; ?>"></script>
<script>
    $(document).ready(function() {
        $('#overView').DataTable();
    });

    const leadstatusCounts = <?php echo json_encode($leadsCountStatus); ?>;
    const leadLabels = ['OPEN', 'CONTACTED', 'WORKING', 'DISQUALIFIED', 'CUSTOMER'];
    const leadData = Object.values(leadstatusCounts);

    // Create Chart.js doughnut chart
    const leadTableId = document.getElementById('leadstatusChart').getContext('2d');
    const leadstatusChart = new Chart(leadTableId, {
        type: 'doughnut',
        data: {
            labels: leadLabels,
            datasets: [{
                data: leadData,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(255, 205, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(39, 245, 174, 0.8)',
                ],
            }],
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Lead Status',
                },
            },
        },
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        var orderStatus = {
            0: "Created",
            1: "Invoiced",
            2: "Completed",
            3: "Cancelled"
        };

        var table = $('#orderStatusTable').DataTable({
            "ajax": {
                "url": "<?= url_to('erp.orderstatus'); ?>",
                "type": "GET",
                "dataSrc": ""
            },
            "dom": 'Bfrtip',
            "buttons": [
                'excel'
            ],
            "columns": [{
                    "data": "code"
                },
                {
                    "data": "order_date"
                },
                {
                    "data": "order_expiry"
                },
                {
                    "data": "status",
                    "render": function(data) {
                        return '<span class="' + getOrderStatusClass(data) + '">' + orderStatus[data] + '</span>';
                    }
                },
                {
                    "data": "amount"
                },
                {
                    "data": "tax"
                }
            ]
        });

        function getOrderStatusClass(status) {
            switch (parseInt(status)) {
                case 0:
                    return 'created-text';
                case 1:
                    return 'invoiced-text';
                case 2:
                    return 'completed-text';
                case 3:
                    return 'cancelled-text';
                default:
                    return '';
            }
        }
    });


    const statusCounts1 = <?php echo json_encode($statusCounts); ?>;
    const data2 = Object.values(statusCounts1);

    const data1 = {
        labels: ['Created', 'Progress', 'On Hold', 'Completed', 'Cancelled'],
        datasets: [{
            label: '',
            data: data2,
            borderWidth: 1,
            backgroundColor: ['#CB4335', '#1F618D', '#F1C40F', '#27AE60', '#884EA0', '#D35400'],
        }]
    };

    const config = {
        type: 'pie',
        data: data1,
        options: {
            plugins: {
                legend: {
                    onHover: handleHover,
                    onLeave: handleLeave
                },
                title: {
                    display: true,
                    text: 'Statistics by Project Status',
                },
            }
        }
    };

    const ctx1 = document.getElementById('pieChart').getContext('2d');
    const pieChart = new Chart(ctx1, config);

    function handleHover(event, legendItem) {
        // console.log('Hovered:', legendItem.text);
    }

    function handleLeave(event, legendItem) {
        // console.log('Left:', legendItem.text);
    }

    // const config1 = {
    //     type: 'line',
    //     data: {
    //         labels: <?php //echo json_encode(array_keys($sourceCount)); 
                        ?>,
    //         datasets: [{
    //             label: 'Source Count',
    //             data: <?php //echo json_encode(array_values($sourceCount)); 
                            ?>,
    //             borderColor: 'rgba(75, 192, 192, 1)',
    //             backgroundColor: 'rgba(75, 192, 192, 0.2)',
    //             fill: true,
    //         }, ],
    //     },
    //     options: {
    //         plugins: {
    //             title: {
    //                 display: true,
    //                 text: 'Lead Source Count',
    //             },
    //         },
    //         scales: {
    //             y: {
    //                 stacked: true,
    //             },
    //         },
    //     },
    // };

    // const ctx2 = document.getElementById('leadSourceChart').getContext('2d');
    // const leadSourceChart = new Chart(ctx2, config1);




    <?php
    if (session()->getFlashdata("op_success")) { ?>
        let alerts = new ModalAlert();
        alerts.invoke_alert("<?php echo session()->getFlashdata('op_success'); ?>", "success");
    <?php
    } else if (session()->getFlashdata("op_error")) { ?>
        let alert = new ModalAlert();
        alert.invoke_alert("<?php echo session()->getFlashdata('op_error'); ?>", "error");
    <?php
    }
    ?>
</script>
</body>

</html>